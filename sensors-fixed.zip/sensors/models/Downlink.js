const mongoose = require('mongoose');

// Downlinks sent from the dashboard. ChirpStack keeps its own device queue;
// this collection tracks what was sent and how far each message got.
const downlinkSchema = new mongoose.Schema({
  devEui: { type: String, required: true, index: true },
  deviceName: { type: String, default: '' },
  applicationId: { type: String, default: '' },
  fPort: { type: Number, required: true, min: 1, max: 223 },
  confirmed: { type: Boolean, default: false },
  data: { type: String, required: true },      // base64 (what is sent to ChirpStack)
  dataHex: { type: String, default: '' },      // same bytes as hex, for display
  status: {
    type: String,
    enum: ['queued', 'transmitted', 'acknowledged', 'failed'],
    default: 'queued'
  },
  fCntDown: { type: Number },
  transmittedAt: { type: Date },
  acknowledgedAt: { type: Date }
}, { timestamps: true });

module.exports = mongoose.model('Downlink', downlinkSchema);
