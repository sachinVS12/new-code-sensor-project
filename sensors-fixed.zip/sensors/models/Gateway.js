const mongoose = require('mongoose');

const gatewaySchema = new mongoose.Schema({
  gatewayName: {
    type: String,
    required: true,
    unique: true
  },
  gatewayEui: {
    type: String,
    required: true,
    unique: true
  },
  destinationIp: {
    type: String,
    required: true
  },
  port: {
    type: String,
    required: true
  },
  mode: {
    type: String,
    required: true,
    enum: ['local', 'cloud']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Gateway', gatewaySchema);
