const mongoose = require('mongoose');

const nodeSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true,
    unique: true
  },
  devEui: {
    type: String,
    required: true,
    unique: true
  },
  applicationId: {
    type: String,
    required: true
  },
  mqttTopic: {
    type: String,
    required: true
  },
  mode: {
    type: String,
    required: true,
    enum: ['OTAA', 'ABP']
  },
  gateway: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Node', nodeSchema);
