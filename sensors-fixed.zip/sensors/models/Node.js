const mongoose = require('mongoose');

const nodeSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true,
    unique: true
  },
  devEui: {
    type: String,
    required: true,
    unique: true
  },
  applicationId: {
    type: String,
    required: true
  },
  mqttTopic: {
    type: String,
    required: true
  },
  mode: {
    type: String,
    enum: ['OTAA', 'ABP'],
    default: 'OTAA'
  },
  gateway: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Node', nodeSchema);
