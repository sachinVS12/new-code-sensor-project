const mongoose = require('mongoose');

const sensorDataSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true
  },
  devEui: {
    type: String,
    required: true,
    index: true
  },
  timestamp: {
    type: Date,
    required: true,
    index: true
  },
  rssi: {
    type: Number
  },
  snr: {
    type: Number
  },
  fPort: {
    type: Number
  },
  data: {
    type: String
  },
  decodedPayload: {
    type: mongoose.Schema.Types.Mixed
  },
  gatewayId: {
    type: String
  },
  frequency: {
    type: Number
  },
  dataRate: {
    type: String
  },
  fCnt: {
    type: Number
  }
}, {
  timestamps: true
});

// Index for efficient queries
sensorDataSchema.index({ devEui: 1, timestamp: -1 });

module.exports = mongoose.model('SensorData', sensorDataSchema);
