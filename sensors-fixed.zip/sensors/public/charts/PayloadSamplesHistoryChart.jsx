function PayloadSamplesHistoryChart({ payloadHistory }) {
    const [hoverData, setHoverData] = React.useState(null);
    const [zoom, setZoom] = React.useState({ scale: 1, offsetX: 0, offsetY: 0 });
    const [isDragging, setIsDragging] = React.useState(false);
    const [dragStart, setDragStart] = React.useState({ x: 0, y: 0 });
    const [lockScroll, setLockScroll] = React.useState(false);
    const svgRef = React.useRef(null);

    // Handle scroll lock with passive: false
    React.useEffect(() => {
        const svg = svgRef.current;
        if (!svg) return;

        const handleWheelEvent = (e) => {
            if (lockScroll) {
                e.preventDefault();
                e.stopPropagation();
                // Handle zoom
                const rect = svg.getBoundingClientRect();
                const mouseX = e.clientX - rect.left;
                const mouseY = e.clientY - rect.top;

                const scaleAmount = e.deltaY > 0 ? 0.9 : 1.1;
                const newScale = Math.max(0.5, Math.min(10, zoom.scale * scaleAmount));

                const scaleChange = newScale / zoom.scale;
                const newOffsetX = mouseX - (mouseX - zoom.offsetX) * scaleChange;
                const newOffsetY = mouseY - (mouseY - zoom.offsetY) * scaleChange;

                setZoom({ scale: newScale, offsetX: newOffsetX, offsetY: newOffsetY });
            }
        };

        svg.addEventListener('wheel', handleWheelEvent, { passive: false });

        return () => {
            svg.removeEventListener('wheel', handleWheelEvent, { passive: false });
        };
    }, [lockScroll, zoom]);

    if (!payloadHistory || payloadHistory.length === 0) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                No payload data yet. Waiting for sensor messages...
            </div>
        );
    }

    // Flatten all samples with gaps only between complete datasets
    // Chunks from the same dataset are continuous (no gaps)
    const gapSize = 10; // Number of null points to insert as gap
    const allSamples = [];
    const sampleInfo = []; // Track which payload each sample belongs to

    payloadHistory.forEach((payload, payloadIndex) => {
        const samples = payload.samples || [];
        samples.forEach((sample, sampleIndex) => {
            allSamples.push(sample);
            sampleInfo.push({
                payloadIndex,
                sampleIndex,
                isStart: sampleIndex === 0,
                isEnd: sampleIndex === samples.length - 1,
                time: payload.time,
                isChunk: payload.isChunk || false,
                progress: payload.progress || null
            });
        });
        // Add gap after complete datasets (not after chunks)
        if (!payload.isChunk && payloadIndex < payloadHistory.length - 1) {
            for (let i = 0; i < gapSize; i++) {
                allSamples.push(null);
                sampleInfo.push({ isGap: true });
            }
        }
    });

    if (allSamples.length === 0) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                No samples in history.
            </div>
        );
    }

    const width = 1200;
    const height = 400;
    const padding = 50;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    // Calculate min/max from non-null samples
    const validSamples = allSamples.filter(s => s !== null);
    const minVal = validSamples.length ? Math.min(...validSamples) : 0;
    const maxVal = validSamples.length ? Math.max(...validSamples) : 100;
    const range = maxVal - minVal || 1;

    // Apply zoom transformation
    const transform = `translate(${zoom.offsetX}, ${zoom.offsetY}) scale(${zoom.scale})`;

    // Calculate points for the line
    const points = allSamples.map((val, i) => {
        const x = padding + (i / (allSamples.length - 1 || 1)) * chartWidth;
        const y = val !== null ? padding + chartHeight - ((val - minVal) / range) * chartHeight : null;
        return { x, y, val, index: i, info: sampleInfo[i] };
    });

    // Build polylines (split at gaps)
    const polylines = [];
    let currentLine = [];
    points.forEach(p => {
        if (p.y !== null) {
            currentLine.push(`${p.x},${p.y}`);
        } else {
            if (currentLine.length > 0) {
                polylines.push(currentLine.join(' '));
                currentLine = [];
            }
        }
    });
    if (currentLine.length > 0) {
        polylines.push(currentLine.join(' '));
    }

    const chunkCount = payloadHistory.filter(p => p.isChunk).length;
    const completeCount = payloadHistory.filter(p => !p.isChunk).length;
    const gapCount = payloadHistory.filter((p, i) => !p.isChunk && i < payloadHistory.length - 1).length;

    // Handle mouse wheel zoom
    const handleWheel = (e) => {
        if (lockScroll) {
            e.preventDefault();
            e.stopPropagation();
        }
        const svg = e.currentTarget;
        const rect = svg.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        const scaleAmount = e.deltaY > 0 ? 0.9 : 1.1;
        const newScale = Math.max(0.5, Math.min(10, zoom.scale * scaleAmount));

        // Calculate new offset to zoom towards mouse position
        const scaleChange = newScale / zoom.scale;
        const newOffsetX = mouseX - (mouseX - zoom.offsetX) * scaleChange;
        const newOffsetY = mouseY - (mouseY - zoom.offsetY) * scaleChange;

        setZoom({ scale: newScale, offsetX: newOffsetX, offsetY: newOffsetY });
    };

    // Handle mouse drag for panning
    const handleMouseDown = (e) => {
        setIsDragging(true);
        setDragStart({ x: e.clientX - zoom.offsetX, y: e.clientY - zoom.offsetY });
    };

    const handleMouseMove = (e) => {
        const svg = e.currentTarget;
        const rect = svg.getBoundingClientRect();
        const scaleX = width / rect.width;
        const scaleY = height / rect.height;
        const mouseX = (e.clientX - rect.left) * scaleX;
        const mouseY = (e.clientY - rect.top) * scaleY;

        if (isDragging) {
            setZoom({
                ...zoom,
                offsetX: e.clientX - dragStart.x,
                offsetY: e.clientY - dragStart.y
            });
            return;
        }

        // Find closest point (account for zoom)
        let closestPoint = null;
        let minDist = Infinity;

        points.forEach(p => {
            if (p.y !== null) {
                const transformedX = p.x * zoom.scale + zoom.offsetX;
                const dist = Math.abs(transformedX - mouseX);
                if (dist < minDist && dist < 20 / zoom.scale) {
                    minDist = dist;
                    closestPoint = p;
                }
            }
        });

        if (closestPoint) {
            setHoverData({
                x: closestPoint.x * zoom.scale + zoom.offsetX,
                y: closestPoint.y * zoom.scale + zoom.offsetY,
                value: closestPoint.val,
                info: closestPoint.info,
                screenX: e.clientX,
                screenY: e.clientY
            });
        } else {
            setHoverData(null);
        }
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    const handleMouseLeave = () => {
        setIsDragging(false);
        setHoverData(null);
    };

    const resetZoom = () => {
        setZoom({ scale: 1, offsetX: 0, offsetY: 0 });
    };

    return (
        <div>
            <div style={{ marginBottom: '10px', fontSize: '14px', color: '#666' }}>
                Total: {payloadHistory.length} entries ({completeCount} complete, {chunkCount} chunks) | Total samples: {validSamples.length} | Gaps: {gapCount}
                {hoverData && <span style={{ marginLeft: '15px', color: '#ff6b6b', fontWeight: 'bold' }}>Hovered Value: {hoverData.value}</span>}
                <button
                    onClick={resetZoom}
                    style={{ marginLeft: '15px', padding: '4px 8px', fontSize: '12px', cursor: 'pointer', backgroundColor: '#ddd', border: 'none', borderRadius: '4px' }}
                >
                    Reset Zoom
                </button>
                <button
                    onClick={() => setLockScroll(!lockScroll)}
                    style={{ marginLeft: '10px', padding: '4px 8px', fontSize: '12px', cursor: 'pointer', backgroundColor: lockScroll ? '#ff6b6b' : '#4CAF50', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    {lockScroll ? '🔓 Unlock' : '🔒 Lock Scroll'}
                </button>
                <span style={{ marginLeft: '10px', fontSize: '12px', color: '#888' }}>
                    (Scroll to zoom, drag to pan)
                </span>
            </div>
            <div style={{ position: 'relative', border: '2px solid #ddd', borderRadius: '8px', padding: '10px', overflow: lockScroll ? 'hidden' : 'visible' }}>
                <svg
                    ref={svgRef}
                    width="100%"
                    height={height}
                    viewBox={`0 0 ${width} ${height}`}
                    style={{ overflow: 'visible', cursor: isDragging ? 'grabbing' : 'grab' }}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseLeave}
                >
                    <g transform={transform}>
                        {/* Grid lines - horizontal */}
                        {[0, 0.2, 0.4, 0.6, 0.8, 1].map(p => (
                            <line
                                key={`h-${p}`}
                                x1={padding}
                                y1={padding + p * chartHeight}
                                x2={width - padding}
                                y2={padding + p * chartHeight}
                                stroke="#e0e0e0"
                                strokeWidth="1"
                            />
                        ))}
                        {/* Y-axis labels */}
                        {[0, 0.2, 0.4, 0.6, 0.8, 1].map(p => {
                            const val = maxVal - p * range;
                            return (
                                <text
                                    key={`yl-${p}`}
                                    x={padding - 10}
                                    y={padding + p * chartHeight + 5}
                                    textAnchor="end"
                                    fontSize="11"
                                    fill="#666"
                                >
                                    {val.toFixed(0)}
                                </text>
                            );
                        })}
                        {/* Main lines (split at gaps) */}
                        {polylines.map((lineStr, i) => (
                            <polyline
                                key={`poly-${i}`}
                                points={lineStr}
                                fill="none"
                                stroke="#ff6b6b"
                                strokeWidth="1.5"
                                strokeLinejoin="round"
                                strokeLinecap="round"
                            />
                        ))}
                        {/* Start markers (green circles for complete, orange for chunks) */}
                        {points.filter(p => p.info?.isStart).map((p, i) => (
                            <circle
                                key={`start-${i}`}
                                cx={p.x}
                                cy={p.y}
                                r="5"
                                fill={p.info.isChunk ? "#ff9800" : "#4caf50"}
                                stroke="white"
                                strokeWidth="2"
                            />
                        ))}
                        {/* End markers (blue circles for complete, orange for chunks) */}
                        {points.filter(p => p.info?.isEnd).map((p, i) => (
                            <circle
                                key={`end-${i}`}
                                cx={p.x}
                                cy={p.y}
                                r="5"
                                fill={p.info.isChunk ? "#ff9800" : "#2196f3"}
                                stroke="white"
                                strokeWidth="2"
                            />
                        ))}
                        {/* Hover indicator line */}
                        {hoverData && (
                            <line
                                x1={hoverData.x / zoom.scale - zoom.offsetX / zoom.scale}
                                y1={padding}
                                x2={hoverData.x / zoom.scale - zoom.offsetX / zoom.scale}
                                y2={height - padding}
                                stroke="#666"
                                strokeWidth="1"
                                strokeDasharray="4"
                            />
                        )}
                        {/* Hover indicator circle */}
                        {hoverData && (
                            <circle
                                cx={hoverData.x / zoom.scale - zoom.offsetX / zoom.scale}
                                cy={hoverData.y / zoom.scale - zoom.offsetY / zoom.scale}
                                r="6"
                                fill="#ff6b6b"
                                stroke="white"
                                strokeWidth="2"
                            />
                        )}
                        {/* Legend */}
                        <text x={padding} y={height - 10} fontSize="12" fill="#666">
                            <tspan fill="#4caf50">●</tspan> Complete Start <tspan dx="5" fill="#2196f3">●</tspan> Complete End <tspan dx="5" fill="#ff9800">●</tspan> Chunk
                        </text>
                    </g>
                </svg>
                {/* Tooltip */}
                {hoverData && (
                    <div
                        style={{
                            position: 'fixed',
                            left: hoverData.screenX + 15,
                            top: hoverData.screenY - 10,
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            color: 'white',
                            padding: '8px 12px',
                            borderRadius: '4px',
                            fontSize: '12px',
                            pointerEvents: 'none',
                            zIndex: 1000,
                            whiteSpace: 'nowrap'
                        }}
                    >
                        <div><strong>Value:</strong> {hoverData.value}</div>
                        <div><strong>Time:</strong> {hoverData.info?.time}</div>
                        <div><strong>Type:</strong> {hoverData.info?.isChunk ? 'Chunk' : 'Complete'}</div>
                        <div><strong>Sample Index:</strong> {hoverData.info?.sampleIndex}</div>
                        {hoverData.info?.progress && <div><strong>Progress:</strong> {hoverData.info.progress}</div>}
                    </div>
                )}
            </div>
        </div>
    );
}
