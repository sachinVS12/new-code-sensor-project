function SimpleLineChart({ data, dataKey, color, title }) {
    if (!data || data.length === 0) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                No data yet. Waiting for sensor messages...
            </div>
        );
    }

    const width = 800;
    const height = 300;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    const values = data.map(d => d[dataKey]);
    const minVal = Math.min(...values) - 5;
    const maxVal = Math.max(...values) + 5;
    const range = maxVal - minVal;

    const points = data.map((d, i) => {
        const x = padding + (i / (data.length - 1)) * chartWidth;
        const y = padding + chartHeight - ((d[dataKey] - minVal) / range) * chartHeight;
        return `${x},${y}`;
    }).join(' ');

    return (
        <div>
            <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} style={{ overflow: 'visible' }}>
                {/* Grid lines */}
                {[0, 0.25, 0.5, 0.75, 1].map(p => (
                    <line
                        key={p}
                        x1={padding}
                        y1={padding + p * chartHeight}
                        x2={width - padding}
                        y2={padding + p * chartHeight}
                        stroke="#e0e0e0"
                        strokeWidth="1"
                    />
                ))}
                {/* Y-axis labels */}
                {[0, 0.25, 0.5, 0.75, 1].map(p => {
                    const val = maxVal - p * range;
                    return (
                        <text
                            key={p}
                            x={padding - 10}
                            y={padding + p * chartHeight + 5}
                            textAnchor="end"
                            fontSize="12"
                            fill="#666"
                        >
                            {val.toFixed(1)}
                        </text>
                    );
                })}
                {/* Line */}
                <polyline
                    points={points}
                    fill="none"
                    stroke={color}
                    strokeWidth="2"
                />
                {/* Data points */}
                {data.map((d, i) => {
                    const x = padding + (i / (data.length - 1)) * chartWidth;
                    const y = padding + chartHeight - ((d[dataKey] - minVal) / range) * chartHeight;
                    return (
                        <circle
                            key={i}
                            cx={x}
                            cy={y}
                            r="3"
                            fill={color}
                        />
                    );
                })}
            </svg>
        </div>
    );
}
