// Navbar Component
function Navbar({ isConnected, isCollapsed }) {
    const navbarStyle = {
        height: '60px',
        backgroundColor: '#34495e',
        color: 'white',
        left: isCollapsed ? '60px' : '250px',
        right: '0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 30px',
        position: 'fixed',
        top: 0,
        zIndex: 1000,
        transition: 'left 0.3s ease'
    };

    return (
        <div style={navbarStyle}>
            <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
                Sensor Monitoring System
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ fontSize: '14px' }}>Status:</span>
                <span style={{
                    padding: '5px 15px',
                    borderRadius: '20px',
                    backgroundColor: isConnected ? '#27ae60' : '#e74c3c',
                    fontSize: '12px',
                    fontWeight: 'bold'
                }}>
                    {isConnected ? '● Connected' : '○ Disconnected'}
                </span>
            </div>
        </div>
    );
}
