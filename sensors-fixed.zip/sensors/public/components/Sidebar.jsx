// Sidebar Component
function Sidebar({ currentPage, setCurrentPage, isCollapsed, setIsCollapsed }) {
    const sidebarStyle = {
        width: isCollapsed ? '60px' : '250px',
        height: '100vh',
        backgroundColor: '#2c3e50',
        color: 'white',
        position: 'fixed',
        left: 0,
        top: 0,
        padding: isCollapsed ? '20px 10px' : '20px',
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.3s ease'
    };

    const navItemStyle = {
        padding: '15px',
        marginBottom: '10px',
        borderRadius: '8px',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        justifyContent: isCollapsed ? 'center' : 'flex-start'
    };

    const activeStyle = {
        backgroundColor: '#3498db',
        fontWeight: 'bold'
    };

    const inactiveStyle = {
        backgroundColor: 'transparent'
    };

    const inactiveHoverStyle = {
        backgroundColor: '#34495e'
    };

    const collapseButtonStyle = {
        position: 'absolute',
        right: '10px',
        top: '20px',
        backgroundColor: '#34495e',
        border: 'none',
        color: 'white',
        cursor: 'pointer',
        padding: '5px',
        borderRadius: '4px',
        fontSize: '16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    };

    return (
        <div style={sidebarStyle}>
            {!isCollapsed && (
                <h2 style={{ marginBottom: '30px', fontSize: '20px', borderBottom: '1px solid #34495e', paddingBottom: '15px' }}>
                    LoRaWAN Dashboard
                </h2>
            )}
            
            <button
                style={collapseButtonStyle}
                onClick={() => setIsCollapsed(!isCollapsed)}
            >
                {isCollapsed ? '→' : '←'}
            </button>

            <div style={{ marginTop: isCollapsed ? '50px' : '0' }}>
                <div
                    style={{ ...navItemStyle, ...(currentPage === 'gateway' ? activeStyle : inactiveStyle) }}
                    onClick={() => setCurrentPage('gateway')}
                    onMouseEnter={(e) => currentPage !== 'gateway' && (e.currentTarget.style.backgroundColor = inactiveHoverStyle.backgroundColor)}
                    onMouseLeave={(e) => currentPage !== 'gateway' && (e.currentTarget.style.backgroundColor = inactiveStyle.backgroundColor)}
                    title="Gateway"
                >
                    <span>📡</span>
                    {!isCollapsed && <span>Gateway</span>}
                </div>

                <div
                    style={{ ...navItemStyle, ...(currentPage === 'node-creation' ? activeStyle : inactiveStyle) }}
                    onClick={() => setCurrentPage('node-creation')}
                    onMouseEnter={(e) => currentPage !== 'node-creation' && (e.currentTarget.style.backgroundColor = inactiveHoverStyle.backgroundColor)}
                    onMouseLeave={(e) => currentPage !== 'node-creation' && (e.currentTarget.style.backgroundColor = inactiveStyle.backgroundColor)}
                    title="Device Creation"
                >
                    <span>➕</span>
                    {!isCollapsed && <span>Device Creation</span>}
                </div>

                <div
                    style={{ ...navItemStyle, ...(currentPage === 'tabular' ? activeStyle : inactiveStyle) }}
                    onClick={() => setCurrentPage('tabular')}
                    onMouseEnter={(e) => currentPage !== 'tabular' && (e.currentTarget.style.backgroundColor = inactiveHoverStyle.backgroundColor)}
                    onMouseLeave={(e) => currentPage !== 'tabular' && (e.currentTarget.style.backgroundColor = inactiveStyle.backgroundColor)}
                    title="Tabular View"
                >
                    <span>📊</span>
                    {!isCollapsed && <span>Tabular View</span>}
                </div>

                <div
                    style={{ ...navItemStyle, ...(currentPage === 'graph' ? activeStyle : inactiveStyle) }}
                    onClick={() => setCurrentPage('graph')}
                    onMouseEnter={(e) => currentPage !== 'graph' && (e.currentTarget.style.backgroundColor = inactiveHoverStyle.backgroundColor)}
                    onMouseLeave={(e) => currentPage !== 'graph' && (e.currentTarget.style.backgroundColor = inactiveStyle.backgroundColor)}
                    title="Graph View"
                >
                    <span>📈</span>
                    {!isCollapsed && <span>Graph View</span>}
                </div>

                <div
                    style={{ ...navItemStyle, ...(currentPage === 'downlink' ? activeStyle : inactiveStyle) }}
                    onClick={() => setCurrentPage('downlink')}
                    onMouseEnter={(e) => currentPage !== 'downlink' && (e.currentTarget.style.backgroundColor = inactiveHoverStyle.backgroundColor)}
                    onMouseLeave={(e) => currentPage !== 'downlink' && (e.currentTarget.style.backgroundColor = inactiveStyle.backgroundColor)}
                    title="Downlink"
                >
                    <span>⬇️</span>
                    {!isCollapsed && <span>Downlink</span>}
                </div>
            </div>
        </div>
    );
}
