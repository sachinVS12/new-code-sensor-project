const { useState, useEffect } = React;

function App() {
    const [isConnected, setIsConnected] = useState(false);
    const [sensorData, setSensorData] = useState(null);
    const [rssiHistory, setRssiHistory] = useState([]);
    const [snrHistory, setSnrHistory] = useState([]);
    const [payloadHistory, setPayloadHistory] = useState([]);
    const [error, setError] = useState(null);
    const [messageCount, setMessageCount] = useState(0);
    const [logs, setLogs] = useState([]);
    const [currentPage, setCurrentPage] = useState('graph'); // 'graph', 'tabular', 'node-creation'
    const [isCollapsed, setIsCollapsed] = useState(false);

    // Export payload history to CSV (Excel-compatible)
    const exportToExcel = () => {
        if (!payloadHistory || payloadHistory.length === 0) {
            alert('No payload data to export');
            return;
        }

        let csvContent = 'Timestamp,Entry Type,Average,Min,Max,Battery,Sample Index,Sample Value\n';

        payloadHistory.forEach((payload, payloadIndex) => {
            const entryType = payload.isChunk ? 'Chunk' : 'Complete';
            const samples = payload.samples || [];
            
            samples.forEach((sample, sampleIndex) => {
                csvContent += `${payload.time},${entryType},${payload.avg || ''},${payload.min},${payload.max},${payload.battery || ''},${sampleIndex},${sample}\n`;
            });
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `payload_history_${new Date().toISOString().replace(/[:.]/g, '-')}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    useEffect(() => {
        console.log('Initializing WebSocket connection...');
        console.log('Host:', window.location.host);
        const ws = new WebSocket(`ws://${window.location.host}`);

        ws.onopen = () => {
            console.log('WebSocket connected');
            setIsConnected(true);
            setError(null);
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                
                // Handle log messages
                if (data.type === 'log') {
                    setLogs(prev => {
                        const newLogs = [...prev, { message: data.message, timestamp: new Date().toLocaleTimeString() }];
                        return newLogs.slice(-200); // Keep last 200 logs
                    });
                    return;
                }
                
                console.log('Received data:', data);
                setSensorData(data);
                setMessageCount(prev => prev + 1);

                // Update history for charts (keep last 50 points)
                const timestamp = new Date(data.timestamp).toLocaleTimeString();
                
                setRssiHistory(prev => {
                    const newHistory = [...prev, { time: timestamp, rssi: data.rssi }];
                    console.log('RSSI history:', newHistory);
                    return newHistory.slice(-100);
                });

                setSnrHistory(prev => {
                    const newHistory = [...prev, { time: timestamp, snr: data.snr }];
                    console.log('SNR history:', newHistory);
                    return newHistory.slice(-100);
                });

                // Update payload history if decoded payload exists
                if (data.decodedPayload) {
                    // Handle chunked-dataset format - add chunks as they arrive
                    if (data.decodedPayload.kind === 'chunk' && data.decodedPayload.chunkSamples) {
                        setPayloadHistory(prev => {
                            const newHistory = [...prev, {
                                time: timestamp,
                                samples: data.decodedPayload.chunkSamples,
                                avg: null, // No avg for partial chunk
                                min: Math.min(...data.decodedPayload.chunkSamples),
                                max: Math.max(...data.decodedPayload.chunkSamples),
                                battery: data.decodedPayload.battery || 'N/A',
                                isChunk: true,
                                progress: `${data.decodedPayload.receivedBytes}/${data.decodedPayload.totalBytes} bytes`
                            }];
                            console.log('Payload history (chunk):', newHistory);
                            return newHistory.slice(-100);
                        });
                    }
                    // Handle complete dataset (replace last chunk or add as new)
                    else if (data.decodedPayload.kind === 'dataset' && data.decodedPayload.samples) {
                        setPayloadHistory(prev => {
                            // Remove the chunks that belong to this dataset and add the complete one
                            const newHistory = [...prev];
                            // Keep only non-chunk entries or chunks from other datasets
                            const filtered = newHistory.filter(p => !p.isChunk);
                            const completeEntry = {
                                time: timestamp,
                                samples: data.decodedPayload.samples,
                                avg: data.decodedPayload.avg,
                                min: data.decodedPayload.min,
                                max: data.decodedPayload.max,
                                battery: data.decodedPayload.battery || 'N/A',
                                isChunk: false
                            };
                            filtered.push(completeEntry);
                            console.log('Payload history (dataset complete):', filtered);
                            return filtered.slice(-100);
                        });
                    }
                    // Handle RAK5146 format
                    else if (data.decodedPayload.samples) {
                        setPayloadHistory(prev => {
                            const newHistory = [...prev, {
                                time: timestamp,
                                samples: data.decodedPayload.samples,
                                avg: data.decodedPayload.avg,
                                min: data.decodedPayload.min,
                                max: data.decodedPayload.max,
                                battery: data.decodedPayload.batteryV,
                                isChunk: false
                            }];
                            console.log('Payload history (RAK5146):', newHistory);
                            return newHistory.slice(-100);
                        });
                    }
                }
            } catch (err) {
                console.error('Error parsing message:', err);
                setError('Failed to parse data');
            }
        };

        ws.onclose = () => {
            console.log('WebSocket disconnected');
            setIsConnected(false);
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            setError('WebSocket connection error');
            setIsConnected(false);
        };

        return () => ws.close();
    }, []);

    return (
        <>
            <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
            <Navbar isConnected={isConnected} isCollapsed={isCollapsed} />
            {currentPage === 'gateway' && <GatewayPage isCollapsed={isCollapsed} />}
            {currentPage === 'node-creation' && <NodeCreationPage isCollapsed={isCollapsed} />}
            {currentPage === 'tabular' && <TabularViewPage payloadHistory={payloadHistory} sensorData={sensorData} isCollapsed={isCollapsed} />}
            {currentPage === 'graph' && <GraphViewPage sensorData={sensorData} rssiHistory={rssiHistory} snrHistory={snrHistory} payloadHistory={payloadHistory} error={error} messageCount={messageCount} logs={logs} exportToExcel={exportToExcel} isCollapsed={isCollapsed} />}
        </>
    );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
