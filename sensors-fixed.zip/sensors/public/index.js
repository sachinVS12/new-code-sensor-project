const { useState, useEffect, useRef } = React;

function App() {
    const [isConnected, setIsConnected] = useState(false);
    const [sensorData, setSensorData] = useState(null);
    const [rssiHistory, setRssiHistory] = useState([]);
    const [snrHistory, setSnrHistory] = useState([]);
    const [payloadHistory, setPayloadHistory] = useState([]);
    const [error, setError] = useState(null);
    const [messageCount, setMessageCount] = useState(0);
    const [logs, setLogs] = useState([]);
    const [currentPage, setCurrentPage] = useState('graph'); // 'graph', 'tabular', 'node-creation'
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [topics, setTopics] = useState([]);              // saved device topics for the dropdown
    const [selectedTopic, setSelectedTopic] = useState('all');
    const selectedTopicRef = useRef('all');
    // One row per device for the tabular view - values are overwritten, never appended
    const [deviceRows, setDeviceRows] = useState({});

    // Seed the table with the last saved values so it isn't empty after a refresh
    useEffect(() => {
        fetch('/api/latest')
            .then(r => r.json())
            .then(list => {
                const seeded = {};
                list.forEach(d => {
                    const key = (d.devEui || '').toLowerCase();
                    seeded[key] = {
                        type: d.decodedPayload?.header?.type ?? d.decodedPayload?.type,
                        snr: d.snr,
                        rssi: d.rssi,
                        spreadingFactor: d.spreadingFactor,
                        realtime: d.decodedPayload?.avg ?? null,
                        lastUpdate: Date.parse(d.timestamp),   // ms, for the relative time
                        lastTs: Date.parse(d.timestamp),
                        interval: null
                    };
                });
                setDeviceRows(prev => ({ ...seeded, ...prev }));
            })
            .catch(err => console.error('Error loading latest values:', err));
    }, []);

    // Load saved devices (and their auto-generated MQTT topics) for the dropdown
    const loadTopics = async () => {
        try {
            const res = await fetch('/api/nodes');
            const nodes = await res.json();
            setTopics(nodes.map(n => ({ topic: n.mqttTopic, deviceName: n.deviceName, devEui: n.devEui })));
        } catch (err) {
            console.error('Error loading topics:', err);
        }
    };
    useEffect(() => { loadTopics(); }, [currentPage]);

    // Selecting a topic shows only that device's data; start with fresh charts
    const handleSelectTopic = (topic) => {
        selectedTopicRef.current = topic;
        setSelectedTopic(topic);
        setSensorData(null);
        setRssiHistory([]);
        setSnrHistory([]);
        setPayloadHistory([]);
        setMessageCount(0);
    };

    // Export payload history to CSV (Excel-compatible)
    const exportToExcel = () => {
        if (!payloadHistory || payloadHistory.length === 0) {
            alert('No payload data to export');
            return;
        }

        let csvContent = 'Timestamp,Entry Type,Average,Min,Max,Battery,Sample Index,Sample Value\n';

        payloadHistory.forEach((payload, payloadIndex) => {
            const entryType = payload.isChunk ? 'Chunk' : 'Complete';
            const samples = payload.samples || [];
            
            samples.forEach((sample, sampleIndex) => {
                csvContent += `${payload.time},${entryType},${payload.avg || ''},${payload.min},${payload.max},${payload.battery || ''},${sampleIndex},${sample}\n`;
            });
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `payload_history_${new Date().toISOString().replace(/[:.]/g, '-')}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    useEffect(() => {
        console.log('Initializing WebSocket connection...');
        console.log('Host:', window.location.host);
        const ws = new WebSocket(`${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}`);

        ws.onopen = () => {
            console.log('WebSocket connected');
            setIsConnected(true);
            setError(null);
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                
                // Handle log messages
                if (data.type === 'log') {
                    setLogs(prev => {
                        const newLogs = [...prev, { message: data.message, timestamp: new Date().toLocaleTimeString() }];
                        return newLogs.slice(-200); // Keep last 200 logs
                    });
                    return;
                }
                
                // Update that device's single table row in place (all devices, regardless of dropdown)
                const rowKey = (data.devEui || '').toLowerCase();
                setDeviceRows(prev => {
                    const old = prev[rowKey] || {};
                    // seconds between this uplink and the previous one from the same device
                    const ts = Date.parse(data.timestamp) || Date.now();
                    const gap = old.lastTs ? (ts - old.lastTs) / 1000 : null;
                    return {
                        ...prev,
                        [rowKey]: {
                            // packet type: chunk devices send it in the header, others in decodedPayload.type
                            type: data.decodedPayload?.header?.type ?? data.decodedPayload?.type ?? old.type,
                            snr: data.snr ?? old.snr,
                            rssi: data.rssi ?? old.rssi,
                            spreadingFactor: data.spreadingFactor ?? old.spreadingFactor,
                            // chunks carry no average - keep the last complete value until a new one arrives
                            realtime: data.decodedPayload?.avg ?? old.realtime ?? null,
                            lastUpdate: Date.now(),
                            lastTs: ts,
                            interval: gap !== null && gap >= 0 ? Math.round(gap * 10) / 10 : (old.interval ?? null)
                        }
                    };
                });

                // Only use data from the selected MQTT topic ('all' = every saved device)
                if (selectedTopicRef.current !== 'all' && data.topic !== selectedTopicRef.current) return;

                console.log('Received data:', data);
                setSensorData(data);
                setMessageCount(prev => prev + 1);

                // Update history for charts (keep last 50 points)
                const timestamp = new Date(data.timestamp).toLocaleTimeString();
                
                setRssiHistory(prev => {
                    const newHistory = [...prev, { time: timestamp, rssi: data.rssi }];
                    console.log('RSSI history:', newHistory);
                    return newHistory.slice(-100);
                });

                setSnrHistory(prev => {
                    const newHistory = [...prev, { time: timestamp, snr: data.snr }];
                    console.log('SNR history:', newHistory);
                    return newHistory.slice(-100);
                });

                // Update payload history if decoded payload exists
                if (data.decodedPayload) {
                    // Handle chunked-dataset format - add chunks as they arrive
                    if (data.decodedPayload.kind === 'chunk' && data.decodedPayload.chunkSamples) {
                        setPayloadHistory(prev => {
                            const newHistory = [...prev, {
                                time: timestamp,
                                samples: data.decodedPayload.chunkSamples,
                                avg: null, // No avg for partial chunk
                                min: Math.min(...data.decodedPayload.chunkSamples),
                                max: Math.max(...data.decodedPayload.chunkSamples),
                                battery: data.decodedPayload.battery || 'N/A',
                                isChunk: true,
                                progress: `${data.decodedPayload.receivedBytes}/${data.decodedPayload.totalBytes} bytes`
                            }];
                            console.log('Payload history (chunk):', newHistory);
                            return newHistory.slice(-100);
                        });
                    }
                    // Handle complete dataset (replace last chunk or add as new)
                    else if (data.decodedPayload.kind === 'dataset' && data.decodedPayload.samples) {
                        setPayloadHistory(prev => {
                            // Remove the chunks that belong to this dataset and add the complete one
                            const newHistory = [...prev];
                            // Keep only non-chunk entries or chunks from other datasets
                            const filtered = newHistory.filter(p => !p.isChunk);
                            const completeEntry = {
                                time: timestamp,
                                samples: data.decodedPayload.samples,
                                avg: data.decodedPayload.avg,
                                min: data.decodedPayload.min,
                                max: data.decodedPayload.max,
                                battery: data.decodedPayload.battery || 'N/A',
                                isChunk: false
                            };
                            filtered.push(completeEntry);
                            console.log('Payload history (dataset complete):', filtered);
                            return filtered.slice(-100);
                        });
                    }
                    // Handle RAK5146 format
                    else if (data.decodedPayload.samples) {
                        setPayloadHistory(prev => {
                            const newHistory = [...prev, {
                                time: timestamp,
                                samples: data.decodedPayload.samples,
                                avg: data.decodedPayload.avg,
                                min: data.decodedPayload.min,
                                max: data.decodedPayload.max,
                                battery: data.decodedPayload.batteryV,
                                isChunk: false
                            }];
                            console.log('Payload history (RAK5146):', newHistory);
                            return newHistory.slice(-100);
                        });
                    }
                }
            } catch (err) {
                console.error('Error parsing message:', err);
                setError('Failed to parse data');
            }
        };

        ws.onclose = () => {
            console.log('WebSocket disconnected');
            setIsConnected(false);
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            setError('WebSocket connection error');
            setIsConnected(false);
        };

        return () => ws.close();
    }, []);

    return (
        <>
            <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
            <Navbar isConnected={isConnected} isCollapsed={isCollapsed} />
            {currentPage === 'gateway' && <GatewayPage isCollapsed={isCollapsed} />}
            {currentPage === 'node-creation' && <NodeCreationPage isCollapsed={isCollapsed} />}
            {currentPage === 'tabular' && <TabularViewPage devices={topics} deviceRows={deviceRows} isCollapsed={isCollapsed} />}
            {currentPage === 'graph' && <GraphViewPage sensorData={sensorData} rssiHistory={rssiHistory} snrHistory={snrHistory} payloadHistory={payloadHistory} error={error} messageCount={messageCount} logs={logs} exportToExcel={exportToExcel} isCollapsed={isCollapsed} topics={topics} selectedTopic={selectedTopic} onSelectTopic={handleSelectTopic} />}
        </>
    );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
