// Dashboard page - opens first after every reload.
// Shows active / offline gateways, totals, charts and the gateway list. Data: GET /api/dashboard

const DASH_GREEN = '#27ae60';
const DASH_RED = '#e74c3c';
const DASH_BLUE = '#3498db';

function dashTimeAgo(iso) {
    if (!iso) return 'Never';
    const sec = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
    if (sec < 60) return `${sec}s ago`;
    if (sec < 3600) return `${Math.floor(sec / 60)} min ago`;
    if (sec < 86400) return `${Math.floor(sec / 3600)} h ago`;
    return `${Math.floor(sec / 86400)} d ago`;
}

// ---- Donut: active vs offline gateways ----
function DashDonut({ active, offline }) {
    const total = active + offline;
    const r = 70;
    const c = 2 * Math.PI * r;
    const activeLen = total ? (active / total) * c : 0;
    const offlineLen = total ? (offline / total) * c : 0;
    return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '28px', flexWrap: 'wrap' }}>
            <svg width="190" height="190" viewBox="0 0 200 200" role="img" aria-label={`${active} active, ${offline} offline gateways`}>
                <g transform="rotate(-90 100 100)">
                    <circle cx="100" cy="100" r={r} fill="none" stroke="#ecf0f1" strokeWidth="26" />
                    {activeLen > 0 && (
                        <circle cx="100" cy="100" r={r} fill="none" stroke={DASH_GREEN} strokeWidth="26"
                            strokeDasharray={`${activeLen} ${c - activeLen}`} strokeDashoffset="0" />
                    )}
                    {offlineLen > 0 && (
                        <circle cx="100" cy="100" r={r} fill="none" stroke={DASH_RED} strokeWidth="26"
                            strokeDasharray={`${offlineLen} ${c - offlineLen}`} strokeDashoffset={-activeLen} />
                    )}
                </g>
                <text x="100" y="98" textAnchor="middle" fontSize="32" fontWeight="bold" fill="#2c3e50">{total}</text>
                <text x="100" y="120" textAnchor="middle" fontSize="13" fill="#888">gateways</text>
            </svg>
            <div style={{ fontSize: '14px', color: '#333' }}>
                <div style={{ marginBottom: '10px' }}>
                    <span style={{ display: 'inline-block', width: '12px', height: '12px', borderRadius: '3px', backgroundColor: DASH_GREEN, marginRight: '8px' }} />
                    Active: <strong>{active}</strong>
                </div>
                <div>
                    <span style={{ display: 'inline-block', width: '12px', height: '12px', borderRadius: '3px', backgroundColor: DASH_RED, marginRight: '8px' }} />
                    Offline: <strong>{offline}</strong>
                </div>
            </div>
        </div>
    );
}

// ---- Line / area chart: uplinks per hour (last 24 h) ----
function DashAreaChart({ points }) {
    const width = 600, height = 250, left = 42, right = 14, top = 14, bottom = 34;
    const cw = width - left - right, ch = height - top - bottom;
    const maxCount = Math.max(1, ...points.map(p => p.count));
    const xAt = (i) => left + (points.length > 1 ? i / (points.length - 1) : 0.5) * cw;
    const yAt = (v) => top + ch - (v / maxCount) * ch;
    const line = points.map((p, i) => `${xAt(i)},${yAt(p.count)}`).join(' ');
    const area = `${left},${top + ch} ${line} ${left + cw},${top + ch}`;
    const ticks = [...new Set([0, 0.25, 0.5, 0.75, 1].map(f => Math.round(f * maxCount)))];
    const hourLabel = (iso) => `${String(new Date(iso).getHours()).padStart(2, '0')}:00`;
    return (
        <svg width="100%" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Uplinks per hour">
            {ticks.map(t => (
                <g key={t}>
                    <line x1={left} x2={left + cw} y1={yAt(t)} y2={yAt(t)} stroke="#eee" />
                    <text x={left - 6} y={yAt(t) + 4} textAnchor="end" fontSize="11" fill="#888">{t}</text>
                </g>
            ))}
            <polygon points={area} fill="rgba(52,152,219,0.15)" />
            <polyline points={line} fill="none" stroke={DASH_BLUE} strokeWidth="2.5" strokeLinejoin="round" />
            {points.map((p, i) => (
                <circle key={p.hour} cx={xAt(i)} cy={yAt(p.count)} r="3.5" fill={DASH_BLUE}>
                    <title>{`${hourLabel(p.hour)} - ${p.count} uplink(s)`}</title>
                </circle>
            ))}
            {points.map((p, i) => (i % 4 === 0 || i === points.length - 1) && (
                <text key={`x${p.hour}`} x={xAt(i)} y={height - 12} textAnchor="middle" fontSize="11" fill="#888">{hourLabel(p.hour)}</text>
            ))}
        </svg>
    );
}

// ---- Bar chart (vertical) ----
function DashBarChart({ items, emptyText }) {
    if (!items.length) {
        return <div style={{ padding: '60px 0', textAlign: 'center', color: '#999', fontSize: '14px' }}>{emptyText}</div>;
    }
    const width = 600, height = 250, left = 42, right = 14, top = 22, bottom = 40;
    const cw = width - left - right, ch = height - top - bottom;
    const maxVal = Math.max(1, ...items.map(i => i.value));
    const slot = cw / items.length;
    const barW = Math.min(64, slot * 0.6);
    const yAt = (v) => top + ch - (v / maxVal) * ch;
    const ticks = [...new Set([0, 0.5, 1].map(f => Math.round(f * maxVal)))];
    const short = (t) => (t.length > 12 ? t.slice(0, 11) + '…' : t);
    return (
        <svg width="100%" viewBox={`0 0 ${width} ${height}`} role="img">
            {ticks.map(t => (
                <g key={t}>
                    <line x1={left} x2={left + cw} y1={yAt(t)} y2={yAt(t)} stroke="#eee" />
                    <text x={left - 6} y={yAt(t) + 4} textAnchor="end" fontSize="11" fill="#888">{t}</text>
                </g>
            ))}
            {items.map((it, i) => {
                const cx = left + slot * i + slot / 2;
                return (
                    <g key={it.label + i}>
                        <rect x={cx - barW / 2} y={yAt(it.value)} width={barW} height={top + ch - yAt(it.value)} rx="3" fill={it.color || DASH_BLUE}>
                            <title>{`${it.label}: ${it.value}`}</title>
                        </rect>
                        <text x={cx} y={yAt(it.value) - 6} textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2c3e50">{it.value}</text>
                        <text x={cx} y={height - 16} textAnchor="middle" fontSize="12" fill="#555">{short(it.label)}</text>
                    </g>
                );
            })}
        </svg>
    );
}

function DashboardPage({ isCollapsed }) {
    const [data, setData] = React.useState(null);
    const [error, setError] = React.useState('');

    const load = async () => {
        try {
            const res = await fetch('/api/dashboard');
            if (!res.ok) throw new Error('Failed to load dashboard');
            setData(await res.json());
            setError('');
        } catch (err) {
            setError(err.message);
        }
    };

    // load now, then refresh every 10 s while this page is open
    React.useEffect(() => {
        load();
        const t = setInterval(load, 10000);
        return () => clearInterval(t);
    }, []);

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '22px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const thStyle = { padding: '12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '12px', borderBottom: '1px solid #eee', fontSize: '14px' };

    const statCard = (label, value, color) => (
        <div style={{ ...cardStyle, borderTop: `4px solid ${color}` }}>
            <div style={{ fontSize: '13px', color: '#777', marginBottom: '8px' }}>{label}</div>
            <div style={{ fontSize: '34px', fontWeight: 'bold', color: '#2c3e50' }}>{value}</div>
        </div>
    );

    const badge = (status) => (
        <span style={{
            backgroundColor: status === 'active' ? '#e8f5e9' : '#fce8e6',
            color: status === 'active' ? '#2e7d32' : '#c62828',
            padding: '3px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold'
        }}>{status === 'active' ? 'Active' : 'Offline'}</span>
    );

    if (!data) {
        return (
            <div style={pageStyle}>
                <h2 style={{ marginBottom: '20px' }}>Dashboard</h2>
                {error ? <p style={{ color: '#c62828' }}>{error}</p> : <p style={{ color: '#888' }}>Loading...</p>}
            </div>
        );
    }

    const t = data.totals;
    const d = data.downlinkByStatus;

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '6px' }}>Dashboard</h2>
            <p style={{ fontSize: '12px', color: '#888', marginBottom: '20px' }}>
                Updated {new Date(data.generatedAt).toLocaleTimeString()} - refreshes every 10 seconds. A gateway counts as active
                if it forwarded an uplink in the last {data.activeMinutes} minutes.
            </p>
            {error && <p style={{ color: '#c62828', marginBottom: '12px' }}>{error}</p>}

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '16px', marginBottom: '20px' }}>
                {statCard('Active gateways', t.active, DASH_GREEN)}
                {statCard('Offline gateways', t.offline, DASH_RED)}
                {statCard('Total gateways', t.gateways, '#7f8c8d')}
                {statCard('Devices', t.devices, '#9b59b6')}
                {statCard('Uplinks (24 h)', t.uplinks24h, DASH_BLUE)}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))', gap: '16px', marginBottom: '20px' }}>
                <div style={cardStyle}>
                    <h3 style={{ marginBottom: '14px', fontSize: '16px' }}>Gateway status</h3>
                    <DashDonut active={t.active} offline={t.offline} />
                </div>
                <div style={cardStyle}>
                    <h3 style={{ marginBottom: '14px', fontSize: '16px' }}>Uplinks per hour (last 24 h)</h3>
                    <DashAreaChart points={data.uplinksPerHour} />
                </div>
                <div style={cardStyle}>
                    <h3 style={{ marginBottom: '14px', fontSize: '16px' }}>Uplinks per gateway (last 24 h)</h3>
                    <DashBarChart items={data.uplinksPerGateway} emptyText="No gateways yet" />
                </div>
                <div style={cardStyle}>
                    <h3 style={{ marginBottom: '14px', fontSize: '16px' }}>Downlinks by status</h3>
                    <DashBarChart
                        items={[
                            { label: 'Queued', value: d.queued, color: '#e65100' },
                            { label: 'Transmitted', value: d.transmitted, color: '#1565c0' },
                            { label: 'Acknowledged', value: d.acknowledged, color: DASH_GREEN },
                            { label: 'Failed', value: d.failed, color: DASH_RED }
                        ]}
                    />
                </div>
            </div>

            <div style={cardStyle}>
                <h3 style={{ marginBottom: '14px', fontSize: '16px' }}>Gateways</h3>
                <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                            <tr>
                                <th style={thStyle}>Name</th>
                                <th style={thStyle}>Gateway EUI</th>
                                <th style={thStyle}>Mode</th>
                                <th style={thStyle}>Last uplink</th>
                                <th style={thStyle}>Uplinks (24 h)</th>
                                <th style={thStyle}>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.gateways.length === 0 ? (
                                <tr><td colSpan="6" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>No gateways yet - add one in the Gateway page</td></tr>
                            ) : data.gateways.map((g, i) => (
                                <tr key={g.id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                    <td style={tdStyle}>{g.name}</td>
                                    <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{g.eui}</td>
                                    <td style={tdStyle}>{g.mode}</td>
                                    <td style={tdStyle} title={g.lastSeen ? new Date(g.lastSeen).toLocaleString() : ''}>{dashTimeAgo(g.lastSeen)}</td>
                                    <td style={tdStyle}>{g.uplinks24h}</td>
                                    <td style={tdStyle}>{badge(g.status)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
