// Downlink page - two tabs: "Feed Data" (send a downlink) and "Queue" (what was sent + status)
function DownlinkPage({ devices = [], isCollapsed }) {
    const [tab, setTab] = React.useState('feed');

    // ---- Feed Data form ----
    const [devEui, setDevEui] = React.useState('');
    const [fPort, setFPort] = React.useState('1');
    const [format, setFormat] = React.useState('hex');
    const [data, setData] = React.useState('');
    const [confirmed, setConfirmed] = React.useState(false);
    const [sending, setSending] = React.useState(false);
    const [feedback, setFeedback] = React.useState(null);   // { type: 'ok' | 'error', text }

    // ---- Queue ----
    const [queue, setQueue] = React.useState([]);
    const [queueDevice, setQueueDevice] = React.useState('all');
    const [queueError, setQueueError] = React.useState('');

    const loadQueue = async () => {
        try {
            const url = queueDevice === 'all' ? '/api/downlinks' : `/api/downlinks?devEui=${queueDevice}`;
            const res = await fetch(url);
            if (!res.ok) throw new Error('Failed to load queue');
            setQueue(await res.json());
            setQueueError('');
        } catch (err) {
            setQueueError(err.message);
        }
    };

    // refresh the queue every 3 s while its tab is open
    React.useEffect(() => {
        if (tab !== 'queue') return;
        loadQueue();
        const t = setInterval(loadQueue, 3000);
        return () => clearInterval(t);
    }, [tab, queueDevice]);

    const handleSend = async () => {
        setFeedback(null);
        if (!devEui) return setFeedback({ type: 'error', text: 'Select a device' });
        if (!data.trim()) return setFeedback({ type: 'error', text: 'Enter the data to send' });

        setSending(true);
        try {
            const res = await fetch('/api/downlinks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ devEui, fPort: Number(fPort), confirmed, format, data })
            });
            const body = await res.json();
            if (!res.ok) throw new Error(body.error || 'Failed to send downlink');
            setData('');
            setFeedback({ type: 'ok', text: 'Downlink added to the queue. ChirpStack sends it after the device\'s next uplink.' });
        } catch (err) {
            setFeedback({ type: 'error', text: err.message });
        } finally {
            setSending(false);
        }
    };

    const handleRemove = async (id) => {
        if (!confirm('Remove this entry from the list?\n(This does not clear ChirpStack\'s own device queue.)')) return;
        try {
            await fetch(`/api/downlinks/${id}`, { method: 'DELETE' });
            loadQueue();
        } catch (err) {
            setQueueError('Failed to remove entry');
        }
    };

    // ---- styles ----
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold', color: '#333', fontSize: '14px' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const tabBtn = (active) => ({
        padding: '10px 24px', cursor: 'pointer', border: 'none', fontSize: '15px',
        borderBottom: active ? '3px solid #3498db' : '3px solid transparent',
        backgroundColor: 'transparent', color: active ? '#3498db' : '#555', fontWeight: active ? 'bold' : 'normal'
    });
    const thStyle = { padding: '12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '12px', borderBottom: '1px solid #eee', fontSize: '14px' };

    const statusBadge = (status) => {
        const map = {
            queued: { bg: '#fff3e0', fg: '#e65100', label: 'Queued' },
            transmitted: { bg: '#e3f2fd', fg: '#1565c0', label: 'Transmitted' },
            acknowledged: { bg: '#e8f5e9', fg: '#2e7d32', label: 'Acknowledged' },
            failed: { bg: '#fce8e6', fg: '#c62828', label: 'Failed' }
        };
        const m = map[status] || { bg: '#eee', fg: '#333', label: status };
        return <span style={{ backgroundColor: m.bg, color: m.fg, padding: '3px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>{m.label}</span>;
    };

    const pending = queue.filter(q => q.status === 'queued').length;

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Downlink</h2>

            <div style={{ borderBottom: '1px solid #ddd', marginBottom: '20px' }}>
                <button style={tabBtn(tab === 'feed')} onClick={() => setTab('feed')}>Feed Data</button>
                <button style={tabBtn(tab === 'queue')} onClick={() => setTab('queue')}>
                    Queue{tab === 'queue' && pending > 0 ? ` (${pending} waiting)` : ''}
                </button>
            </div>

            {tab === 'feed' && (
                <div style={{ ...cardStyle, maxWidth: '640px' }}>
                    <div style={{ marginBottom: '18px' }}>
                        <label style={labelStyle}>Device</label>
                        <select style={inputStyle} value={devEui} onChange={(e) => setDevEui(e.target.value)}>
                            <option value="">Select device</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName} ({d.devEui})</option>
                            ))}
                        </select>
                        {devices.length === 0 && (
                            <p style={{ fontSize: '12px', color: '#888', margin: '6px 0 0' }}>No devices yet - create one in Device Creation first.</p>
                        )}
                    </div>

                    <div style={{ display: 'flex', gap: '15px', marginBottom: '18px' }}>
                        <div style={{ flex: 1 }}>
                            <label style={labelStyle}>FPort (1-223)</label>
                            <input style={inputStyle} type="number" min="1" max="223" value={fPort} onChange={(e) => setFPort(e.target.value)} />
                        </div>
                        <div style={{ flex: 1 }}>
                            <label style={labelStyle}>Data format</label>
                            <select style={inputStyle} value={format} onChange={(e) => setFormat(e.target.value)}>
                                <option value="hex">Hex</option>
                                <option value="text">Text</option>
                                <option value="base64">Base64</option>
                            </select>
                        </div>
                    </div>

                    <div style={{ marginBottom: '18px' }}>
                        <label style={labelStyle}>Data</label>
                        <textarea
                            style={{ ...inputStyle, minHeight: '90px', fontFamily: 'monospace' }}
                            value={data}
                            onChange={(e) => setData(e.target.value)}
                            placeholder={format === 'hex' ? 'e.g. 01 02 FF' : format === 'text' ? 'e.g. hello' : 'e.g. AQL/'}
                        />
                    </div>

                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '20px', fontSize: '14px', cursor: 'pointer' }}>
                        <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
                        Confirmed downlink (device must acknowledge)
                    </label>

                    {feedback && (
                        <div style={{
                            padding: '10px 14px', borderRadius: '6px', marginBottom: '16px', fontSize: '14px',
                            backgroundColor: feedback.type === 'ok' ? '#e8f5e9' : '#fce8e6',
                            color: feedback.type === 'ok' ? '#2e7d32' : '#c62828'
                        }}>
                            {feedback.text}
                            {feedback.type === 'ok' && (
                                <button onClick={() => setTab('queue')} style={{ marginLeft: '10px', background: 'none', border: 'none', color: '#1565c0', cursor: 'pointer', textDecoration: 'underline', fontSize: '14px' }}>
                                    View queue
                                </button>
                            )}
                        </div>
                    )}

                    <button
                        onClick={handleSend}
                        disabled={sending}
                        style={{ padding: '11px 28px', backgroundColor: sending ? '#95a5a6' : '#3498db', color: 'white', border: 'none', borderRadius: '6px', fontSize: '15px', fontWeight: 'bold', cursor: sending ? 'default' : 'pointer' }}
                    >
                        {sending ? 'Sending...' : 'Send Downlink'}
                    </button>
                </div>
            )}

            {tab === 'queue' && (
                <div style={cardStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
                        <label style={{ fontWeight: 'bold', color: '#333' }}>Device</label>
                        <select style={{ ...inputStyle, width: 'auto', minWidth: '240px' }} value={queueDevice} onChange={(e) => setQueueDevice(e.target.value)}>
                            <option value="all">All devices</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName}</option>
                            ))}
                        </select>
                        <button onClick={loadQueue} style={{ padding: '8px 16px', border: '1px solid #3498db', color: '#3498db', backgroundColor: 'white', borderRadius: '6px', cursor: 'pointer' }}>
                            Refresh
                        </button>
                        <span style={{ fontSize: '12px', color: '#888' }}>Updates every 3 seconds</span>
                    </div>

                    {queueError && <p style={{ color: '#c62828' }}>{queueError}</p>}

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Time</th>
                                    <th style={thStyle}>Device</th>
                                    <th style={thStyle}>FPort</th>
                                    <th style={thStyle}>Confirmed</th>
                                    <th style={thStyle}>Data (hex)</th>
                                    <th style={thStyle}>Status</th>
                                    <th style={{ ...thStyle, textAlign: 'center' }}>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                {queue.length === 0 ? (
                                    <tr><td colSpan="7" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>Queue is empty</td></tr>
                                ) : queue.map((q, i) => (
                                    <tr key={q._id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                        <td style={tdStyle}>{new Date(q.createdAt).toLocaleString()}</td>
                                        <td style={tdStyle}>{q.deviceName || q.devEui}</td>
                                        <td style={tdStyle}>{q.fPort}</td>
                                        <td style={tdStyle}>{q.confirmed ? 'Yes' : 'No'}</td>
                                        <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{q.dataHex || q.data}</td>
                                        <td style={tdStyle}>{statusBadge(q.status)}</td>
                                        <td style={{ ...tdStyle, textAlign: 'center' }}>
                                            <button
                                                onClick={() => handleRemove(q._id)}
                                                title="Remove from list"
                                                aria-label="Remove from list"
                                                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#c62828', fontSize: '16px' }}
                                            >✕</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}
