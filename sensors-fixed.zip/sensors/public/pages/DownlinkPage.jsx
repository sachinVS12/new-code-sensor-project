// Downlink page - two tabs: "Feed Data" (empty) and "Queue" (the send form).
// What was sent and its status is on the Task page.
function DownlinkPage({ devices = [], isCollapsed, onOpenTask }) {
    const [tab, setTab] = React.useState('feed');

    // ---- Feed Data form ----
    const [devEui, setDevEui] = React.useState('');
    const [fPort, setFPort] = React.useState('1');
    const [format, setFormat] = React.useState('hex');
    const [data, setData] = React.useState('');
    const [confirmed, setConfirmed] = React.useState(false);
    const [sending, setSending] = React.useState(false);
    const [feedback, setFeedback] = React.useState(null);   // { type: 'ok' | 'error', text }

    const handleSend = async () => {
        setFeedback(null);
        if (!devEui) return setFeedback({ type: 'error', text: 'Select a device' });
        if (!data.trim()) return setFeedback({ type: 'error', text: 'Enter the data to send' });

        setSending(true);
        try {
            const res = await fetch('/api/downlinks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ devEui, fPort: Number(fPort), confirmed, format, data })
            });
            const body = await res.json();
            if (!res.ok) throw new Error(body.error || 'Failed to send downlink');
            setData('');
            setFeedback({ type: 'ok', text: 'Downlink added to the queue. ChirpStack sends it after the device\'s next uplink.' });
        } catch (err) {
            setFeedback({ type: 'error', text: err.message });
        } finally {
            setSending(false);
        }
    };

    // ---- styles ----
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold', color: '#333', fontSize: '14px' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const tabBtn = (active) => ({
        padding: '10px 24px', cursor: 'pointer', border: 'none', fontSize: '15px',
        borderBottom: active ? '3px solid #3498db' : '3px solid transparent',
        backgroundColor: 'transparent', color: active ? '#3498db' : '#555', fontWeight: active ? 'bold' : 'normal'
    });

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Downlink</h2>

            <div style={{ borderBottom: '1px solid #ddd', marginBottom: '20px' }}>
                <button style={tabBtn(tab === 'feed')} onClick={() => setTab('feed')}>Feed Data</button>
                <button style={tabBtn(tab === 'queue')} onClick={() => setTab('queue')}>Queue</button>
            </div>

            {/* Feed Data tab: intentionally empty */}

            {tab === 'queue' && (
                <div style={{ ...cardStyle, maxWidth: '640px' }}>
                    <div style={{ marginBottom: '18px' }}>
                        <label style={labelStyle}>Device</label>
                        <select style={inputStyle} value={devEui} onChange={(e) => setDevEui(e.target.value)}>
                            <option value="">Select device</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName} ({d.devEui})</option>
                            ))}
                        </select>
                        {devices.length === 0 && (
                            <p style={{ fontSize: '12px', color: '#888', margin: '6px 0 0' }}>No devices yet - create one in Device Creation first.</p>
                        )}
                    </div>

                    <div style={{ display: 'flex', gap: '15px', marginBottom: '18px' }}>
                        <div style={{ flex: 1 }}>
                            <label style={labelStyle}>FPort (1-223)</label>
                            <input style={inputStyle} type="number" min="1" max="223" value={fPort} onChange={(e) => setFPort(e.target.value)} />
                        </div>
                        <div style={{ flex: 1 }}>
                            <label style={labelStyle}>Data format</label>
                            <select style={inputStyle} value={format} onChange={(e) => setFormat(e.target.value)}>
                                <option value="hex">Hex</option>
                                <option value="text">Text</option>
                                <option value="base64">Base64</option>
                            </select>
                        </div>
                    </div>

                    <div style={{ marginBottom: '18px' }}>
                        <label style={labelStyle}>Data</label>
                        <textarea
                            style={{ ...inputStyle, minHeight: '90px', fontFamily: 'monospace' }}
                            value={data}
                            onChange={(e) => setData(e.target.value)}
                            placeholder={format === 'hex' ? 'e.g. 01 02 FF' : format === 'text' ? 'e.g. hello' : 'e.g. AQL/'}
                        />
                    </div>

                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '20px', fontSize: '14px', cursor: 'pointer' }}>
                        <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
                        Confirmed downlink (device must acknowledge)
                    </label>

                    {feedback && (
                        <div style={{
                            padding: '10px 14px', borderRadius: '6px', marginBottom: '16px', fontSize: '14px',
                            backgroundColor: feedback.type === 'ok' ? '#e8f5e9' : '#fce8e6',
                            color: feedback.type === 'ok' ? '#2e7d32' : '#c62828'
                        }}>
                            {feedback.text}
                            {feedback.type === 'ok' && (
                                <button onClick={() => onOpenTask && onOpenTask()} style={{ marginLeft: '10px', background: 'none', border: 'none', color: '#1565c0', cursor: 'pointer', textDecoration: 'underline', fontSize: '14px' }}>
                                    View in Task
                                </button>
                            )}
                        </div>
                    )}

                    <button
                        onClick={handleSend}
                        disabled={sending}
                        style={{ padding: '11px 28px', backgroundColor: sending ? '#95a5a6' : '#3498db', color: 'white', border: 'none', borderRadius: '6px', fontSize: '15px', fontWeight: 'bold', cursor: sending ? 'default' : 'pointer' }}
                    >
                        {sending ? 'Sending...' : 'Send Downlink'}
                    </button>
                </div>
            )}

        </div>
    );
}
