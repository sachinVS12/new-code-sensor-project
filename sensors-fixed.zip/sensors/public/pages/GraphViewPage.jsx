// Graph View Page Component
function GraphViewPage({ sensorData, rssiHistory, snrHistory, payloadHistory, error, messageCount, logs, exportToExcel, isCollapsed, topics = [], selectedTopic = 'all', onSelectTopic }) {
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };

    return (
        <div style={pageStyle}>
            <div style={{ backgroundColor: 'white', padding: '15px 20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                <label style={{ fontWeight: 'bold', color: '#333' }}>MQTT Topic</label>
                <select
                    value={selectedTopic}
                    onChange={(e) => onSelectTopic && onSelectTopic(e.target.value)}
                    style={{ padding: '8px 12px', borderRadius: '4px', border: '1px solid #ddd', minWidth: '320px', maxWidth: '100%' }}
                >
                    <option value="all">All devices</option>
                    {topics.map((t) => (
                        <option key={t.topic} value={t.topic}>
                            {t.deviceName} - {t.topic}
                        </option>
                    ))}
                </select>
                <span style={{ fontSize: '12px', color: '#666' }}>
                    {selectedTopic === 'all' ? 'Showing data from every saved device' : 'Showing data from the selected topic only'}
                </span>
            </div>

            <div style={{ marginBottom: '20px', fontSize: '12px', color: '#666' }}>
                Messages received: {messageCount} | RSSI points: {rssiHistory.length} | SNR points: {snrHistory.length} | Payloads: {payloadHistory.length} | Total samples: {payloadHistory.reduce((sum, p) => sum + (p.samples?.length || 0), 0)}
            </div>

            {!sensorData && !error && (
                <div className="card" style={{ textAlign: 'center', padding: '40px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                    <h2>Waiting for sensor data...</h2>
                    <p style={{ color: '#666', marginTop: '10px' }}>
                        Connected to WebSocket. Waiting for device uplinks...
                    </p>
                </div>
            )}

            {sensorData && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '30px' }}>
                    <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                        <h3 style={{ margin: '0 0 10px 0', color: '#666', fontSize: '14px' }}>Device</h3>
                        <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#333' }}>{sensorData.deviceName}</div>
                    </div>
                    <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                        <h3 style={{ margin: '0 0 10px 0', color: '#666', fontSize: '14px' }}>RSSI</h3>
                        <div className="metric-value">{sensorData.rssi} dBm</div>
                    </div>
                    <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                        <h3 style={{ margin: '0 0 10px 0', color: '#666', fontSize: '14px' }}>SNR</h3>
                        <div className="metric-value">{sensorData.snr} dB</div>
                    </div>
                    <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}>
                        <h3 style={{ margin: '0 0 10px 0', color: '#666', fontSize: '14px' }}>Last Update</h3>
                        <div className="metric-value">{new Date(sensorData.timestamp).toLocaleString()}</div>
                    </div>
                </div>
            )}

            <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
                <h2 style={{ margin: '0 0 15px 0' }}>RSSI History (dBm)</h2>
                <SimpleLineChart data={rssiHistory} dataKey="rssi" color="#8884d8" />
            </div>

            <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
                <h2 style={{ margin: '0 0 15px 0' }}>SNR History (dB)</h2>
                <SimpleLineChart data={snrHistory} dataKey="snr" color="#82ca9d" />
            </div>

            <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                    <h2 style={{ margin: 0 }}>Payload Samples History (with gaps)</h2>
                    <button
                        onClick={exportToExcel}
                        style={{
                            padding: '8px 16px',
                            backgroundColor: '#4CAF50',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold'
                        }}
                    >
                        Export to Excel
                    </button>
                </div>
                <PayloadSamplesHistoryChart payloadHistory={payloadHistory} />
            </div>

            <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
                <h2 style={{ margin: '0 0 15px 0' }}>Payload Samples (Latest)</h2>
                <PayloadSamplesChart payloadHistory={payloadHistory} />
            </div>

            <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
                <h2 style={{ margin: '0 0 15px 0' }}>Server Console Logs</h2>
                <div style={{
                    backgroundColor: '#1e1e1e',
                    color: '#d4d4d4',
                    padding: '15px',
                    borderRadius: '5px',
                    fontFamily: 'monospace',
                    fontSize: '12px',
                    maxHeight: '300px',
                    overflowY: 'auto'
                }}>
                    {logs.length === 0 ? <div style={{ color: '#888' }}>No logs yet...</div> : logs.map((log, index) => (
                        <div key={index} style={{ marginBottom: '4px' }}>
                            <span style={{ color: '#888' }}>[{log.timestamp}]</span> {log.message}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
