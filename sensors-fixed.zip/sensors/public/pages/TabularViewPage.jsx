// small clickable icon (children are the SVG shapes)
const IconButton = ({ title, onClick, children }) => (
    <button
        onClick={onClick}
        title={title}
        aria-label={title}
        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', margin: '0 2px', borderRadius: '4px', lineHeight: 0 }}
        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#e8f0fe')}
        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
    >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1a73e8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            {children}
        </svg>
    </button>
);

// Tabular View Page Component
function TabularViewPage({ devices = [], deviceRows = {}, isCollapsed, onOpenPayload }) {
    // tick every second so the relative time keeps counting up
    const [now, setNow] = React.useState(Date.now());
    React.useEffect(() => {
        const t = setInterval(() => setNow(Date.now()), 1000);
        return () => clearInterval(t);
    }, []);

    const relativeTime = (ms) => {
        if (!ms) return 'Waiting...';
        const sec = Math.max(0, Math.floor((now - ms) / 1000));
        if (sec < 60) return `${sec} sec ago`;
        const min = Math.floor(sec / 60);
        if (min < 60) return `${min} min ${sec % 60} sec ago`;
        const hr = Math.floor(min / 60);
        return `${hr} hr ${min % 60} min ago`;
    };

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };

    const tableContainerStyle = {
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
        overflow: 'hidden'
    };

    const tableStyle = {
        width: '100%',
        borderCollapse: 'collapse'
    };

    const thStyle = {
        backgroundColor: '#34495e',
        color: 'white',
        padding: '12px',
        textAlign: 'left',
        fontWeight: 'bold',
        borderBottom: '2px solid #2c3e50'
    };

    const tdStyle = {
        padding: '12px',
        borderBottom: '1px solid #ecf0f1',
        color: '#333'
    };

    const rowStyle = {
        backgroundColor: 'white'
    };

    const alternateRowStyle = {
        backgroundColor: '#f8f9fa'
    };

    const chunkBadgeStyle = {
        padding: '6px 12px',
        borderRadius: '4px',
        backgroundColor: '#ff9800',
        color: 'white',
        fontSize: '12px',
        fontWeight: 'bold',
        display: 'inline-block'
    };

    const completeBadgeStyle = {
        padding: '6px 12px',
        borderRadius: '4px',
        backgroundColor: '#4caf50',
        color: 'white',
        fontSize: '12px',
        fontWeight: 'bold',
        display: 'inline-block'
    };

    // SF7 -> DR5, SF8 -> DR4, SF9 -> DR3, SF10 -> DR2, SF11 -> DR1, SF12 -> DR0
    const SF_TO_DR = { 7: 5, 8: 4, 9: 3, 10: 2, 11: 1, 12: 0 };
    const dataRateOf = (sf) => (SF_TO_DR[Number(sf)] !== undefined ? `DR${SF_TO_DR[Number(sf)]}` : 'N/A');

    const fmt = (v, unit) => (v === undefined || v === null || v === '' ? 'N/A' : `${v}${unit ? ' ' + unit : ''}`);

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '30px' }}>Tabular View</h2>
            <div style={tableContainerStyle}>
                <table style={tableStyle}>
                    <thead>
                        <tr>
                            <th style={thStyle}>Node Name</th>
                            <th style={thStyle}>Type</th>
                            <th style={thStyle}>SNR</th>
                            <th style={thStyle}>RSSI</th>
                            <th style={thStyle}>Spreading Factor</th>
                            <th style={thStyle}>Data Rate</th>
                            <th style={thStyle}>Realtime Data</th>
                            <th style={thStyle}>Receive Interval</th>
                            <th style={{ ...thStyle, textAlign: 'center' }}>Graphs</th>
                        </tr>
                    </thead>
                    <tbody>
                        {devices.length === 0 ? (
                            <tr>
                                <td colSpan="9" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                    No devices created yet
                                </td>
                            </tr>
                        ) : (
                            devices.map((device, index) => {
                                // one fixed row per device - only its values change
                                const row = deviceRows[(device.devEui || '').toLowerCase()] || {};
                                return (
                                    <tr key={device.devEui} style={index % 2 === 0 ? rowStyle : alternateRowStyle}>
                                        <td style={tdStyle}>{device.deviceName}</td>
                                        <td style={tdStyle}>
                                            {row.type === 1 ? <span style={chunkBadgeStyle}>Chunk</span>
                                                : row.type === 0 ? <span style={completeBadgeStyle}>Single</span>
                                                : row.type != null ? `Type ${row.type}` : 'N/A'}
                                        </td>
                                        <td style={tdStyle}>{fmt(row.snr, 'dB')}</td>
                                        <td style={tdStyle}>{fmt(row.rssi, 'dBm')}</td>
                                        <td style={tdStyle}>{row.spreadingFactor != null ? `SF${row.spreadingFactor}` : 'N/A'}</td>
                                        <td style={tdStyle}>{dataRateOf(row.spreadingFactor)}</td>
                                        <td style={tdStyle} title={row.lastUpdate ? new Date(row.lastUpdate).toLocaleString() : ''}>{relativeTime(row.lastUpdate)}</td>
                                        <td style={tdStyle}>{row.interval != null ? `${row.interval} sec` : 'N/A'}</td>
                                        <td style={{ ...tdStyle, textAlign: 'center', whiteSpace: 'nowrap' }}>
                                            <IconButton title={`Payload history - ${device.deviceName}`} onClick={() => onOpenPayload && onOpenPayload(device, 'history')}>
                                                <circle cx="12" cy="12" r="9" />
                                                <polyline points="12 7 12 12 15.5 14" />
                                            </IconButton>
                                            <IconButton title={`Payload latest - ${device.deviceName}`} onClick={() => onOpenPayload && onOpenPayload(device, 'latest')}>
                                                <polyline points="3 12 7 12 10 4 14 20 17 12 21 12" />
                                            </IconButton>
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
