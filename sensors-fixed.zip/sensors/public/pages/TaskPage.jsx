// Task page - the downlink queue: everything sent from the Downlink page and its status
function TaskPage({ devices = [], isCollapsed }) {
    const [queue, setQueue] = React.useState([]);
    const [queueDevice, setQueueDevice] = React.useState('all');
    const [queueError, setQueueError] = React.useState('');
    const [popupKey, setPopupKey] = React.useState(null);   // key of the row (message) whose data popup is open

    // One row per sent message: chunks that share a messageId are merged (older entries without one stay single rows)
    const groups = React.useMemo(() => {
        const map = new Map();
        queue.forEach(q => {
            const key = q.messageId || q._id;
            if (!map.has(key)) map.set(key, { key, chunks: [] });
            map.get(key).chunks.push(q);
        });
        return [...map.values()].map(g => {
            g.chunks.sort((a, b) => (a.chunkIndex || 1) - (b.chunkIndex || 1));
            return { ...g, first: g.chunks[0] };
        });
    }, [queue]);

    const popupGroup = groups.find(g => g.key === popupKey) || null;

    // Esc closes the popup
    React.useEffect(() => {
        if (!popupKey) return;
        const onKey = (e) => { if (e.key === 'Escape') setPopupKey(null); };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [popupKey]);

    const loadQueue = async () => {
        try {
            const url = queueDevice === 'all' ? '/api/downlinks' : `/api/downlinks?devEui=${queueDevice}`;
            const res = await fetch(url);
            if (!res.ok) throw new Error('Failed to load queue');
            setQueue(await res.json());
            setQueueError('');
        } catch (err) {
            setQueueError(err.message);
        }
    };

    // refresh every 3 s while this page is open
    React.useEffect(() => {
        loadQueue();
        const t = setInterval(loadQueue, 3000);
        return () => clearInterval(t);
    }, [queueDevice]);

    const handleRemove = async (group) => {
        const many = group.chunks.length > 1;
        if (!confirm(`Remove this entry${many ? ` (all ${group.chunks.length} chunks)` : ''} from the list?\n(This does not clear ChirpStack's own device queue.)`)) return;
        try {
            await Promise.all(group.chunks.map(c => fetch(`/api/downlinks/${c._id}`, { method: 'DELETE' })));
            loadQueue();
        } catch (err) {
            setQueueError('Failed to remove entry');
        }
    };

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const thStyle = { padding: '12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '12px', borderBottom: '1px solid #eee', fontSize: '14px' };

    const EyeIcon = () => (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
        </svg>
    );

    const CloseIcon = () => (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
            <line x1="5" y1="5" x2="19" y2="19" />
            <line x1="19" y1="5" x2="5" y2="19" />
        </svg>
    );

    const dataText = (q) => q.dataHex || q.data || '';
    const byteLen = (q) => (q.dataHex ? q.dataHex.length / 2 : (q.data ? atob(q.data).length : 0));

    // Status of a whole message = its least advanced chunk (any failed chunk makes it failed)
    const STATUS_RANK = { queued: 0, transmitted: 1, acknowledged: 2 };
    const groupStatus = (group) => {
        if (group.chunks.some(c => c.status === 'failed')) return 'failed';
        return group.chunks.reduce((min, c) => ((STATUS_RANK[c.status] ?? 0) < (STATUS_RANK[min] ?? 0) ? c.status : min), group.chunks[0].status);
    };
    const groupBytes = (group) => group.chunks.reduce((sum, c) => sum + byteLen(c), 0);

    const statusBadge = (status) => {
        const map = {
            queued: { bg: '#fff3e0', fg: '#e65100', label: 'Queued' },
            transmitted: { bg: '#e3f2fd', fg: '#1565c0', label: 'Transmitted' },
            acknowledged: { bg: '#e8f5e9', fg: '#2e7d32', label: 'Acknowledged' },
            failed: { bg: '#fce8e6', fg: '#c62828', label: 'Failed' }
        };
        const m = map[status] || { bg: '#eee', fg: '#333', label: status };
        return <span style={{ backgroundColor: m.bg, color: m.fg, padding: '3px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>{m.label}</span>;
    };

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Task</h2>
                <div style={cardStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
                        <label style={{ fontWeight: 'bold', color: '#333' }}>Device</label>
                        <select style={{ ...inputStyle, width: 'auto', minWidth: '240px' }} value={queueDevice} onChange={(e) => setQueueDevice(e.target.value)}>
                            <option value="all">All devices</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName}</option>
                            ))}
                        </select>
                        <button onClick={loadQueue} style={{ padding: '8px 16px', border: '1px solid #3498db', color: '#3498db', backgroundColor: 'white', borderRadius: '6px', cursor: 'pointer' }}>
                            Refresh
                        </button>
                        <span style={{ fontSize: '12px', color: '#888' }}>Updates every 3 seconds</span>
                    </div>

                    {queueError && <p style={{ color: '#c62828' }}>{queueError}</p>}

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Time</th>
                                    <th style={thStyle}>Device</th>
                                    <th style={thStyle}>FPort</th>
                                    <th style={thStyle}>Confirmed</th>
                                    <th style={thStyle}>Data (hex)</th>
                                    <th style={thStyle}>Status</th>
                                    <th style={{ ...thStyle, textAlign: 'center' }}>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                {groups.length === 0 ? (
                                    <tr><td colSpan="7" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>Queue is empty</td></tr>
                                ) : groups.map((g, i) => {
                                    const q = g.first;
                                    const sent = g.chunks.filter(c => (STATUS_RANK[c.status] ?? 0) >= 1).length;
                                    const mixed = g.chunks.length > 1 && new Set(g.chunks.map(c => c.status)).size > 1;
                                    return (
                                        <tr key={g.key} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                            <td style={tdStyle}>{new Date(q.createdAt).toLocaleString()}</td>
                                            <td style={tdStyle}>{q.deviceName || q.devEui}</td>
                                            <td style={tdStyle}>{q.fPort}</td>
                                            <td style={tdStyle}>{q.confirmed ? 'Yes' : 'No'}</td>
                                            <td style={tdStyle}>
                                                <button
                                                    onClick={() => setPopupKey(g.key)}
                                                    title="View data"
                                                    aria-label="View data"
                                                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#3498db', padding: 0, verticalAlign: 'middle' }}
                                                >
                                                    <EyeIcon />
                                                </button>
                                                <span style={{ marginLeft: '8px', fontSize: '12px', color: '#888' }}>
                                                    {groupBytes(g)} bytes{g.chunks.length > 1 ? ` - ${g.chunks.length} chunks` : ''}
                                                </span>
                                            </td>
                                            <td style={tdStyle}>
                                                {statusBadge(groupStatus(g))}
                                                {mixed && <div style={{ fontSize: '11px', color: '#888', marginTop: '4px' }}>{sent} of {g.chunks.length} sent</div>}
                                            </td>
                                            <td style={{ ...tdStyle, textAlign: 'center' }}>
                                                <button
                                                    onClick={() => handleRemove(g)}
                                                    title="Remove from list"
                                                    aria-label="Remove from list"
                                                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#c62828', fontSize: '16px' }}
                                                >✕</button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>

            {popupGroup && (
                <div
                    onClick={() => setPopupKey(null)}
                    style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2000, padding: '20px' }}
                >
                    <div
                        role="dialog"
                        aria-modal="true"
                        aria-label="Downlink data"
                        onClick={(e) => e.stopPropagation()}
                        style={{ backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 10px 30px rgba(0,0,0,0.3)', width: '100%', maxWidth: '640px', maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}
                    >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 20px', borderBottom: '1px solid #eee' }}>
                            <h3 style={{ margin: 0 }}>Downlink data</h3>
                            <button
                                onClick={() => setPopupKey(null)}
                                title="Close"
                                aria-label="Close"
                                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#555', padding: 0, display: 'flex' }}
                            >
                                <CloseIcon />
                            </button>
                        </div>
                        <div style={{ padding: '16px 20px', overflowY: 'auto' }}>
                            <p style={{ margin: '0 0 14px', fontSize: '14px', color: '#555' }}>
                                {popupGroup.first.deviceName || popupGroup.first.devEui} &middot; FPort {popupGroup.first.fPort} &middot; {groupBytes(popupGroup)} bytes
                                {popupGroup.chunks.length > 1 && <> &middot; {popupGroup.chunks.length} chunks</>}
                            </p>
                            {popupGroup.chunks.map((c, i) => (
                                <div key={c._id} style={{ marginBottom: i === popupGroup.chunks.length - 1 ? 0 : '16px' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                                        <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#333' }}>
                                            {popupGroup.chunks.length > 1 ? `Chunk ${c.chunkIndex || i + 1} - ` : ''}{byteLen(c)} bytes
                                        </span>
                                        {statusBadge(c.status)}
                                    </div>
                                    <div style={{ fontFamily: 'monospace', fontSize: '14px', wordBreak: 'break-all', backgroundColor: '#f8f9fa', border: '1px solid #eee', borderRadius: '6px', padding: '12px' }}>
                                        {dataText(c)}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
