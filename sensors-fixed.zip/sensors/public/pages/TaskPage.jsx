// Task page - the downlink queue: everything sent from the Downlink page and its status
function TaskPage({ devices = [], isCollapsed }) {
    const [queue, setQueue] = React.useState([]);
    const [queueDevice, setQueueDevice] = React.useState('all');
    const [queueError, setQueueError] = React.useState('');
    const [shownIds, setShownIds] = React.useState(() => new Set());   // rows whose data is revealed (hidden by default)

    const toggleData = (id) => {
        setShownIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    };

    const loadQueue = async () => {
        try {
            const url = queueDevice === 'all' ? '/api/downlinks' : `/api/downlinks?devEui=${queueDevice}`;
            const res = await fetch(url);
            if (!res.ok) throw new Error('Failed to load queue');
            setQueue(await res.json());
            setQueueError('');
        } catch (err) {
            setQueueError(err.message);
        }
    };

    // refresh every 3 s while this page is open
    React.useEffect(() => {
        loadQueue();
        const t = setInterval(loadQueue, 3000);
        return () => clearInterval(t);
    }, [queueDevice]);

    const handleRemove = async (id) => {
        if (!confirm('Remove this entry from the list?\n(This does not clear ChirpStack\'s own device queue.)')) return;
        try {
            await fetch(`/api/downlinks/${id}`, { method: 'DELETE' });
            loadQueue();
        } catch (err) {
            setQueueError('Failed to remove entry');
        }
    };

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const thStyle = { padding: '12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '12px', borderBottom: '1px solid #eee', fontSize: '14px' };

    const EyeIcon = ({ off }) => (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
            {off && <line x1="3" y1="3" x2="21" y2="21" />}
        </svg>
    );

    const statusBadge = (status) => {
        const map = {
            queued: { bg: '#fff3e0', fg: '#e65100', label: 'Queued' },
            transmitted: { bg: '#e3f2fd', fg: '#1565c0', label: 'Transmitted' },
            acknowledged: { bg: '#e8f5e9', fg: '#2e7d32', label: 'Acknowledged' },
            failed: { bg: '#fce8e6', fg: '#c62828', label: 'Failed' }
        };
        const m = map[status] || { bg: '#eee', fg: '#333', label: status };
        return <span style={{ backgroundColor: m.bg, color: m.fg, padding: '3px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>{m.label}</span>;
    };

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Task</h2>
                <div style={cardStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
                        <label style={{ fontWeight: 'bold', color: '#333' }}>Device</label>
                        <select style={{ ...inputStyle, width: 'auto', minWidth: '240px' }} value={queueDevice} onChange={(e) => setQueueDevice(e.target.value)}>
                            <option value="all">All devices</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName}</option>
                            ))}
                        </select>
                        <button onClick={loadQueue} style={{ padding: '8px 16px', border: '1px solid #3498db', color: '#3498db', backgroundColor: 'white', borderRadius: '6px', cursor: 'pointer' }}>
                            Refresh
                        </button>
                        <span style={{ fontSize: '12px', color: '#888' }}>Updates every 3 seconds</span>
                    </div>

                    {queueError && <p style={{ color: '#c62828' }}>{queueError}</p>}

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Time</th>
                                    <th style={thStyle}>Device</th>
                                    <th style={thStyle}>FPort</th>
                                    <th style={thStyle}>Confirmed</th>
                                    <th style={thStyle}>Data (hex)</th>
                                    <th style={thStyle}>Status</th>
                                    <th style={{ ...thStyle, textAlign: 'center' }}>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                {queue.length === 0 ? (
                                    <tr><td colSpan="7" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>Queue is empty</td></tr>
                                ) : queue.map((q, i) => (
                                    <tr key={q._id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                        <td style={tdStyle}>{new Date(q.createdAt).toLocaleString()}</td>
                                        <td style={tdStyle}>{q.deviceName || q.devEui}</td>
                                        <td style={tdStyle}>{q.fPort}</td>
                                        <td style={tdStyle}>{q.confirmed ? 'Yes' : 'No'}</td>
                                        <td style={{ ...tdStyle, maxWidth: '420px' }}>
                                            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                                                <button
                                                    onClick={() => toggleData(q._id)}
                                                    title={shownIds.has(q._id) ? 'Hide data' : 'Show data'}
                                                    aria-label={shownIds.has(q._id) ? 'Hide data' : 'Show data'}
                                                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: shownIds.has(q._id) ? '#3498db' : '#777', padding: 0, display: 'flex', flexShrink: 0 }}
                                                >
                                                    <EyeIcon off={shownIds.has(q._id)} />
                                                </button>
                                                {shownIds.has(q._id) && (
                                                    <span style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>{q.dataHex || q.data}</span>
                                                )}
                                            </div>
                                        </td>
                                        <td style={tdStyle}>{statusBadge(q.status)}</td>
                                        <td style={{ ...tdStyle, textAlign: 'center' }}>
                                            <button
                                                onClick={() => handleRemove(q._id)}
                                                title="Remove from list"
                                                aria-label="Remove from list"
                                                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#c62828', fontSize: '16px' }}
                                            >✕</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>
    );
}
