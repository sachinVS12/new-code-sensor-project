
require("dotenv").config();

const mqtt = require("mqtt");
const fs = require("fs");
const path = require("path");

// ─── Environment configuration ──────────────────────────
const {
  MQTT_HOST,
  MQTT_USERNAME,
  MQTT_PASSWORD,
  MQTT_CA_CERT,
  APPLICATION_ID,
} = process.env;

if (!MQTT_HOST || !APPLICATION_ID) {
  console.error("Missing MQTT_HOST or APPLICATION_ID in .env");
  process.exit(1);
}

const DEVICE_EUI = "50c6c10d19c40cce";
const DEVICE_NAME = "mohan";

// Run: node publisher.js chunk
// Run: node publisher.js rak
const MODE = process.argv[2] || "chunk";

const topic =
  `application/${APPLICATION_ID}/device/${DEVICE_EUI}/event/up`;

const options = {
  clientId: `mqtt-test-publisher-${Math.random().toString(16).slice(2, 10)}`,
  username: MQTT_USERNAME?.trim() || undefined,
  password: MQTT_PASSWORD?.trim() || undefined,
  reconnectPeriod: 5000,
  connectTimeout: 10000,
  clean: true,
  keepalive: 60,
};

if (MQTT_HOST.startsWith("mqtts://")) {
  const caPath = MQTT_CA_CERT || "./certs/ca.pem";
  options.ca = fs.readFileSync(path.resolve(caPath));
  options.rejectUnauthorized = true;
}

// ─── MQTT connection ────────────────────────────────────
const client = mqtt.connect(MQTT_HOST, options);

let fCnt = 1;

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Simulated ChirpStack uplink ─────────────────────────
function publishUplink(payload, fPort) {
  const uplink = {
    deduplicationId: `test-${Date.now()}-${Math.random()}`,
    time: new Date().toISOString(),
    deviceInfo: {
      tenantId: "test-tenant",
      tenantName: "Test Tenant",
      applicationId: APPLICATION_ID,
      applicationName: "Sensor Application",
      deviceProfileId: "test-profile",
      deviceProfileName: "Test Device Profile",
      deviceName: DEVICE_NAME,
      devEui: DEVICE_EUI,
      deviceClassEnabled: "CLASS_A",
    },
    devAddr: "01ABCDEF",
    adr: true,
    dr: 5,
    fCnt: fCnt++,
    fPort,
    confirmed: false,
    data: payload.toString("base64"),
    rxInfo: [
      {
        gatewayId: "test-gateway-001",
        rssi: -75,
        snr: 9.5,
        channel: 1,
        rfChain: 0,
        location: {},
        context: "dGVzdA==",
        uplinkId: 1,
        crcStatus: "CRC_OK",
        frequency: 868100000,
        gwTime: new Date().toISOString(),
        nsTime: new Date().toISOString(),
        fineTimestampType: "NONE",
      },
    ],
    txInfo: {
      frequency: 868100000,
      modulation: {
        lora: {
          bandwidth: 125000,
          spreadingFactor: 7,
          codeRate: "CR_4_5",
        },
      },
    },
  };

  return new Promise((resolve, reject) => {
    client.publish(
      topic,
      JSON.stringify(uplink),
      { qos: 0 },
      err => {
        if (err) return reject(err);

        console.log(
          `📡 Published | Device: ${DEVICE_NAME} | FPort: ${fPort} | FCnt: ${uplink.fCnt} | Bytes: ${payload.length}`
        );

        resolve();
      }
    );
  });
}

// ─── STM32 CHUNKED DATASET PUBLISHER ─────────────────────
// Packet format:
// [Type: 1 byte]
// [Total: 2 bytes BE]
// [Offset: 2 bytes BE]
// [Length: 2 bytes BE]
// [Samples: 16-bit LE]

async function publishChunkedDataset() {
  console.log("\n🚀 Starting STM32 chunk simulation");
  console.log("Device:", DEVICE_EUI);

  const sampleCount = 2096;
  const totalBytes = sampleCount * 2;

  // Generate 2096 simulated ADC samples
  const samples = [];

  for (let i = 0; i < sampleCount; i++) {
    const value =
      2000 +
      Math.round(300 * Math.sin(i / 30)) +
      Math.round(Math.random() * 30);

    samples.push(value);
  }

  const dataset = Buffer.alloc(totalBytes);

  samples.forEach((value, index) => {
    dataset.writeUInt16LE(value, index * 2);
  });

  // Keep each test packet small enough for typical
  // LoRaWAN payload limits. Actual limits depend on DR.
  const chunkSize = 100;

  let offset = 0;
  let packetNumber = 1;

  while (offset < totalBytes) {
    const length = Math.min(chunkSize, totalBytes - offset);

    const header = Buffer.alloc(7);

    header.writeUInt8(1, 0);
    header.writeUInt16BE(totalBytes, 1);
    header.writeUInt16BE(offset, 3);
    header.writeUInt16BE(length, 5);

    const packet = Buffer.concat([
      header,
      dataset.subarray(offset, offset + length),
    ]);

    await publishUplink(packet, 2);

    console.log(
      `Chunk ${packetNumber}: offset=${offset}, length=${length}`
    );

    offset += length;
    packetNumber++;

    // Simulate time between LoRaWAN uplinks
    await delay(500);
  }

  console.log("\n✅ STM32 dataset simulation completed");
  console.log("Total samples:", sampleCount);
  console.log("Total bytes:", totalBytes);
}

// ─── RAK5146 SENSOR DATA PUBLISHER ───────────────────────
// Packet format:
// [Version: 1 byte]
// [Type: 1 byte]
// [Reserved: 1 byte]
// [Count: 1 byte]
// [Duration: 2 bytes BE]
// [Battery: 2 bytes BE]
// [Samples: 16-bit BE]

async function publishRak5146() {
  console.log("\n🚀 Starting RAK5146 simulation");

  const samples = [];

  for (let i = 0; i < 100; i++) {
    const value =
      2000 +
      Math.round(300 * Math.sin(i / 10)) +
      Math.round(Math.random() * 20);

    samples.push(value);
  }

  const headerSize = 8;
  const packet = Buffer.alloc(headerSize + samples.length * 2);

  packet.writeUInt8(1, 0);       // Version
  packet.writeUInt8(1, 1);       // Type
  packet.writeUInt8(0, 2);       // Reserved
  packet.writeUInt8(samples.length, 3);
  packet.writeUInt16BE(1000, 4); // Duration: 1000 ms
  packet.writeUInt16BE(370, 6);  // Battery: 3.70 V

  samples.forEach((value, index) => {
    packet.writeUInt16BE(value, headerSize + index * 2);
  });

  await publishUplink(packet, 2);

  console.log("✅ RAK5146 packet published");
  console.log("Samples:", samples.length);
  console.log("Battery: 3.70 V");
}

// ─── MQTT EVENTS ────────────────────────────────────────
client.on("connect", async () => {
  console.log("✅ Connected to MQTT broker");
  console.log("MQTT Host:", MQTT_HOST);
  console.log("Topic:", topic);
  console.log("Mode:", MODE);

  try {
    if (MODE === "chunk") {
      await publishChunkedDataset();
    } else if (MODE === "rak") {
      await publishRak5146();
    } else {
      console.error("Unknown mode. Use chunk or rak.");
    }
  } catch (err) {
    console.error("❌ Publishing error:", err.message);
  } finally {
    client.end();
  }
});

client.on("error", err => {
  console.error("❌ MQTT Error:", err.message);
});

client.on("reconnect", () => {
  console.log("🔄 Reconnecting...");
});

client.on("offline", () => {
  console.log("⚠️ MQTT offline");
});
