require("dotenv").config();
const mqtt = require("mqtt");
const fs = require("fs");
const path = require("path");
const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const mongoose = require("mongoose");
const SensorData = require("./models/SensorData");
const Node = require("./models/Node");
const Gateway = require("./models/Gateway");
const Downlink = require("./models/Downlink");
const FeedData = require("./models/FeedData");

// ─── Validate env ────────────────────────────────────────
const {
  MQTT_HOST,
  MQTT_USERNAME,
  MQTT_PASSWORD,
  MQTT_CA_CERT,
  APPLICATION_ID,
  MONGODB_URI,
} = process.env;

if (!MQTT_HOST) {
  console.error("❌ MQTT_HOST is missing in .env");
  process.exit(1);
}
if (!MONGODB_URI) {
  console.error("❌ MONGODB_URI is missing in .env");
  process.exit(1);
}

// ─── Connect to MongoDB ───────────────────────────────────
mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log("✅ Connected to MongoDB");
    await loadDeviceNames();
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err);
    process.exit(1);
  });

// ─── Build connection options ────────────────────────────
const connectOptions = {
  clientId: `chirpstack-sub-${Math.random().toString(16).slice(2, 10)}`,
  username: MQTT_USERNAME?.trim() || undefined,
  password: MQTT_PASSWORD?.trim() || undefined,
  reconnectPeriod: 5000,
  connectTimeout: 10_000,
  clean: true,
  keepalive: 60,
};

// Attach CA if using TLS
if (MQTT_HOST.startsWith("mqtts://")) {
  const caPath = MQTT_CA_CERT || "./certs/ca.pem";
  try {
    connectOptions.ca = fs.readFileSync(path.resolve(caPath));
    connectOptions.rejectUnauthorized = true;
    console.log(`🔐 Loaded CA from ${caPath}`);
  } catch (err) {
    console.error(`❌ Cannot read CA file at ${caPath}:`, err.message);
    process.exit(1);
  }
}

// ─── Device name map ─────────────────────────────────────
const deviceNames = {};

// Load device names from MongoDB on startup
async function loadDeviceNames() {
  try {
    const nodes = await Node.find({});
    nodes.forEach(node => {
      deviceNames[node.devEui.toLowerCase()] = node.deviceName;
      subscribeTopic(node.mqttTopic);
    });
    console.log(`📋 Loaded ${Object.keys(deviceNames).length} device names from database`);
  } catch (err) {
    console.error("❌ Error loading device names:", err.message);
  }
}

// ─── Chunked-dataset devices (STM32 node sending the 2096-sample table) ───
// Packet layout (FPort 2):
//   type 1 = data chunk : [type 1B][total size 2B BE][offset 2B BE][length 2B BE][samples, 16-bit LITTLE-endian]
//   type 2 = probe      : [type 1B]... data-rate test, no samples
const CHUNK_DEVICES = new Set([
  "50c6c10d19c40cce", // mohan
]);
const CHUNK_HEADER_SIZE = 7;
const chunkSessions = {}; // devEui -> { total, buf, filled, received, packets }

function decodeChunkPacket(devEui, fPort, b64) {
  const buf = Buffer.from(b64, "base64");
  const hex = buf.toString("hex");

  if (fPort !== 2) return { error: `Unhandled FPort ${fPort}`, hex };
  if (buf.length < 2) return { error: "Payload too short", hex };

  const type = buf[0];

  // Probe packet (data-rate test): "02 <DR>" or "02 00 00 00 00 00 01 <DR>"
  if (type === 2) {
    const dataRate = buf.length >= 8 ? buf[7] : buf[1];
    return { kind: "probe", type, dataRate, hex };
  }

  if (type !== 1 || buf.length < CHUNK_HEADER_SIZE) {
    return { error: `Unknown packet (type ${type}, ${buf.length} bytes)`, hex };
  }

  // ---- 7-byte chunk header (big-endian) ----
  const total  = buf.readUInt16BE(1);
  const offset = buf.readUInt16BE(3);
  const length = buf.readUInt16BE(5);
  const data   = buf.subarray(CHUNK_HEADER_SIZE);

  if (data.length !== length) {
    return { error: `Length mismatch: header says ${length}, packet has ${data.length}`, hex };
  }
  if (offset + length > total) {
    return { error: `Chunk outside dataset (offset ${offset} + length ${length} > total ${total})`, hex };
  }

  // ---- samples inside THIS chunk (16-bit little-endian) ----
  const chunkSamples = [];
  for (let i = 0; i + 1 < data.length; i += 2) chunkSamples.push(data.readUInt16LE(i));

  // ---- collect chunks per device until the whole dataset has arrived ----
  let s = chunkSessions[devEui];
  let previousIncomplete = false;
  if (!s || s.total !== total || (offset === 0 && s.filled[0] === 1)) {
    previousIncomplete = !!s && s.received < s.total;
    s = chunkSessions[devEui] = {
      total,
      buf: Buffer.alloc(total),
      filled: new Uint8Array(total),
      received: 0,
      packets: 0,
    };
  }

  data.copy(s.buf, offset);
  let newBytes = 0;
  for (let i = 0; i < length; i++) {
    if (!s.filled[offset + i]) { s.filled[offset + i] = 1; newBytes++; }
  }
  s.received += newBytes;
  if (newBytes > 0) s.packets++;
  const duplicate = newBytes === 0; // a resent chunk (same offset) just overwrites

  const complete = s.received >= s.total;
  const result = {
    kind: complete ? "dataset" : "chunk",
    header: {
      hex: buf.subarray(0, CHUNK_HEADER_SIZE).toString("hex"),
      type,
      total,
      offset,
      length,
    },
    chunkSamples,
    chunksReceived: s.packets,
    receivedBytes: s.received,
    totalBytes: s.total,
    duplicate,
    previousIncomplete,
    battery: null, // not sent by the node yet
    hex,
  };

  if (complete) {
    const samples = [];
    for (let i = 0; i + 1 < s.total; i += 2) samples.push(s.buf.readUInt16LE(i));
    result.samples = samples;
    result.sampleCount = samples.length;
    result.min = Math.min(...samples);
    result.max = Math.max(...samples);
    result.avg = Number((samples.reduce((a, b) => a + b, 0) / samples.length).toFixed(2));
    delete chunkSessions[devEui];
  }
  return result;
}

function printChunkResult(deviceName, devEui, r) {
  const line = "━".repeat(63);

  if (r.error) {
    console.log(`Decode error  : ${r.error}`);
    return;
  }

  if (r.kind === "probe") {
    console.log(`Probe packet  : data-rate test at DR${r.dataRate} (no samples, ignored)`);
    return;
  }

  const hdrHex = r.header.hex.match(/../g).join(" ");
  console.log(line);
  console.log(`📦 CHUNK RECEIVED - ${deviceName} (${devEui})`);
  console.log(line);
  console.log(`HEADER (7 B)  : ${hdrHex}`);
  console.log(`  Type        : ${r.header.type} (data chunk)`);
  console.log(`  Total size  : ${r.header.total} bytes (${r.header.total / 2} samples)`);
  console.log(`  Offset      : ${r.header.offset}`);
  console.log(`  Length      : ${r.header.length} bytes (${r.header.length / 2} samples)`);
  console.log(`Battery       : N/A (not sent by node yet)`);
  console.log(`Chunk samples : [${r.chunkSamples.join(", ")}]`);
  console.log(
    `Progress      : ${r.receivedBytes}/${r.totalBytes} bytes, ${r.chunksReceived} chunk(s)` +
      (r.duplicate ? "  (duplicate chunk, ignored)" : ""),
  );
  if (r.previousIncomplete) {
    console.log(`⚠️  Previous dataset was incomplete and has been discarded`);
  }

  if (r.kind === "dataset") {
    console.log(line);
    console.log(`✅ DATASET COMPLETE - ${deviceName} (${devEui})`);
    console.log(line);
    console.log(`Samples       : ${r.sampleCount}`);
    console.log(`Stats         : min=${r.min} | max=${r.max} | avg=${r.avg}`);
    console.log(`All Samples   : [${r.samples.join(", ")}]`);
  }
  console.log(line);
}

// ─── RAK5146 / WisBlock FPort-2 decoder ──────────────────
function decodeRak5146(fPort, b64) {
  const buf = Buffer.from(b64, "base64");

  if (fPort !== 2) {
    return { error: `Unhandled FPort ${fPort}`, hex: buf.toString("hex") };
  }
  if (buf.length < 8) {
    return { error: "Payload too short", hex: buf.toString("hex") };
  }

  const version = buf[0];
  const type = buf[1];
  const reserved = buf[2];
  const count = buf[3];
  const duration = buf.readUInt16BE(4);
  const batteryRaw = buf.readUInt16BE(6);

  const samples = [];
  for (let i = 8; i + 1 < buf.length; i += 2) {
    samples.push(buf.readUInt16BE(i));
  }

  // Filter out outlier values (likely transmission errors)
  // Remove values > 10000 which are clearly spurious (normal ADC samples are < 5000)
  const filteredSamples = samples.filter(s => s < 10000);

  // Additional filtering: use interquartile range (IQR) method for robust outlier detection
  if (filteredSamples.length > 20) {
    const sorted = [...filteredSamples].sort((a, b) => a - b);
    const q1 = sorted[Math.floor(sorted.length * 0.25)];
    const q3 = sorted[Math.floor(sorted.length * 0.75)];
    const iqr = q3 - q1;
    const lowerBound = q1 - 1.5 * iqr;
    const upperBound = q3 + 1.5 * iqr;

    const iqrFiltered = filteredSamples.filter(s => s >= lowerBound && s <= upperBound);
    if (iqrFiltered.length > filteredSamples.length * 0.6) {
      console.log(`⚠️  IQR filtering: removed ${filteredSamples.length - iqrFiltered.length} samples (Q1=${q1}, Q3=${q3}, IQR=${iqr})`);
      filteredSamples.length = 0;
      filteredSamples.push(...iqrFiltered);
    }
  }

  // If we filtered out some outliers, use the filtered array
  if (filteredSamples.length > 0 && filteredSamples.length < samples.length) {
    console.log(`⚠️  Total filtered: ${samples.length - filteredSamples.length} outlier samples`);
    // Replace samples array with filtered version
    samples.length = 0;
    samples.push(...filteredSamples);
  }

  const min = samples.length ? Math.min(...samples) : null;
  const max = samples.length ? Math.max(...samples) : null;
  const avg = samples.length
    ? Number((samples.reduce((a, b) => a + b, 0) / samples.length).toFixed(2))
    : null;

  return {
    version,
    type,
    reserved,
    count,
    duration,
    batteryRaw,
    batteryV: (batteryRaw / 100).toFixed(2),
    sampleCount: samples.length,
    min,
    max,
    avg,
    samples,
    samplesPreview: samples.slice(0, 16),
    hex: buf.toString("hex"),
  };
}

// ─── Express & WebSocket server ─────────────────────────
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static("public"));
app.use(express.json());

// ─── Dynamic MQTT topics ─────────────────────────────────
// A device's topic is generated from its Application ID + DevEUI and saved
// with the device. The broker subscription is added/removed as devices are
// created, edited and deleted - no restart and no .env topic needed.
const buildTopic = (applicationId, devEui) =>
  `application/${applicationId}/device/${devEui}/event/up`;

const subscribedTopics = new Set();

// Besides a device's uplink topic, also follow its downlink status events
// (txack = sent to the radio, ack = confirmed by the device).
const relatedTopics = (topic) =>
  topic.endsWith("/event/up")
    ? [
        topic,
        topic.replace(/\/event\/up$/, "/event/txack"),
        topic.replace(/\/event\/up$/, "/event/ack"),
      ]
    : [topic];

function subscribeTopic(topic) {
  if (!topic) return;
  relatedTopics(topic).forEach((t) => {
    subscribedTopics.add(t);
    if (client.connected) {
      client.subscribe(t, { qos: 0 }, (err) => {
        if (err) console.error(`❌ Subscribe failed (${t}):`, err.message);
        else console.log(`📡 Subscribed to: ${t}`);
      });
    }
  });
}

async function unsubscribeTopic(topic, excludeId) {
  if (!topic) return;
  // keep the subscription if another saved device still uses this topic
  const stillUsed = await Node.exists({ mqttTopic: topic, _id: { $ne: excludeId } });
  if (stillUsed) return;
  relatedTopics(topic).forEach((t) => {
    subscribedTopics.delete(t);
    if (client.connected) {
      client.unsubscribe(t, (err) => {
        if (err) console.error(`❌ Unsubscribe failed (${t}):`, err.message);
        else console.log(`🔕 Unsubscribed from: ${t}`);
      });
    }
  });
}

const EUI_REGEX = /^[0-9a-f]{16}$/;

// API endpoint to create a new node
// Body: { deviceName, devEui, applicationId } (+ optional mode, gateway)
// mqttTopic is generated automatically.
app.post("/api/nodes", async (req, res) => {
  try {
    const { deviceName, devEui, applicationId, mode, gateway } = req.body;

    if (!deviceName?.trim() || !devEui?.trim() || !applicationId?.trim()) {
      return res.status(400).json({ error: "Device name, DevEUI and Application ID are required" });
    }
    const eui = devEui.trim().toLowerCase();
    if (!EUI_REGEX.test(eui)) {
      return res.status(400).json({ error: "DevEUI must be 16 hex characters" });
    }

    const newNode = new Node({
      deviceName: deviceName.trim(),
      devEui: eui,
      applicationId: applicationId.trim(),
      mqttTopic: buildTopic(applicationId.trim(), eui),
      mode: mode || "OTAA",
      gateway: gateway || "",
    });

    await newNode.save();

    deviceNames[newNode.devEui] = newNode.deviceName;
    subscribeTopic(newNode.mqttTopic);

    console.log(`✅ Node created: ${newNode.deviceName} (${newNode.devEui})`);
    console.log(`📡 MQTT topic: ${newNode.mqttTopic}`);
    res.status(201).json({ message: "Node created successfully", node: newNode });
  } catch (err) {
    console.error("❌ Error creating node:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Device name or DevEUI already exists" });
    }
    res.status(500).json({ error: "Failed to create node" });
  }
});

// API endpoint to get all nodes
app.get("/api/nodes", async (req, res) => {
  try {
    const nodes = await Node.find({});
    res.json(nodes);
  } catch (err) {
    console.error("❌ Error fetching nodes:", err.message);
    res.status(500).json({ error: "Failed to fetch nodes" });
  }
});

// API endpoint to update a node
app.put("/api/nodes/:id", async (req, res) => {
  try {
    const { deviceName, devEui, applicationId, mode, gateway } = req.body;

    if (!deviceName?.trim() || !devEui?.trim() || !applicationId?.trim()) {
      return res.status(400).json({ error: "Device name, DevEUI and Application ID are required" });
    }
    const eui = devEui.trim().toLowerCase();
    if (!EUI_REGEX.test(eui)) {
      return res.status(400).json({ error: "DevEUI must be 16 hex characters" });
    }

    const old = await Node.findById(req.params.id);
    if (!old) return res.status(404).json({ error: "Node not found" });

    const updated = await Node.findByIdAndUpdate(
      req.params.id,
      {
        deviceName: deviceName.trim(),
        devEui: eui,
        applicationId: applicationId.trim(),
        mqttTopic: buildTopic(applicationId.trim(), eui),
        mode: mode || "OTAA",
        gateway: gateway || "",
      },
      { new: true, runValidators: true }
    );

    delete deviceNames[old.devEui.toLowerCase()];
    deviceNames[updated.devEui] = updated.deviceName;

    if (old.mqttTopic !== updated.mqttTopic) {
      await unsubscribeTopic(old.mqttTopic, old._id);
      subscribeTopic(updated.mqttTopic);
    }

    console.log(`✅ Node updated: ${updated.deviceName} (${updated.devEui})`);
    res.json({ message: "Node updated successfully", node: updated });
  } catch (err) {
    console.error("❌ Error updating node:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Device name or DevEUI already exists" });
    }
    res.status(500).json({ error: "Failed to update node" });
  }
});

// API endpoint to delete a node
app.delete("/api/nodes/:id", async (req, res) => {
  try {
    const node = await Node.findByIdAndDelete(req.params.id);
    if (!node) return res.status(404).json({ error: "Node not found" });
    delete deviceNames[node.devEui.toLowerCase()];
    await unsubscribeTopic(node.mqttTopic, node._id);
    await FeedData.deleteMany({ devEui: node.devEui });
    console.log(`✅ Node deleted: ${req.params.id}`);
    res.json({ message: "Node deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting node:", err.message);
    res.status(500).json({ error: "Failed to delete node" });
  }
});

// API endpoint to create a new gateway
app.post("/api/gateways", async (req, res) => {
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;

    if (!gatewayName || !gatewayEui || !destinationIp || !port || !mode) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const newGateway = new Gateway({
      gatewayName,
      gatewayEui,
      destinationIp,
      port,
      mode
    });

    await newGateway.save();
    console.log(`✅ Gateway created: ${gatewayName} (${gatewayEui})`);
    res.status(201).json({ message: "Gateway created successfully", gateway: newGateway });
  } catch (err) {
    console.error("❌ Error creating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to create gateway" });
  }
});

// API endpoint to get all gateways
app.get("/api/gateways", async (req, res) => {
  try {
    const gateways = await Gateway.find({});
    res.json(gateways);
  } catch (err) {
    console.error("❌ Error fetching gateways:", err.message);
    res.status(500).json({ error: "Failed to fetch gateways" });
  }
});

// API endpoint to delete a gateway
app.delete("/api/gateways/:id", async (req, res) => {
  try {
    const deleted = await Gateway.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Gateway not found" });
    console.log(`✅ Gateway deleted: ${req.params.id}`);
    res.json({ message: "Gateway deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting gateway:", err.message);
    res.status(500).json({ error: "Failed to delete gateway" });
  }
});

// API endpoint to update a gateway
app.put("/api/gateways/:id", async (req, res) => {
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;
    const updatedGateway = await Gateway.findByIdAndUpdate(
      req.params.id,
      { gatewayName, gatewayEui, destinationIp, port, mode },
      { new: true, runValidators: true }
    );
    if (!updatedGateway) return res.status(404).json({ error: "Gateway not found" });
    console.log(`✅ Gateway updated: ${req.params.id}`);
    res.json({ message: "Gateway updated successfully", gateway: updatedGateway });
  } catch (err) {
    console.error("❌ Error updating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to update gateway" });
  }
});

// ─── Downlink (Feed Data + Queue) ────────────────────────
// Feed Data -> POST /api/downlinks publishes to ChirpStack's
//   application/<appId>/device/<devEui>/command/down
// Queue     -> GET  /api/downlinks lists what was sent and its status:
//   queued -> transmitted (txack event) -> acknowledged (ack event, confirmed only)
const DOWNLINK_CHUNK_BYTES = 240;   // fixed chunk size: each downlink carries at most 240 bytes
const MAX_DOWNLINK_CHUNKS = 50;    // safety cap per request (50 x 240 = 12000 bytes)

function parseDownlinkData(format, raw) {
  const text = String(raw ?? "");
  if (format === "hex") {
    const hex = text.replace(/0x/gi, "").replace(/[\s:,-]/g, "");
    if (!hex || hex.length % 2 !== 0 || !/^[0-9a-fA-F]+$/.test(hex)) {
      throw new Error("Hex data must have an even number of hex digits (0-9, A-F)");
    }
    return Buffer.from(hex, "hex");
  }
  if (format === "base64") {
    const b64 = text.replace(/\s/g, "");
    if (!b64 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64) || b64.length % 4 !== 0) {
      throw new Error("Invalid base64 data");
    }
    return Buffer.from(b64, "base64");
  }
  if (format === "text") {
    if (!text) throw new Error("Data is required");
    return Buffer.from(text, "utf8");
  }
  throw new Error("Format must be hex, text or base64");
}

app.post("/api/downlinks", async (req, res) => {
  try {
    const { devEui, fPort, confirmed, format, data } = req.body;

    const eui = String(devEui || "").trim().toLowerCase();
    const node = await Node.findOne({ devEui: eui });
    if (!node) return res.status(404).json({ error: "Device not found" });

    const port = Number(fPort);
    if (!Number.isInteger(port) || port < 1 || port > 223) {
      return res.status(400).json({ error: "FPort must be a whole number from 1 to 223" });
    }
    const allowedPort = await FeedData.findOne({ devEui: node.devEui, framePort: port });
    if (!allowedPort) {
      return res.status(400).json({ error: "FPort is not in this device's saved Feed Data. Upload it in the Feed Data tab first." });
    }

    let bytes;
    try {
      bytes = parseDownlinkData(format, data);
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
    if (bytes.length === 0) {
      return res.status(400).json({ error: "Data is required" });
    }

    // Split into fixed 240-byte chunks: 240 bytes = 1 chunk, 300 bytes = 240 + 60
    const chunks = [];
    for (let i = 0; i < bytes.length; i += DOWNLINK_CHUNK_BYTES) {
      chunks.push(bytes.subarray(i, i + DOWNLINK_CHUNK_BYTES));
    }
    if (chunks.length > MAX_DOWNLINK_CHUNKS) {
      return res.status(400).json({
        error: `Data is too long: ${bytes.length} bytes needs ${chunks.length} chunks (maximum ${MAX_DOWNLINK_CHUNKS} chunks of ${DOWNLINK_CHUNK_BYTES} bytes)`,
      });
    }

    if (!client.connected) {
      return res.status(503).json({ error: "MQTT broker is not connected" });
    }

    const topic = `application/${node.applicationId}/device/${node.devEui}/command/down`;
    const downlinks = [];

    // Send in order so the chunks are queued in order
    for (const [i, chunk] of chunks.entries()) {
      const payload = {
        devEui: node.devEui,
        confirmed: !!confirmed,
        fPort: port,
        data: chunk.toString("base64"),
      };

      try {
        await new Promise((resolve, reject) => {
          client.publish(topic, JSON.stringify(payload), { qos: 0 }, (err) =>
            err ? reject(err) : resolve()
          );
        });
      } catch (e) {
        console.error(`❌ Chunk ${i + 1}/${chunks.length} failed for ${node.deviceName}:`, e.message);
        return res.status(500).json({
          error: `Chunk ${i + 1} of ${chunks.length} failed to send (${downlinks.length} chunk(s) were already queued)`,
        });
      }

      const downlink = await Downlink.create({
        devEui: node.devEui,
        deviceName: node.deviceName,
        applicationId: node.applicationId,
        fPort: port,
        confirmed: !!confirmed,
        data: payload.data,
        dataHex: chunk.toString("hex").toUpperCase(),
        status: "queued",
      });
      downlinks.push(downlink);

      console.log(`⬇️  Downlink chunk ${i + 1}/${chunks.length} queued for ${node.deviceName} (${node.devEui}) fPort ${port}: ${chunk.length} bytes`);
    }

    res.status(201).json({
      message: chunks.length === 1 ? "Downlink queued" : `${chunks.length} downlink chunks queued`,
      totalBytes: bytes.length,
      chunks: chunks.length,
      downlinks,
    });
  } catch (err) {
    console.error("❌ Error sending downlink:", err.message);
    res.status(500).json({ error: "Failed to send downlink" });
  }
});

app.get("/api/downlinks", async (req, res) => {
  try {
    const filter = {};
    if (req.query.devEui) filter.devEui = String(req.query.devEui).toLowerCase();
    if (req.query.status) filter.status = String(req.query.status);
    const list = await Downlink.find(filter).sort({ createdAt: -1 }).limit(200);
    res.json(list);
  } catch (err) {
    console.error("❌ Error fetching downlinks:", err.message);
    res.status(500).json({ error: "Failed to fetch downlinks" });
  }
});

// Removes the entry from this list only (ChirpStack's own device queue is not touched)
app.delete("/api/downlinks/:id", async (req, res) => {
  try {
    const removed = await Downlink.findByIdAndDelete(req.params.id);
    if (!removed) return res.status(404).json({ error: "Downlink not found" });
    res.json({ message: "Downlink removed" });
  } catch (err) {
    res.status(500).json({ error: "Failed to remove downlink" });
  }
});

// txack / ack events from ChirpStack move the oldest matching queue entry forward
async function handleDownlinkEvent(topic, data) {
  try {
    const devEui = (data.deviceInfo?.devEui || data.devEui || "").toLowerCase();
    if (!devEui) return;

    if (topic.endsWith("/event/txack")) {
      const updated = await Downlink.findOneAndUpdate(
        { devEui, status: "queued" },
        { status: "transmitted", fCntDown: data.fCntDown, transmittedAt: new Date() },
        { sort: { createdAt: 1 }, new: true }
      );
      if (updated) console.log(`⬇️  Downlink transmitted: ${updated.deviceName} (${devEui})`);
    } else if (topic.endsWith("/event/ack") && data.acknowledged !== false) {
      const updated = await Downlink.findOneAndUpdate(
        { devEui, status: "transmitted", confirmed: true },
        { status: "acknowledged", acknowledgedAt: new Date() },
        { sort: { createdAt: 1 }, new: true }
      );
      if (updated) console.log(`✅ Downlink acknowledged: ${updated.deviceName} (${devEui})`);
    }
  } catch (err) {
    console.error("❌ Error handling downlink event:", err.message);
  }
}

// ─── Feed Data (uploaded Excel / CSV rows, stored per device) ──────────
// The browser reads the file and sends rows: [{ framePort, purpose }].
app.post("/api/feed-data", async (req, res) => {
  try {
    const { devEui, fileName, rows } = req.body;

    const eui = String(devEui || "").trim().toLowerCase();
    const node = await Node.findOne({ devEui: eui });
    if (!node) return res.status(404).json({ error: "Device not found" });

    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: "No rows to save" });
    }
    if (rows.length > 500) {
      return res.status(400).json({ error: "Too many rows (maximum 500)" });
    }

    // one row per frame port (if a port repeats, the last one wins)
    const byPort = new Map();
    for (const [i, r] of rows.entries()) {
      const port = Number(r.framePort);
      const purpose = String(r.purpose ?? "").trim();
      if (!Number.isInteger(port) || port < 1 || port > 223) {
        return res.status(400).json({ error: `Row ${i + 1}: Frame Port must be a whole number from 1 to 223` });
      }
      if (!purpose || purpose.length > 200) {
        return res.status(400).json({ error: `Row ${i + 1}: Purpose is required (max 200 characters)` });
      }
      byPort.set(port, purpose);
    }

    // replace this device's previous upload
    const removed = await FeedData.deleteMany({ devEui: node.devEui });
    const docs = [...byPort].map(([framePort, purpose]) => ({
      devEui: node.devEui,
      deviceName: node.deviceName,
      framePort,
      purpose,
      sourceFile: String(fileName || "").slice(0, 200),
    }));
    await FeedData.insertMany(docs);

    console.log(`📄 Feed data saved for ${node.deviceName}: ${docs.length} row(s), replaced ${removed.deletedCount}`);
    res.status(201).json({ message: "Feed data saved", saved: docs.length, replaced: removed.deletedCount });
  } catch (err) {
    console.error("❌ Error saving feed data:", err.message);
    res.status(500).json({ error: "Failed to save feed data" });
  }
});

app.get("/api/feed-data", async (req, res) => {
  try {
    const eui = String(req.query.devEui || "").trim().toLowerCase();
    if (!eui) return res.status(400).json({ error: "devEui is required" });
    const rows = await FeedData.find({ devEui: eui }).sort({ framePort: 1 });
    res.json(rows);
  } catch (err) {
    console.error("❌ Error fetching feed data:", err.message);
    res.status(500).json({ error: "Failed to fetch feed data" });
  }
});

app.delete("/api/feed-data", async (req, res) => {
  try {
    const eui = String(req.query.devEui || "").trim().toLowerCase();
    if (!eui) return res.status(400).json({ error: "devEui is required" });
    const result = await FeedData.deleteMany({ devEui: eui });
    res.json({ message: "Feed data cleared", deleted: result.deletedCount });
  } catch (err) {
    console.error("❌ Error clearing feed data:", err.message);
    res.status(500).json({ error: "Failed to clear feed data" });
  }
});

// Latest uplink per device (used to fill the tabular view on page load)
app.get("/api/latest", async (req, res) => {
  try {
    const rows = await SensorData.aggregate([
      { $sort: { timestamp: -1 } },
      { $group: { _id: "$devEui", doc: { $first: "$$ROOT" } } },
    ]);
    res.json(rows.map((r) => r.doc));
  } catch (err) {
    console.error("❌ Error fetching latest data:", err.message);
    res.status(500).json({ error: "Failed to fetch latest data" });
  }
});

// Broadcast sensor data to all connected WebSocket clients
function broadcastSensorData(data) {
  const clientCount = wss.clients.size;
  console.log(`📡 Broadcasting to ${clientCount} WebSocket clients:`, JSON.stringify(data));
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

// Broadcast console logs to all connected WebSocket clients
function broadcastLog(message) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'log', message }));
    }
  });
}

// Override console.log to also broadcast to WebSocket
const originalLog = console.log;
console.log = function(...args) {
  originalLog.apply(console, args);
  const message = args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ');
  broadcastLog(message);
};

console.log("🌐 WebSocket server initialized");

// ─── MQTT client ─────────────────────────────────────────
const client = mqtt.connect(MQTT_HOST, connectOptions);

client.on("connect", () => {
  console.log(`✅ Connected to MQTT: ${MQTT_HOST}`);
  // (Re)subscribe to every saved device topic (subscriptions are lost on reconnect)
  if (subscribedTopics.size) {
    client.subscribe([...subscribedTopics], { qos: 0 }, (err) => {
      if (err) console.error("❌ Subscribe failed:", err.message);
    });
  }
  console.log(`⏳ Subscribed to ${subscribedTopics.size} topic(s), waiting for data...\n`);
});

client.on("message", (receivedTopic, message) => {
  try {
    const data = JSON.parse(message.toString());

    // Downlink status events are not uplinks
    if (receivedTopic.endsWith("/event/txack") || receivedTopic.endsWith("/event/ack")) {
      handleDownlinkEvent(receivedTopic, data);
      return;
    }

    const devEui = (data.deviceInfo?.devEui || "").toLowerCase();
    const deviceName = deviceNames[devEui] || "Unknown";
    const appIdFromTopic = receivedTopic.split("/")[1];
    const rx =
      Array.isArray(data.rxInfo) && data.rxInfo.length ? data.rxInfo[0] : null;
    const spreadingFactor =
      data.txInfo?.modulation?.lora?.spreadingFactor ?? data.dr ?? undefined;

    console.log("──────────────────────────────────────────");
    console.log(`Topic         : ${receivedTopic}`);
    console.log(`App ID        : ${appIdFromTopic}`);
    console.log(`Device        : ${deviceName}`);
    console.log(`DevEUI        : ${devEui}`);
    console.log(
      `Profile       : ${data.deviceInfo?.deviceProfileName || "N/A"}`,
    );
    console.log(`Received at   : ${data.time || "N/A"}`);
    console.log(`FCnt          : ${data.fCnt ?? "N/A"}`);
    console.log(`FPort         : ${data.fPort ?? "N/A"}`);
    console.log(`Raw payload   : ${data.data || "N/A"}`);

    // Decode payload if FPort 2
    let decodedPayload = null;
    if (data.data && data.fPort != null && CHUNK_DEVICES.has(devEui)) {
      // Chunked-dataset device: 7-byte header + little-endian samples
      decodedPayload = decodeChunkPacket(devEui, data.fPort, data.data);
      printChunkResult(deviceName, devEui, decodedPayload);
    } else if (data.data && data.fPort != null) {
      decodedPayload = decodeRak5146(data.fPort, data.data);
      if (decodedPayload.error) {
        console.log(`Decode error  : ${decodedPayload.error}`);
      } else {
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`📊 PAYLOAD DECODED - ${deviceName} (${devEui})`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`Version       : ${decodedPayload.version}`);
        console.log(`Type          : 0x${decodedPayload.type.toString(16).padStart(2, "0")}`);
        console.log(`Count         : ${decodedPayload.count}`);
        console.log(`Duration      : ${decodedPayload.duration} ms`);
        console.log(`Battery       : ${decodedPayload.batteryV} V (raw ${decodedPayload.batteryRaw})`);
        console.log(`Samples       : ${decodedPayload.sampleCount}`);
        console.log(`Stats         : min=${decodedPayload.min} | max=${decodedPayload.max} | avg=${decodedPayload.avg}`);
        console.log(`All Samples   : [${decodedPayload.samples.join(', ')}]`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
      }
    } else if (data.object) {
      console.log(`Decoded object: ${JSON.stringify(data.object)}`);
    }
    if (rx) {
      console.log(`RSSI          : ${rx.rssi} dBm`);
      console.log(`SNR           : ${rx.snr} dB`);
      console.log(`Gateway       : ${rx.gatewayId || "N/A"}`);
      console.log(
        `Frequency     : ${
          rx.frequency ? (rx.frequency / 1e6).toFixed(3) + " MHz" : "N/A"
        }`,
      );
      console.log(`DataRate      : ${rx.dataRate?.modulation || "N/A"}`);
    }
    console.log("──────────────────────────────────────────\n");

    // Save to MongoDB
    const sensorData = new SensorData({
      deviceName,
      devEui,
      timestamp: data.time || new Date(),
      rssi: rx?.rssi,
      snr: rx?.snr,
      fPort: data.fPort,
      data: data.data,
      decodedPayload: decodedPayload,
      gatewayId: rx?.gatewayId,
      frequency: rx?.frequency,
      dataRate: rx?.dataRate?.modulation,
      spreadingFactor,
      fCnt: data.fCnt
    });

    sensorData.save()
      .then(() => {
        console.log("💾 Saved to MongoDB");
      })
      .catch((err) => {
        console.error("❌ Error saving to MongoDB:", err.message);
      });

    // Broadcast to WebSocket clients
    broadcastSensorData({
      deviceName,
      devEui,
      topic: receivedTopic,
      spreadingFactor,
      timestamp: data.time || new Date().toISOString(),
      rssi: rx?.rssi,
      snr: rx?.snr,
      fPort: data.fPort,
      data: data.data,
      decodedPayload: decodedPayload,
    });
  } catch (err) {
    console.error("❌ Message parsing error:", err.message);
  }
});

client.on("error", (err) => console.error("❌ MQTT error:", err.message));
client.on("reconnect", () => console.log("🔄 Reconnecting to MQTT..."));
client.on("offline", () => console.log("⚠️  MQTT offline"));
client.on("close", () => console.log("🔌 MQTT connection closed"));

// ─── Graceful shutdown ───────────────────────────────────
const shutdown = () => {
  console.log("\n🛑 Shutting down...");
  client.end(false, {}, () => {
    server.close(() => process.exit(0));
  });
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

// ─── Start HTTP server ───────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
