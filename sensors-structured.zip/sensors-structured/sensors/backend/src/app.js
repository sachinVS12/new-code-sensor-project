const fs = require("fs");
const path = require("path");
const express = require("express");
const routes = require("./routes");
const { FRONTEND_DIST } = require("./config/env");

const app = express();

app.use(express.json());

// REST API
app.use("/api", routes);
app.use("/api", (req, res) => res.status(404).json({ error: "API route not found" }));

// Production: serve the built frontend (run "npm run build" in frontend/ first).
// In development the Vite dev server serves the UI and proxies /api and /ws here.
if (fs.existsSync(FRONTEND_DIST)) {
  app.use(express.static(FRONTEND_DIST));
  app.get("*", (req, res) => res.sendFile(path.join(FRONTEND_DIST, "index.html")));
}

module.exports = app;
