const Gateway = require("../models/Gateway");

const createGateway = async (req, res) => {
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;

    if (!gatewayName || !gatewayEui || !destinationIp || !port || !mode) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const newGateway = new Gateway({
      gatewayName,
      gatewayEui,
      destinationIp,
      port,
      mode
    });

    await newGateway.save();
    console.log(`✅ Gateway created: ${gatewayName} (${gatewayEui})`);
    res.status(201).json({ message: "Gateway created successfully", gateway: newGateway });
  } catch (err) {
    console.error("❌ Error creating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to create gateway" });
  }
};

const getGateways = async (req, res) => {
  try {
    const gateways = await Gateway.find({});
    res.json(gateways);
  } catch (err) {
    console.error("❌ Error fetching gateways:", err.message);
    res.status(500).json({ error: "Failed to fetch gateways" });
  }
};

const deleteGateway = async (req, res) => {
  try {
    const deleted = await Gateway.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Gateway not found" });
    console.log(`✅ Gateway deleted: ${req.params.id}`);
    res.json({ message: "Gateway deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting gateway:", err.message);
    res.status(500).json({ error: "Failed to delete gateway" });
  }
};

const updateGateway = async (req, res) => {
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;
    const updatedGateway = await Gateway.findByIdAndUpdate(
      req.params.id,
      { gatewayName, gatewayEui, destinationIp, port, mode },
      { new: true, runValidators: true }
    );
    if (!updatedGateway) return res.status(404).json({ error: "Gateway not found" });
    console.log(`✅ Gateway updated: ${req.params.id}`);
    res.json({ message: "Gateway updated successfully", gateway: updatedGateway });
  } catch (err) {
    console.error("❌ Error updating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to update gateway" });
  }
};

module.exports = { createGateway, getGateways, deleteGateway, updateGateway };
