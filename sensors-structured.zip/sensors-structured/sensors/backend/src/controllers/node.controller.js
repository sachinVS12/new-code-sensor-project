const Node = require("../models/Node");
const FeedData = require("../models/FeedData");
const { deviceNames } = require("../services/deviceRegistry");
const { buildTopic, subscribeTopic, unsubscribeTopic } = require("../services/mqtt.service");
const { EUI_REGEX } = require("../utils/eui");

// Body: { deviceName, devEui, applicationId } (+ optional mode, gateway)
// mqttTopic is generated automatically.
const createNode = async (req, res) => {
  try {
    const { deviceName, devEui, applicationId, mode, gateway } = req.body;

    if (!deviceName?.trim() || !devEui?.trim() || !applicationId?.trim()) {
      return res.status(400).json({ error: "Device name, DevEUI and Application ID are required" });
    }
    const eui = devEui.trim().toLowerCase();
    if (!EUI_REGEX.test(eui)) {
      return res.status(400).json({ error: "DevEUI must be 16 hex characters" });
    }

    const newNode = new Node({
      deviceName: deviceName.trim(),
      devEui: eui,
      applicationId: applicationId.trim(),
      mqttTopic: buildTopic(applicationId.trim(), eui),
      mode: mode || "OTAA",
      gateway: gateway || "",
    });

    await newNode.save();

    deviceNames[newNode.devEui] = newNode.deviceName;
    subscribeTopic(newNode.mqttTopic);

    console.log(`✅ Node created: ${newNode.deviceName} (${newNode.devEui})`);
    console.log(`📡 MQTT topic: ${newNode.mqttTopic}`);
    res.status(201).json({ message: "Node created successfully", node: newNode });
  } catch (err) {
    console.error("❌ Error creating node:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Device name or DevEUI already exists" });
    }
    res.status(500).json({ error: "Failed to create node" });
  }
};

const getNodes = async (req, res) => {
  try {
    const nodes = await Node.find({});
    res.json(nodes);
  } catch (err) {
    console.error("❌ Error fetching nodes:", err.message);
    res.status(500).json({ error: "Failed to fetch nodes" });
  }
};

const updateNode = async (req, res) => {
  try {
    const { deviceName, devEui, applicationId, mode, gateway } = req.body;

    if (!deviceName?.trim() || !devEui?.trim() || !applicationId?.trim()) {
      return res.status(400).json({ error: "Device name, DevEUI and Application ID are required" });
    }
    const eui = devEui.trim().toLowerCase();
    if (!EUI_REGEX.test(eui)) {
      return res.status(400).json({ error: "DevEUI must be 16 hex characters" });
    }

    const old = await Node.findById(req.params.id);
    if (!old) return res.status(404).json({ error: "Node not found" });

    const updated = await Node.findByIdAndUpdate(
      req.params.id,
      {
        deviceName: deviceName.trim(),
        devEui: eui,
        applicationId: applicationId.trim(),
        mqttTopic: buildTopic(applicationId.trim(), eui),
        mode: mode || "OTAA",
        gateway: gateway || "",
      },
      { new: true, runValidators: true }
    );

    delete deviceNames[old.devEui.toLowerCase()];
    deviceNames[updated.devEui] = updated.deviceName;

    if (old.mqttTopic !== updated.mqttTopic) {
      await unsubscribeTopic(old.mqttTopic, old._id);
      subscribeTopic(updated.mqttTopic);
    }

    console.log(`✅ Node updated: ${updated.deviceName} (${updated.devEui})`);
    res.json({ message: "Node updated successfully", node: updated });
  } catch (err) {
    console.error("❌ Error updating node:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Device name or DevEUI already exists" });
    }
    res.status(500).json({ error: "Failed to update node" });
  }
};

const deleteNode = async (req, res) => {
  try {
    const node = await Node.findByIdAndDelete(req.params.id);
    if (!node) return res.status(404).json({ error: "Node not found" });
    delete deviceNames[node.devEui.toLowerCase()];
    await unsubscribeTopic(node.mqttTopic, node._id);
    await FeedData.deleteMany({ devEui: node.devEui });
    console.log(`✅ Node deleted: ${req.params.id}`);
    res.json({ message: "Node deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting node:", err.message);
    res.status(500).json({ error: "Failed to delete node" });
  }
};

module.exports = { createNode, getNodes, updateNode, deleteNode };
