const SensorData = require("../models/SensorData");
const { deviceNames } = require("./deviceRegistry");
const { handleDownlinkEvent } = require("./downlink.service");
const { broadcastSensorData } = require("./websocket.service");
const { CHUNK_DEVICES, decodeChunkPacket, printChunkResult } = require("../decoders/chunkDecoder");
const { decodeRak5146 } = require("../decoders/rak5146Decoder");

// Every message received from the MQTT broker (uplinks + downlink txack/ack events)
function handleMqttMessage(receivedTopic, message) {
  try {
    const data = JSON.parse(message.toString());

    // Downlink status events are not uplinks
    if (receivedTopic.endsWith("/event/txack") || receivedTopic.endsWith("/event/ack")) {
      handleDownlinkEvent(receivedTopic, data);
      return;
    }

    const devEui = (data.deviceInfo?.devEui || "").toLowerCase();
    const deviceName = deviceNames[devEui] || "Unknown";
    const appIdFromTopic = receivedTopic.split("/")[1];
    const rx =
      Array.isArray(data.rxInfo) && data.rxInfo.length ? data.rxInfo[0] : null;
    const spreadingFactor =
      data.txInfo?.modulation?.lora?.spreadingFactor ?? data.dr ?? undefined;

    console.log("──────────────────────────────────────────");
    console.log(`Topic         : ${receivedTopic}`);
    console.log(`App ID        : ${appIdFromTopic}`);
    console.log(`Device        : ${deviceName}`);
    console.log(`DevEUI        : ${devEui}`);
    console.log(
      `Profile       : ${data.deviceInfo?.deviceProfileName || "N/A"}`,
    );
    console.log(`Received at   : ${data.time || "N/A"}`);
    console.log(`FCnt          : ${data.fCnt ?? "N/A"}`);
    console.log(`FPort         : ${data.fPort ?? "N/A"}`);
    console.log(`Raw payload   : ${data.data || "N/A"}`);

    // Decode payload if FPort 2
    let decodedPayload = null;
    if (data.data && data.fPort != null && CHUNK_DEVICES.has(devEui)) {
      // Chunked-dataset device: 7-byte header + little-endian samples
      decodedPayload = decodeChunkPacket(devEui, data.fPort, data.data);
      printChunkResult(deviceName, devEui, decodedPayload);
    } else if (data.data && data.fPort != null) {
      decodedPayload = decodeRak5146(data.fPort, data.data);
      if (decodedPayload.error) {
        console.log(`Decode error  : ${decodedPayload.error}`);
      } else {
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`📊 PAYLOAD DECODED - ${deviceName} (${devEui})`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`Version       : ${decodedPayload.version}`);
        console.log(`Type          : 0x${decodedPayload.type.toString(16).padStart(2, "0")}`);
        console.log(`Count         : ${decodedPayload.count}`);
        console.log(`Duration      : ${decodedPayload.duration} ms`);
        console.log(`Battery       : ${decodedPayload.batteryV} V (raw ${decodedPayload.batteryRaw})`);
        console.log(`Samples       : ${decodedPayload.sampleCount}`);
        console.log(`Stats         : min=${decodedPayload.min} | max=${decodedPayload.max} | avg=${decodedPayload.avg}`);
        console.log(`All Samples   : [${decodedPayload.samples.join(', ')}]`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
      }
    } else if (data.object) {
      console.log(`Decoded object: ${JSON.stringify(data.object)}`);
    }
    if (rx) {
      console.log(`RSSI          : ${rx.rssi} dBm`);
      console.log(`SNR           : ${rx.snr} dB`);
      console.log(`Gateway       : ${rx.gatewayId || "N/A"}`);
      console.log(
        `Frequency     : ${
          rx.frequency ? (rx.frequency / 1e6).toFixed(3) + " MHz" : "N/A"
        }`,
      );
      console.log(`DataRate      : ${rx.dataRate?.modulation || "N/A"}`);
    }
    console.log("──────────────────────────────────────────\n");

    // Save to MongoDB
    const sensorData = new SensorData({
      deviceName,
      devEui,
      timestamp: data.time || new Date(),
      rssi: rx?.rssi,
      snr: rx?.snr,
      fPort: data.fPort,
      data: data.data,
      decodedPayload: decodedPayload,
      gatewayId: rx?.gatewayId,
      frequency: rx?.frequency,
      dataRate: rx?.dataRate?.modulation,
      spreadingFactor,
      fCnt: data.fCnt
    });

    sensorData.save()
      .then(() => {
        console.log("💾 Saved to MongoDB");
      })
      .catch((err) => {
        console.error("❌ Error saving to MongoDB:", err.message);
      });

    // Broadcast to WebSocket clients
    broadcastSensorData({
      deviceName,
      devEui,
      topic: receivedTopic,
      spreadingFactor,
      timestamp: data.time || new Date().toISOString(),
      rssi: rx?.rssi,
      snr: rx?.snr,
      fPort: data.fPort,
      data: data.data,
      decodedPayload: decodedPayload,
    });
  } catch (err) {
    console.error("❌ Message parsing error:", err.message);
  }
}

module.exports = { handleMqttMessage };
