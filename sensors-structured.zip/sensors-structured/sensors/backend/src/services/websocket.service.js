const WebSocket = require("ws");

let wss = null;

// Attach the WebSocket server to the HTTP server (browser connects to /ws)
function initWebSocket(server) {
  wss = new WebSocket.Server({ server, path: "/ws" });
  console.log("🌐 WebSocket server initialized");
  return wss;
}

function sendToAll(message) {
  if (!wss) return;
  wss.clients.forEach((c) => {
    if (c.readyState === WebSocket.OPEN) c.send(message);
  });
}

// Broadcast sensor data to all connected WebSocket clients
function broadcastSensorData(data) {
  const clientCount = wss ? wss.clients.size : 0;
  console.log(`📡 Broadcasting to ${clientCount} WebSocket clients:`, JSON.stringify(data));
  sendToAll(JSON.stringify(data));
}

// Broadcast console logs to all connected WebSocket clients
function broadcastLog(message) {
  sendToAll(JSON.stringify({ type: "log", message }));
}

// Push a downlink change (created / updated / deleted) with the full record to every open page,
// so the Task page shows new Queued / Transmitted / Acknowledged times at once without reloading
function broadcastDownlinkUpdate(downlink, event = "updated") {
  sendToAll(JSON.stringify({ type: "downlink", event, downlink }));
}

// Make every console.log also show up in the browser log panel
function hookConsoleToWebSocket() {
  const originalLog = console.log;
  console.log = function (...args) {
    originalLog.apply(console, args);
    const message = args.map((arg) => (typeof arg === "object" ? JSON.stringify(arg) : String(arg))).join(" ");
    broadcastLog(message);
  };
}

module.exports = {
  initWebSocket,
  hookConsoleToWebSocket,
  broadcastSensorData,
  broadcastLog,
  broadcastDownlinkUpdate,
};
