import { useEffect, useState } from 'react';

// Gateway Page Component
export default function GatewayPage({ isCollapsed }) {
    const [activeTab, setActiveTab] = useState('creation');
    const [formData, setFormData] = useState({
        gatewayName: '',
        gatewayEui: '',
        destinationIp: '',
        port: '',
        mode: 'local'
    });
    const [gateways, setGateways] = useState([]);
    const [editingId, setEditingId] = useState(null);

    // Load gateways from API on component mount
    useEffect(() => {
        fetchGateways();
    }, []);

    const fetchGateways = async () => {
        try {
            const response = await fetch('/api/gateways');
            const data = await response.json();
            setGateways(data);
        } catch (error) {
            console.error('Error fetching gateways:', error);
        }
    };

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };

    const tabContainerStyle = {
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
        overflow: 'hidden'
    };

    const tabHeaderStyle = {
        display: 'flex',
        borderBottom: '2px solid #ecf0f1'
    };

    const tabStyle = {
        padding: '15px 30px',
        cursor: 'pointer',
        backgroundColor: '#f8f9fa',
        border: 'none',
        fontSize: '16px',
        fontWeight: 'bold',
        color: '#666',
        transition: 'all 0.3s'
    };

    const activeTabStyle = {
        ...tabStyle,
        backgroundColor: 'white',
        color: '#3498db',
        borderBottom: '2px solid #3498db'
    };

    const tabContentStyle = {
        padding: '30px'
    };

    // Form sits on the left, fields all the same width and height
    const formStyle = {
        maxWidth: '600px',
        margin: 0,
        textAlign: 'left'
    };

    const inputStyle = {
        display: 'block',
        width: '100%',
        height: '44px',
        padding: '0 12px',
        margin: 0,
        boxSizing: 'border-box',
        border: '1px solid #ddd',
        borderRadius: '4px',
        fontSize: '14px',
        fontFamily: 'inherit',
        backgroundColor: 'white'
    };

    const labelStyle = {
        display: 'block',
        marginBottom: '6px',
        textAlign: 'left',
        fontWeight: 'bold',
        color: '#333'
    };

    const buttonStyle = {
        width: '100%',
        padding: '12px',
        backgroundColor: '#3498db',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        fontSize: '16px',
        fontWeight: 'bold',
        cursor: 'pointer'
    };

    const tableStyle = {
        width: '100%',
        borderCollapse: 'collapse'
    };

    const thStyle = {
        backgroundColor: '#34495e',
        color: 'white',
        padding: '12px',
        textAlign: 'left',
        fontWeight: 'bold',
        borderBottom: '2px solid #2c3e50'
    };

    const tdStyle = {
        padding: '12px',
        borderBottom: '1px solid #ecf0f1',
        color: '#333'
    };

    const selectStyle = {
        display: 'block',
        width: '100%',
        height: '44px',
        padding: '0 12px',
        margin: 0,
        boxSizing: 'border-box',
        border: '1px solid #ddd',
        borderRadius: '4px',
        fontSize: '14px',
        fontFamily: 'inherit',
        backgroundColor: 'white'
    };

    const editButtonStyle = {
        padding: '6px 12px',
        backgroundColor: '#f39c12',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        marginRight: '5px',
        fontSize: '12px'
    };

    const deleteButtonStyle = {
        padding: '6px 12px',
        backgroundColor: '#e74c3c',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '12px'
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        try {
            let response;
            if (editingId !== null) {
                response = await fetch(`/api/gateways/${editingId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
            } else {
                response = await fetch('/api/gateways', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
            }

            const result = await response.json();

            if (response.ok) {
                alert(editingId !== null ? 'Gateway updated successfully!' : 'Gateway created successfully!');
                fetchGateways();
                setFormData({
                    gatewayName: '',
                    gatewayEui: '',
                    destinationIp: '',
                    port: '',
                    mode: 'local'
                });
                setEditingId(null);
            } else {
                alert('Error: ' + (result.error || 'Failed to save gateway'));
            }
        } catch (error) {
            console.error('Error saving gateway:', error);
            alert('Failed to connect to server');
        }
    };

    const handleEdit = (gateway) => {
        setFormData({
            gatewayName: gateway.gatewayName,
            gatewayEui: gateway.gatewayEui,
            destinationIp: gateway.destinationIp,
            port: gateway.port,
            mode: gateway.mode
        });
        setEditingId(gateway._id);
        setActiveTab('creation');
    };

    const handleDelete = async (id) => {
        if (!confirm('Are you sure you want to delete this gateway?')) return;
        
        try {
            const response = await fetch(`/api/gateways/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                alert('Gateway deleted successfully!');
                fetchGateways();
            } else {
                alert('Failed to delete gateway');
            }
        } catch (error) {
            console.error('Error deleting gateway:', error);
            alert('Failed to connect to server');
        }
    };

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '30px' }}>Gateway Management</h2>
            
            <div style={tabContainerStyle}>
                <div style={tabHeaderStyle}>
                    <button
                        style={activeTab === 'creation' ? activeTabStyle : tabStyle}
                        onClick={() => setActiveTab('creation')}
                    >
                        Gateway Creation
                    </button>
                    <button
                        style={activeTab === 'list' ? activeTabStyle : tabStyle}
                        onClick={() => setActiveTab('list')}
                    >
                        Gateway List
                    </button>
                </div>

                <div style={tabContentStyle}>
                    {activeTab === 'creation' && (
                        <form style={formStyle} onSubmit={handleSubmit}>
                            <h3 style={{ marginBottom: '20px', color: '#666' }}>
                                {editingId !== null ? 'Edit Gateway' : 'Create New Gateway'}
                            </h3>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Gateway Name</label>
                                <input
                                    type="text"
                                    name="gatewayName"
                                    value={formData.gatewayName}
                                    onChange={(e) => setFormData({ ...formData, gatewayName: e.target.value })}
                                    style={inputStyle}
                                    placeholder="Enter gateway name"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Gateway EUI</label>
                                <input
                                    type="text"
                                    name="gatewayEui"
                                    value={formData.gatewayEui}
                                    onChange={(e) => setFormData({ ...formData, gatewayEui: e.target.value })}
                                    style={inputStyle}
                                    placeholder="Enter gateway EUI"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Destination IP</label>
                                <input
                                    type="text"
                                    name="destinationIp"
                                    value={formData.destinationIp}
                                    onChange={(e) => setFormData({ ...formData, destinationIp: e.target.value })}
                                    style={inputStyle}
                                    placeholder="Enter destination IP"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Port</label>
                                <input
                                    type="text"
                                    name="port"
                                    value={formData.port}
                                    onChange={(e) => setFormData({ ...formData, port: e.target.value })}
                                    style={inputStyle}
                                    placeholder="Enter port"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Mode</label>
                                <select
                                    name="mode"
                                    value={formData.mode}
                                    onChange={(e) => setFormData({ ...formData, mode: e.target.value })}
                                    style={selectStyle}
                                >
                                    <option value="local">Local</option>
                                    <option value="cloud">Cloud</option>
                                </select>
                            </div>
                            <button type="submit" style={buttonStyle}>
                                {editingId !== null ? 'Update Gateway' : 'Create Gateway'}
                            </button>
                            {editingId !== null && (
                                <button
                                    type="button"
                                    style={{ ...buttonStyle, backgroundColor: '#95a5a6', marginTop: '10px' }}
                                    onClick={() => {
                                        setEditingId(null);
                                        setFormData({
                                            gatewayName: '',
                                            gatewayEui: '',
                                            destinationIp: '',
                                            port: '',
                                            mode: 'local'
                                        });
                                    }}
                                >
                                    Cancel
                                </button>
                            )}
                        </form>
                    )}

                    {activeTab === 'list' && (
                        <div>
                            <h3 style={{ marginBottom: '20px', color: '#666' }}>Gateway List</h3>
                            <table style={tableStyle}>
                                <thead>
                                    <tr>
                                        <th style={thStyle}>Gateway Name</th>
                                        <th style={thStyle}>Gateway EUI</th>
                                        <th style={thStyle}>Destination IP</th>
                                        <th style={thStyle}>Port</th>
                                        <th style={thStyle}>Mode</th>
                                        <th style={thStyle}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {gateways.length === 0 ? (
                                        <tr>
                                            <td colSpan="6" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                                No gateways available
                                            </td>
                                        </tr>
                                    ) : (
                                        gateways.map((gateway) => (
                                            <tr key={gateway._id}>
                                                <td style={tdStyle}>{gateway.gatewayName}</td>
                                                <td style={tdStyle}>{gateway.gatewayEui}</td>
                                                <td style={tdStyle}>{gateway.destinationIp}</td>
                                                <td style={tdStyle}>{gateway.port}</td>
                                                <td style={tdStyle}>{gateway.mode}</td>
                                                <td style={tdStyle}>
                                                    <button
                                                        style={editButtonStyle}
                                                        onClick={() => handleEdit(gateway)}
                                                    >
                                                        Edit
                                                    </button>
                                                    <button
                                                        style={deleteButtonStyle}
                                                        onClick={() => handleDelete(gateway._id)}
                                                    >
                                                        Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
