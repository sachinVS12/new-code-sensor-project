// Adds one decoded uplink to a payload history list (same rules the Graph page uses)
export function applyPayloadEntry(prev, dp, time) {
    if (!dp) return prev;
    if (dp.kind === 'chunk' && dp.chunkSamples) {
        return [...prev, {
            time,
            samples: dp.chunkSamples,
            avg: null,
            min: Math.min(...dp.chunkSamples),
            max: Math.max(...dp.chunkSamples),
            battery: dp.battery || 'N/A',
            isChunk: true,
            progress: `${dp.receivedBytes}/${dp.totalBytes} bytes`
        }].slice(-100);
    }
    if (dp.kind === 'dataset' && dp.samples) {
        const filtered = prev.filter(p => !p.isChunk);
        filtered.push({ time, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.battery || 'N/A', isChunk: false });
        return filtered.slice(-100);
    }
    if (dp.samples) {
        return [...prev, { time, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.batteryV, isChunk: false }].slice(-100);
    }
    return prev;
}
