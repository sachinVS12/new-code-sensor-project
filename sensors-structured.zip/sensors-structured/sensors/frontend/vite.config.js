import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), '');
    const backend = env.BACKEND_URL || 'http://localhost:3000';

    return {
        plugins: [react()],
        server: {
            port: 5173,
            // In development the UI talks to the backend through these proxies,
            // so the frontend code can keep using relative URLs (/api/..., /ws).
            proxy: {
                '/api': backend,
                '/ws': { target: backend.replace(/^http/, 'ws'), ws: true },
            },
        },
        build: { outDir: 'dist' },
    };
});
