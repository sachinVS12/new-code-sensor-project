# LoRaWAN Sensor Dashboard

Two separate apps in one repo:

```
sensors/
├── backend/                 Node.js API + MQTT + WebSocket + MongoDB
│   ├── src/
│   │   ├── server.js        entry point (start-up, shutdown)
│   │   ├── app.js           Express app (API routes, serves frontend/dist in production)
│   │   ├── config/          env.js (.env loading/validation), db.js (MongoDB)
│   │   ├── routes/          URL -> controller mapping (/api/...)
│   │   ├── controllers/     request handlers (nodes, gateways, downlinks, feed-data, dashboard, latest)
│   │   ├── services/        mqtt, websocket, uplink message handling, downlink status, device registry
│   │   ├── decoders/        payload decoders (chunked dataset, RAK5146)
│   │   ├── models/          Mongoose models
│   │   └── utils/           small helpers (EUI)
│   ├── scripts/sender.js    test publisher (npm run sender -- chunk | rak)
│   ├── certs/               MQTT CA certificate (ca.pem), not committed
│   └── .env.example
└── frontend/                React + Webpack UI
    ├── public/index.html
    ├── webpack.config.js    build + dev proxy: /api and /socket -> backend
    └── src/
        ├── main.jsx         entry
        ├── App.jsx          page switching + live WebSocket data
        ├── pages/           Dashboard, Gateway, Device Creation, Tabular, Graph, Payload view, Downlink, Task
        ├── components/
        │   ├── layout/      Sidebar, Navbar
        │   └── charts/      SimpleLineChart, PayloadSamples charts
        ├── utils/           payload.js
        └── styles/          global.css
```

## Setup

```bash
npm run install:all                 # installs backend + frontend dependencies
cp backend/.env.example backend/.env   # then fill in MQTT / MongoDB values
```

## Development (two terminals)

```bash
npm run dev:backend      # http://localhost:3000  (API + WebSocket at /socket)
npm run dev:frontend     # http://localhost:5173  (open this one)
```

## Production (one server)

```bash
npm run build            # builds frontend/dist
npm start                # backend serves the API and the built UI on http://localhost:3000
```

## ChirpStack sync (optional)

When a gateway or device is created in the dashboard it can be created in ChirpStack at the same time.
Add these to `backend/.env`:

```
CHIRPSTACK_API_URL=http://YOUR_CHIRPSTACK_IP:8090   # the chirpstack-rest-api proxy, not the web UI port 8080
CHIRPSTACK_API_TOKEN=...                            # API key from the ChirpStack web UI
CHIRPSTACK_TENANT_ID=                               # optional, first tenant is used if empty
CHIRPSTACK_DEVICE_PROFILE_ID=                       # optional default device profile
```

- Devices: the Application must already exist in ChirpStack (its ID is the "Application ID" in the form).
  Pick a Device Profile and enter the AppKey (OTAA) in the form.
- Create, edit and delete are all synced. Delete removes it from ChirpStack too (if it is already gone there, that is fine).
- Edit changes the name (and, for devices, the device profile and AppKey if you fill them in). Fields you leave empty stay as they are in ChirpStack.
- ChirpStack cannot change a device's DevEUI or Application, or a gateway's EUI, on an existing entry. If you edit one of those here, the entry is created again in ChirpStack and the old one removed.
- Device Profile page (sidebar, after Device Creation): the *Device Profile Creation* tab creates a profile in ChirpStack (name, region, MAC version, regional parameters, uplink interval, OTAA / Class-B / Class-C, payload codec) and the *Device Profile List* tab shows the profiles in ChirpStack with Edit and Delete buttons. Edit opens the profile in the form and saves the changes to ChirpStack (fields the form does not show stay as they are). Delete asks for confirmation and removes the profile from ChirpStack; ChirpStack refuses if devices still use it. Profiles are stored only in ChirpStack, not in the dashboard database. A new profile also appears in the Device Profile dropdown of Device Creation after the page is reloaded.
- Gateway Region ID: pick one of EU868, EU433, US915, AU915, AS923, IN865, KR920, CN470, RU864. ChirpStack gateways have no region field, so the choice is saved there as the gateway tag `region_id`.
- Leave the variables empty to turn the sync off.

## API

`/api/nodes`, `/api/gateways`, `/api/downlinks`, `/api/feed-data`, `/api/dashboard`, `/api/latest`, `/api/chirpstack/status`, `/api/device-profiles`
(unchanged from before). Live updates: WebSocket at `/socket`.

## Notifications

Success and error messages are shown as toast notifications (top right, closed by themselves after a few seconds or with the x) instead of browser alert boxes. Use `toast.success / error / warning / info` from `frontend/src/utils/toast.js`; `ToastContainer` is mounted once in `App.jsx`. 

## Pop-up windows

Delete confirmations and other pop-ups use styled windows instead of the browser's own boxes: `confirmDialog({ title, message, confirmText })` from `frontend/src/utils/confirm.js` returns a promise (true / false), and `components/common/Modal.jsx` is the general pop-up window (used for the Task page "Downlink data" popup). Esc or a click outside closes them; `ConfirmDialogHost` is mounted once in `App.jsx`.

## Chunked ADC datasets (STM32 node)

Uplinks of the chunked-dataset node start with a 3-byte header (type, total chunks, chunk number, 0-based). Types: `00` single and `01` batch (16-bit little-endian samples), `02` probe (DR test), `03` packed 12-bit dataset (two samples in every 3 bytes; 4096 samples per dataset). Chunks may arrive out of order or twice; the dataset completes when every chunk number has arrived. Settings in `backend/.env`: `CHUNK_DEVICE_EUIS` (extra DevEUIs), `CHUNK_FPORT` (default 2) and `CHUNK_PACK12_LAYOUT` (`lsb` or `msb`, the bit order of the packed samples; compare the first samples in the server log with the node's serial dump and switch it if they differ). Run `node backend/test/chunkDecoder.test.js` to check the decoder.

## Phones and small screens

At 768 px wide or less the layout switches to a phone layout (`hooks/useIsMobile.js` + the `@media` block at the end of `frontend/src/styles/global.css`): the sidebar becomes a slide-in menu opened with the menu button in the navbar (tap outside it or pick a page to close it), pages use the full width, two-column forms become one column, and wide tables scroll sideways. Pages are mounted inside `<main className="page-area">` in `App.jsx`; the phone rules apply to everything inside it.

## Application page

Sidebar item after Device Profile, with two tabs. *Application Creation* creates an application in ChirpStack (name, optional description). *Application List* shows the applications in ChirpStack with their Application ID and a Copy button; that ID is the "Application ID" to enter in Device Creation. Applications are stored only in ChirpStack. API: `GET` and `POST /api/applications` (needs `CHIRPSTACK_API_URL` and `CHIRPSTACK_API_TOKEN`).

The Application List also has a **Device** column with an **eye** icon (with the number of devices) and a round **+**. The eye opens a pop-up with the device name and Device EUI of every device in that application (each row has an Edit button that opens the device in Device Creation). The **+** opens Device Creation to add a new device with that application already chosen. In Device Creation the **Application ID** is now a dropdown of the ChirpStack applications (a text box when ChirpStack sync is off).

The Application List has an **Actions** column. **Edit** (orange) opens the application in the form of the first tab (name and description can be changed; the tab is called "Edit Application") and saves the change to ChirpStack. **Delete** (red) asks for confirmation and deletes the application in ChirpStack; ChirpStack deletes all devices of an application together with it, so the devices of that application saved in the dashboard (and their saved feed data) are removed as well. If ChirpStack refuses the delete, nothing is removed in the dashboard. API: `GET`, `PUT` and `DELETE /api/applications/:id`.

## API design (IDs)

The whole project is ID based: devices point to their application, device profile and gateway by ID, and everything else points to a device by its `devEui`. Names are only for display. The full list of endpoints, the ID formats and the rules (reference checks, clean-up on delete) are in [`docs/API.md`](docs/API.md). Run all backend tests with `npm test` in `backend/`.
