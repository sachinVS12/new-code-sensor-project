# LoRaWAN Sensor Dashboard

Two separate apps in one repo:

```
sensors/
├── backend/                 Node.js API + MQTT + WebSocket + MongoDB
│   ├── src/
│   │   ├── server.js        entry point (start-up, shutdown)
│   │   ├── app.js           Express app (API routes, serves frontend/dist in production)
│   │   ├── config/          env.js (.env loading/validation), db.js (MongoDB)
│   │   ├── routes/          URL -> controller mapping (/api/...)
│   │   ├── controllers/     request handlers (nodes, gateways, downlinks, feed-data, dashboard, latest)
│   │   ├── services/        mqtt, websocket, uplink message handling, downlink status, device registry
│   │   ├── decoders/        payload decoders (chunked dataset, RAK5146)
│   │   ├── models/          Mongoose models
│   │   └── utils/           small helpers (EUI)
│   ├── scripts/sender.js    test publisher (npm run sender -- chunk | rak)
│   ├── certs/               MQTT CA certificate (ca.pem), not committed
│   └── .env.example
└── frontend/                React + Webpack UI
    ├── public/index.html
    ├── webpack.config.js    build + dev proxy: /api and /socket -> backend
    └── src/
        ├── main.jsx         entry
        ├── App.jsx          page switching + live WebSocket data
        ├── pages/           Dashboard, Gateway, Device Creation, Tabular, Graph, Payload view, Downlink, Task
        ├── components/
        │   ├── layout/      Sidebar, Navbar
        │   └── charts/      SimpleLineChart, PayloadSamples charts
        ├── utils/           payload.js
        └── styles/          global.css
```

## Setup

```bash
npm run install:all                 # installs backend + frontend dependencies
cp backend/.env.example backend/.env   # then fill in MQTT / MongoDB values
```

## Development (two terminals)

```bash
npm run dev:backend      # http://localhost:3000  (API + WebSocket at /socket)
npm run dev:frontend     # http://localhost:5173  (open this one)
```

## Production (one server)

```bash
npm run build            # builds frontend/dist
npm start                # backend serves the API and the built UI on http://localhost:3000
```

## ChirpStack sync (optional)

When a gateway or device is created in the dashboard it can be created in ChirpStack at the same time.
Add these to `backend/.env`:

```
CHIRPSTACK_API_URL=http://YOUR_CHIRPSTACK_IP:8090   # the chirpstack-rest-api proxy, not the web UI port 8080
CHIRPSTACK_API_TOKEN=...                            # API key from the ChirpStack web UI
CHIRPSTACK_TENANT_ID=                               # optional, first tenant is used if empty
CHIRPSTACK_DEVICE_PROFILE_ID=                       # optional default device profile
```

- Devices: the Application must already exist in ChirpStack (its ID is the "Application ID" in the form).
  Pick a Device Profile and enter the AppKey (OTAA) in the form.
- Deleting something here also deletes it in ChirpStack, but only if this dashboard created it there.
- Editing is not synced. Leave the variables empty to turn the sync off.

## API

`/api/nodes`, `/api/gateways`, `/api/downlinks`, `/api/feed-data`, `/api/dashboard`, `/api/latest`, `/api/chirpstack/status`
(unchanged from before). Live updates: WebSocket at `/socket`.
