# LoRaWAN Sensor Dashboard

Two separate apps in one repo:

```
sensors/
├── backend/                 Node.js API + MQTT + WebSocket + MongoDB
│   ├── src/
│   │   ├── server.js        entry point (start-up, shutdown)
│   │   ├── app.js           Express app (API routes, serves frontend/dist in production)
│   │   ├── config/          env.js (.env loading/validation), db.js (MongoDB)
│   │   ├── routes/          URL -> controller mapping (/api/...)
│   │   ├── controllers/     request handlers (nodes, gateways, downlinks, feed-data, dashboard, latest)
│   │   ├── services/        mqtt, websocket, uplink message handling, downlink status, device registry
│   │   ├── decoders/        payload decoders (chunked dataset, RAK5146)
│   │   ├── models/          Mongoose models
│   │   └── utils/           small helpers (EUI)
│   ├── scripts/sender.js    test publisher (npm run sender -- chunk | batch | packed | probe | rak)
│   ├── certs/               MQTT CA certificate (ca.pem), not committed
│   └── .env.example
└── frontend/                React 19 + Vite 6 UI
    ├── index.html           entry page (loads src/main.jsx)
    ├── public/              static files copied as they are (e.g. a login photo)
    ├── vite.config.js       build + dev proxy: /api and /socket -> backend
    └── src/
        ├── main.jsx         entry
        ├── App.jsx          page switching + live WebSocket data
        ├── pages/           Dashboard, Gateway, Device Creation, Tabular, Graph, Payload view, Downlink, Task
        ├── components/
        │   ├── layout/      Sidebar, Navbar
        │   └── charts/      SimpleLineChart, PayloadSamples charts
        ├── utils/           payload.js
        └── styles/          global.css
```

## Setup

Needs **Node.js 18, 20 or 22+** (a Vite 6 requirement; check with `node --version`).

```bash
npm install                         # installs backend + frontend dependencies (Vite 6 and the React plugin are in package.json)
cp backend/.env.example backend/.env   # then fill in MQTT / MongoDB values
```

## Development (two terminals)

```bash
npm run dev:backend      # http://localhost:3000  (API + WebSocket at /socket)
npm run dev:frontend     # http://localhost:5173  (open this one; Vite dev server with hot reload)
```

The dev server sends `/api` and `/socket` to the backend on `http://localhost:3000`; if the backend runs elsewhere, start the frontend with `BACKEND_URL=http://host:port npm run dev:frontend`.

## Production (one server)

```bash
npm run build            # Vite builds frontend/dist
npm start                # backend serves the API and the built UI on http://localhost:3000
```

To look at the production build on its own first: `npm --prefix frontend run preview` (http://localhost:4173, also proxies `/api` and `/socket` to the backend).

## ChirpStack sync (optional)

When a gateway or device is created in the dashboard it can be created in ChirpStack at the same time.
Add these to `backend/.env`:

```
CHIRPSTACK_API_URL=http://YOUR_CHIRPSTACK_IP:8090   # the chirpstack-rest-api proxy, not the web UI port 8080
CHIRPSTACK_API_TOKEN=...                            # API key from the ChirpStack web UI
CHIRPSTACK_TENANT_ID=                               # optional, first tenant is used if empty
CHIRPSTACK_DEVICE_PROFILE_ID=                       # optional default device profile
```

- Devices: the Application must already exist in ChirpStack (its ID is the "Application ID" in the form).
  Pick a Device Profile and enter the AppKey (OTAA) in the form.
- Create, edit and delete are all synced. Delete removes it from ChirpStack too (if it is already gone there, that is fine).
- Edit changes the name (and, for devices, the device profile and AppKey if you fill them in). Fields you leave empty stay as they are in ChirpStack.
- ChirpStack cannot change a device's DevEUI or Application, or a gateway's EUI, on an existing entry. If you edit one of those here, the entry is created again in ChirpStack and the old one removed.
- Device Profile page (sidebar, after Device Creation): the *Device Profile Creation* tab creates a profile in ChirpStack (name, region, MAC version, regional parameters, uplink interval, OTAA / Class-B / Class-C, payload codec) and the *Device Profile List* tab shows the profiles in ChirpStack with Edit and Delete buttons. Edit opens the profile in the form and saves the changes to ChirpStack (fields the form does not show stay as they are). Delete asks for confirmation and removes the profile from ChirpStack; ChirpStack refuses if devices still use it. Profiles are stored only in ChirpStack, not in the dashboard database. A new profile also appears in the Device Profile dropdown of Device Creation after the page is reloaded.
- Gateway Region ID: pick one of EU868, EU433, US915, AU915, AS923, IN865, KR920, CN470, RU864. ChirpStack gateways have no region field, so the choice is saved there as the gateway tag `region_id`.
- Leave the variables empty to turn the sync off.

## API

`/api/nodes`, `/api/gateways`, `/api/downlinks`, `/api/feed-data`, `/api/dashboard`, `/api/latest`, `/api/chirpstack/status`, `/api/device-profiles`
(unchanged from before). Live updates: WebSocket at `/socket`.

## Notifications

Success and error messages are shown as toast notifications (top right, closed by themselves after a few seconds or with the x) instead of browser alert boxes. Use `toast.success / error / warning / info` from `frontend/src/utils/toast.js`; `ToastContainer` is mounted once in `App.jsx`. 

## Pop-up windows

Delete confirmations and other pop-ups use styled windows instead of the browser's own boxes: `confirmDialog({ title, message, confirmText })` from `frontend/src/utils/confirm.js` returns a promise (true / false), and `components/common/Modal.jsx` is the general pop-up window (used for the Task page "Downlink data" popup). Esc or a click outside closes them; `ConfirmDialogHost` is mounted once in `App.jsx`.

## Chunked ADC datasets (STM32 node)

Uplinks of the chunked-dataset node start with a 3-byte header (type, total chunks, chunk number, 0-based). Types: `00` single and `01` batch (16-bit little-endian samples), `02` probe (DR test), `03` packed 12-bit dataset (two samples in every 3 bytes; 4096 samples per dataset). Chunks may arrive out of order or twice; the dataset completes when every chunk number has arrived. Settings in `backend/.env`: `CHUNK_DEVICE_EUIS` (extra DevEUIs), `CHUNK_FPORT` (default 2) and `CHUNK_PACK12_LAYOUT` (`msb` by default, which is what the node firmware's Pack12 sends; `lsb` is the other bit order). **Incomplete datasets:** if chunks are lost, the dataset never completes. It is then saved as its own row with `decodedPayload.kind = "partial"`, either when a new dataset starts first or when no chunk arrives for `CHUNK_PARTIAL_TIMEOUT_SECONDS` (default 120, `0` = off). A partial lists `receivedChunks`, `totalChunks` and `missingChunks`, and keeps the samples that did arrive in `partialSamples` with `stats` (min/max/avg). It has no `samples` or `avg` field on purpose, so it is never mistaken for a complete dataset, and it is saved but not broadcast to the live dashboard. Run `node backend/test/chunkDecoder.test.js` to check the decoder.

## Phones and small screens

At 768 px wide or less the layout switches to a phone layout (`hooks/useIsMobile.js` + the `@media` block at the end of `frontend/src/styles/global.css`): the sidebar becomes a slide-in menu opened with the menu button in the navbar (tap outside it or pick a page to close it), pages use the full width, two-column forms become one column, and wide tables scroll sideways. Pages are mounted inside `<main className="page-area">` in `App.jsx`; the phone rules apply to everything inside it.

## Application page

Sidebar item after Device Profile, with two tabs. *Application Creation* creates an application in ChirpStack (name, optional description). *Application List* shows the applications in ChirpStack with their Application ID and a Copy button; that ID is the "Application ID" to enter in Device Creation. Applications are stored only in ChirpStack. API: `GET` and `POST /api/applications` (needs `CHIRPSTACK_API_URL` and `CHIRPSTACK_API_TOKEN`).

The Application List also has a **Device** column with an **eye** icon (with the number of devices) and a round **+**. The eye opens a pop-up with the device name and Device EUI of every device in that application (each row has an Edit button that opens the device in Device Creation). The **+** opens Device Creation to add a new device with that application already chosen. In Device Creation the **Application ID** is now a dropdown of the ChirpStack applications (a text box when ChirpStack sync is off).

The Application List has an **Actions** column. **Edit** (orange) opens the application in the form of the first tab (name and description can be changed; the tab is called "Edit Application") and saves the change to ChirpStack. **Delete** (red) asks for confirmation and deletes the application in ChirpStack; ChirpStack deletes all devices of an application together with it, so the devices of that application saved in the dashboard (and their saved feed data) are removed as well. If ChirpStack refuses the delete, nothing is removed in the dashboard. API: `GET`, `PUT` and `DELETE /api/applications/:id`.

## API design (IDs)

The whole project is ID based: devices point to their application, device profile and gateway by ID, and everything else points to a device by its `devEui`. Names are only for display. The full list of endpoints, the ID formats and the rules (reference checks, clean-up on delete) are in [`docs/API.md`](docs/API.md). Run all backend tests with `npm test` in `backend/`.

## Production checklist

Done in the code (settings in `backend/.env`, see `.env.example`):

* **Security headers** on every reply (nosniff, frame denial, referrer policy, HSTS behind HTTPS) and a **Content-Security-Policy** on the pages (`DISABLE_CSP=true` turns the CSP off if you need that).
* **Rate limit** on `/api`: `RATE_LIMIT_PER_MINUTE` (default 600 per IP, 0 = off). Behind nginx or a load balancer set `TRUST_PROXY=1`, otherwise every visitor looks like the proxy.
* **Errors are JSON** (invalid JSON body 400, too large 413, anything else 500 without a stack trace); the body limit is `JSON_BODY_LIMIT` (default 2mb).
* **WebSocket origin check**: only the site that serves the UI, localhost, and `ALLOWED_ORIGINS` can open the live connection.
* **Server log is no longer sent to the browsers** (it contained device data). Turn it back on only for debugging with `BROWSER_LOG_STREAM=true`. Uplink payloads are no longer written to the log by the broadcaster.
* **Data retention**: `SENSOR_DATA_RETENTION_DAYS` (e.g. 90) makes MongoDB delete older uplinks automatically. The default 0 keeps everything, so set it before going live; the choice is applied at every start.
* **Spreading factor** is only stored for LoRa uplinks (FSK has none).
* **xlsx** now comes from the SheetJS site (0.20.3). The npm copy (0.18.5) has known vulnerabilities (CVE-2023-30533, CVE-2024-22363) and is no longer updated there. For a build that does not depend on that site, download the `.tgz` into a `vendor/` folder and install it with `file:vendor/xlsx-0.20.3.tgz`.

Still to do before going live (the login is described in the next section):

* **HTTPS.** Terminate TLS in front of the app (nginx, Caddy, a load balancer) and use `mqtts://` for the MQTT broker if it is not on a private network.
* **Packed 12-bit samples** (packet type 3): the decoder now matches the node firmware (`msb`). If your `backend/.env` was copied from an older `.env.example` it may still contain `CHUNK_PACK12_LAYOUT=lsb`; change that line to `msb` or delete it. Then run one full dataset and compare a few samples with the node's serial dump.
* A production build and a click-through of every page, with the real database, MQTT broker and ChirpStack.

## Login

The dashboard needs a login (page with the LoRaWAN illustration on the left, the sign-in form on the right; on narrow screens only the form). One user is set in `backend/.env`:

```
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=...      # make it with: cd backend && npm run hash-password
AUTH_SECRET=...              # long random value that signs the login cookie
SESSION_HOURS=12
```

* The password is stored as a scrypt hash. `ADMIN_PASSWORD` (plain text) works for a quick start but the server warns about it. The server **does not start** without a login setup; for development only, `AUTH_DISABLED=true` turns the login off.
* After a correct login the server sets a session cookie (HttpOnly, SameSite=Strict, Secure on HTTPS). Every `/api` route except `/api/auth/*` and the live WebSocket need that cookie; without it the API answers `401 Not logged in` and the app shows the login page again.
* 10 login attempts per 15 minutes per IP (`429` after that). Changing data from another website is refused (Origin check). Set `AUTH_SECRET`, otherwise everyone is logged out whenever the server restarts.
* Behind HTTPS (nginx, Caddy, a load balancer) also set `TRUST_PROXY=1`, so the cookie gets the Secure flag and the rate limit sees the real client IP.
* Logout is at the bottom of the sidebar, under a card with the signed-in user. The sidebar menu scrolls (with a thin scrollbar) when the window is too low for all items. API: `POST /api/auth/login`, `GET /api/auth/me`, `POST /api/auth/logout` (see `docs/API.md`).
* The illustration is an SVG drawn in `frontend/src/components/auth/SensorsIllustration.jsx` (no image file, works offline). To use a photo instead, put it in `frontend/public/` and use an `<img>` in `LoginPage.jsx`.

## Frontend stack (Vite 6, React 19)

The frontend moved from Webpack 5 + Babel + React 18 to **Vite 6 + React 19** (`@vitejs/plugin-react` 4). What changed: `webpack.config.js` and `public/index.html` are replaced by `vite.config.js` and `index.html` in the frontend root; `__WS_BASE__` (the WebSocket address the code uses) is now set with Vite's `define` (the backend address in development, the page's own host in production); the build output is still `frontend/dist`, so the backend serves it as before. The React code needed no changes: it uses no APIs that React 19 removed. After upgrading, delete the old `frontend/node_modules` and run `npm install` again.

## Sharing the code with the team

* **Do not copy `node_modules`** (zip, USB or chat). Share the project without it, or use git: `.gitignore` already leaves it out. A copied `node_modules` made on another computer or Node version is what causes broken installs.
* After getting the code, run `npm install` once in the project root. It installs the backend and the frontend, including `vite@6` and `@vitejs/plugin-react@4`, so no extra `npm install -D ...` command is needed. Then copy `backend/.env.example` to `backend/.env` and fill it in.
* Commit `frontend/package-lock.json` (and `backend/package-lock.json`) so everyone gets exactly the same versions. If the frontend one does not exist yet, run `npm install` in `frontend/` once and commit the file it creates.
* If a computer still has problems, delete `node_modules` in the root, `backend/` and `frontend/`, then run `npm install` again.

## Payload History: table and Excel export

Tabular View -> the clock icon of a device opens **Payload History**. Use the **Graph | Table** switch at the top:

* **Table** lists every entry of the history (newest first): date and time, Complete or Chunk, chunks received, number of samples, min, max, average and battery. The **eye icon** at the end of each row opens a popup with a preview of that entry: its type, sample count, min, max, average and battery, a small chart of the samples and the first 20 sample values. The popup has a **Download** button that saves that one entry as an Excel file (`payload_history_<device>_entry-<n>_<date-time>.xlsx`, same three sheets, with *all* of the entry's samples). The popup shows a snapshot taken when the icon was clicked, so it does not change while new uplinks arrive.
* **Export to Excel** downloads `payload_history_<device>_<date-time>.xlsx` with three sheets: *Summary* (one row per entry, same columns as the table), *Samples* (one row per sample: entry #, date and time, type, sample #, value) and *Info* (device name, DevEUI, number of entries, export time). Dates are real Excel dates, numbers are real numbers, so sorting and charts work.

The history is kept while the dashboard is open and holds the last 100 entries of the device (a complete dataset replaces its chunks). Run `npm test` in the project root to run the backend and frontend tests.
