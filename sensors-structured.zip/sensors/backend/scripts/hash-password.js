// Makes the value for ADMIN_PASSWORD_HASH in .env:   npm run hash-password
// (or: node scripts/hash-password.js "the password"; a password typed on the command line stays in the shell history)
const readline = require("readline");
const { hashPassword } = require("../src/services/auth.service");

function ask(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(question)) rl.output.write(s); }; // do not echo the typed characters
    rl.question(question, (answer) => { rl.close(); process.stdout.write("\n"); resolve(answer); });
  });
}

(async () => {
  const password = process.argv[2] || (await ask("Password: "));
  if (!password || password.length < 8) {
    console.error("Use a password of at least 8 characters.");
    process.exit(1);
  }
  console.log("\nAdd this line to backend/.env (keep the quotes out, it has no spaces):\n");
  console.log(`ADMIN_PASSWORD_HASH=${hashPassword(password)}\n`);
})();
