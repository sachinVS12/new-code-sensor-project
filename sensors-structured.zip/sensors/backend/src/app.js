const fs = require("fs");
const path = require("path");
const express = require("express");
const routes = require("./routes");
const { FRONTEND_DIST, RATE_LIMIT_PER_MINUTE, TRUST_PROXY, JSON_BODY_LIMIT } = require("./config/env");
const { securityHeaders, createRateLimiter, apiNotFound, errorHandler } = require("./middleware/security");
const { createRequireAuth, originGuard } = require("./middleware/auth");
const { auth, AUTH_DISABLED } = require("./services/auth.instance");

const app = express();

app.disable("x-powered-by");
if (TRUST_PROXY) app.set("trust proxy", /^\d+$/.test(TRUST_PROXY) ? Number(TRUST_PROXY) : TRUST_PROXY);

app.use(securityHeaders);
app.use(express.json({ limit: JSON_BODY_LIMIT }));

// REST API
app.use("/api", createRateLimiter({ max: RATE_LIMIT_PER_MINUTE }));
app.use("/api", originGuard);
app.use("/api/auth", require("./routes/auth.routes"));   // login, who am I, logout: the only routes without a session
app.use("/api", createRequireAuth(auth, { authDisabled: AUTH_DISABLED }), routes);
app.use("/api", apiNotFound);

// Production: serve the built frontend (run "npm run build" in frontend/ first).
// In development the webpack dev server serves the UI and proxies /api and /socket here.
if (fs.existsSync(FRONTEND_DIST)) {
  app.use(express.static(FRONTEND_DIST));
  app.get("*", (req, res) => res.sendFile(path.join(FRONTEND_DIST, "index.html")));
}

// last: any error becomes a JSON reply (no stack traces to the client)
app.use(errorHandler);

module.exports = app;
