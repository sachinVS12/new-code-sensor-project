const path = require("path");

// backend/ folder (where .env, certs/ live)
const rootDir = path.resolve(__dirname, "../..");
require("dotenv").config({ path: path.join(rootDir, ".env") });

const {
  MQTT_HOST,
  MQTT_USERNAME,
  MQTT_PASSWORD,
  MQTT_CA_CERT,
  APPLICATION_ID,
  MONGODB_URI,
  CHIRPSTACK_API_URL,
  CHIRPSTACK_API_TOKEN,
  CHIRPSTACK_TENANT_ID,
  CHIRPSTACK_DEVICE_PROFILE_ID,
} = process.env;

if (!MQTT_HOST) {
  console.error("❌ MQTT_HOST is missing in .env");
  process.exit(1);
}
if (!MONGODB_URI) {
  console.error("❌ MONGODB_URI is missing in .env");
  process.exit(1);
}

module.exports = {
  rootDir,
  PORT: process.env.PORT || 3000,
  MQTT_HOST,
  MQTT_USERNAME,
  MQTT_PASSWORD,
  MQTT_CA_CERT,
  APPLICATION_ID,
  MONGODB_URI,
  // ChirpStack sync (optional). Needs the chirpstack-rest-api proxy (default port 8090) and an API key.
  // When both URL and TOKEN are set, gateways/devices created here are also created in ChirpStack.
  CHIRPSTACK_API_URL: (CHIRPSTACK_API_URL || "").trim(),
  CHIRPSTACK_API_TOKEN: (CHIRPSTACK_API_TOKEN || "").trim(),
  CHIRPSTACK_TENANT_ID: (CHIRPSTACK_TENANT_ID || "").trim(),                   // needed for gateways (auto-detected if empty)
  CHIRPSTACK_DEVICE_PROFILE_ID: (CHIRPSTACK_DEVICE_PROFILE_ID || "").trim(),   // default device profile for new devices
  // A gateway is "active" if it forwarded an uplink within this many minutes
  GATEWAY_ACTIVE_MINUTES: Number(process.env.GATEWAY_ACTIVE_MINUTES) || 15,
  // Hardening (see README "Production checklist")
  RATE_LIMIT_PER_MINUTE: process.env.RATE_LIMIT_PER_MINUTE === undefined ? 600 : Number(process.env.RATE_LIMIT_PER_MINUTE) || 0, // 0 = off
  TRUST_PROXY: (process.env.TRUST_PROXY || "").trim(),                 // e.g. 1 when behind nginx / a load balancer
  JSON_BODY_LIMIT: (process.env.JSON_BODY_LIMIT || "2mb").trim(),
  ALLOWED_ORIGINS: (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean), // extra browser origins for the WebSocket
  BROWSER_LOG_STREAM: process.env.BROWSER_LOG_STREAM === "true",       // stream server logs to the browser log panel (off by default)
  // Uplinks older than this many days are deleted by MongoDB (0 = keep forever)
  SENSOR_DATA_RETENTION_DAYS: Math.max(0, Number(process.env.SENSOR_DATA_RETENTION_DAYS) || 0),
  // Built frontend (frontend/dist). Served by the backend only if it exists.
  FRONTEND_DIST: path.resolve(rootDir, "../frontend/dist"),
};
