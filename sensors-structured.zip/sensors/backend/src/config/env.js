const path = require("path");

// backend/ folder (where .env, certs/ live)
const rootDir = path.resolve(__dirname, "../..");
require("dotenv").config({ path: path.join(rootDir, ".env") });

const {
  MQTT_HOST,
  MQTT_USERNAME,
  MQTT_PASSWORD,
  MQTT_CA_CERT,
  APPLICATION_ID,
  MONGODB_URI,
  CHIRPSTACK_API_URL,
  CHIRPSTACK_API_TOKEN,
  CHIRPSTACK_TENANT_ID,
  CHIRPSTACK_DEVICE_PROFILE_ID,
} = process.env;

if (!MQTT_HOST) {
  console.error("❌ MQTT_HOST is missing in .env");
  process.exit(1);
}
if (!MONGODB_URI) {
  console.error("❌ MONGODB_URI is missing in .env");
  process.exit(1);
}

module.exports = {
  rootDir,
  PORT: process.env.PORT || 3000,
  MQTT_HOST,
  MQTT_USERNAME,
  MQTT_PASSWORD,
  MQTT_CA_CERT,
  APPLICATION_ID,
  MONGODB_URI,
  // ChirpStack sync (optional). Needs the chirpstack-rest-api proxy (default port 8090) and an API key.
  // When both URL and TOKEN are set, gateways/devices created here are also created in ChirpStack.
  CHIRPSTACK_API_URL: (CHIRPSTACK_API_URL || "").trim(),
  CHIRPSTACK_API_TOKEN: (CHIRPSTACK_API_TOKEN || "").trim(),
  CHIRPSTACK_TENANT_ID: (CHIRPSTACK_TENANT_ID || "").trim(),                   // needed for gateways (auto-detected if empty)
  CHIRPSTACK_DEVICE_PROFILE_ID: (CHIRPSTACK_DEVICE_PROFILE_ID || "").trim(),   // default device profile for new devices
  // A gateway is "active" if it forwarded an uplink within this many minutes
  GATEWAY_ACTIVE_MINUTES: Number(process.env.GATEWAY_ACTIVE_MINUTES) || 15,
  // Built frontend (frontend/dist). Served by the backend only if it exists.
  FRONTEND_DIST: path.resolve(rootDir, "../frontend/dist"),
};
