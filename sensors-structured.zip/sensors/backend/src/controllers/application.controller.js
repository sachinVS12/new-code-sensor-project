const chirpstack = require("../services/chirpstack.service");

const notEnabled = (res) =>
  res.status(400).json({ error: "ChirpStack sync is off. Set CHIRPSTACK_API_URL and CHIRPSTACK_API_TOKEN in backend/.env." });

const sendError = (res, err, fallback) => {
  let status = 502;
  if (err.status === 400) status = 400;
  else if (err.notFound) status = 404;
  else if (err.alreadyExists) status = 409;
  const message = err.alreadyExists ? "An application with this name already exists in ChirpStack" : err.message || fallback;
  res.status(status).json({ error: `ChirpStack: ${message}` });
};

// GET /api/applications
const getApplications = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    res.json(await chirpstack.listApplications());
  } catch (err) {
    console.error("❌ ChirpStack application list error:", err.message);
    sendError(res, err, "Failed to load applications");
  }
};

// POST /api/applications   Body: { name, description? }
const createApplication = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const b = req.body || {};
  const name = String(b.name || "").trim();
  const description = String(b.description || "").trim();
  if (!name) return res.status(400).json({ error: "Name is required" });
  if (name.length > 100) return res.status(400).json({ error: "Name must be 100 characters or fewer" });
  if (description.length > 500) return res.status(400).json({ error: "Description must be 500 characters or fewer" });

  try {
    const r = await chirpstack.createApplication({ name, description });
    console.log(`✅ Application created in ChirpStack: ${name} (${r.id})`);
    res.status(201).json({ message: "Application created successfully", id: r.id, name });
  } catch (err) {
    console.error("❌ ChirpStack application create error:", err.message);
    sendError(res, err, "Failed to create application");
  }
};

module.exports = { getApplications, createApplication };
