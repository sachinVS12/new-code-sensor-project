const Node = require("../models/Node");
const FeedData = require("../models/FeedData");
const { deviceNames } = require("../services/deviceRegistry");
const { unsubscribeTopic } = require("../services/mqtt.service");
const chirpstack = require("../services/chirpstack.service");

const notEnabled = (res) =>
  res.status(400).json({ error: "ChirpStack sync is off. Set CHIRPSTACK_API_URL and CHIRPSTACK_API_TOKEN in backend/.env." });

const sendError = (res, err, fallback) => {
  let status = 502;
  if (err.status === 400) status = 400;
  else if (err.notFound) status = 404;
  else if (err.alreadyExists) status = 409;
  const message = err.alreadyExists ? "An application with this name already exists in ChirpStack" : err.message || fallback;
  res.status(status).json({ error: `ChirpStack: ${message}` });
};

// Checks the form body (create and edit). Returns { error } or { name, description }.
function parseBody(b = {}) {
  const name = String(b.name || "").trim();
  const description = String(b.description || "").trim();
  if (!name) return { error: "Name is required" };
  if (name.length > 100) return { error: "Name must be 100 characters or fewer" };
  if (description.length > 500) return { error: "Description must be 500 characters or fewer" };
  return { name, description };
}

// GET /api/applications
const getApplications = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    res.json(await chirpstack.listApplications());
  } catch (err) {
    console.error("❌ ChirpStack application list error:", err.message);
    sendError(res, err, "Failed to load applications");
  }
};

// GET /api/applications/:id  (what the edit form is filled with)
const getApplication = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    const a = await chirpstack.findApplication(req.params.id);
    if (!a) return res.status(404).json({ error: "Application not found in ChirpStack" });
    res.json({ id: a.id, name: a.name || "", description: a.description || "" });
  } catch (err) {
    console.error("❌ ChirpStack application read error:", err.message);
    sendError(res, err, "Failed to load application");
  }
};

// POST /api/applications   Body: { name, description? }
const createApplication = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const { error, name, description } = parseBody(req.body);
  if (error) return res.status(400).json({ error });

  try {
    const r = await chirpstack.createApplication({ name, description });
    console.log(`✅ Application created in ChirpStack: ${name} (${r.id})`);
    res.status(201).json({ message: "Application created successfully", id: r.id, name });
  } catch (err) {
    console.error("❌ ChirpStack application create error:", err.message);
    sendError(res, err, "Failed to create application");
  }
};

// PUT /api/applications/:id   Body: { name, description? }
const updateApplication = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const { error, name, description } = parseBody(req.body);
  if (error) return res.status(400).json({ error });

  try {
    await chirpstack.updateApplication(req.params.id, { name, description });
    console.log(`✅ Application updated in ChirpStack: ${name} (${req.params.id})`);
    res.json({ message: "Application updated successfully", id: req.params.id, name });
  } catch (err) {
    console.error("❌ ChirpStack application update error:", err.message);
    sendError(res, err, "Failed to update application");
  }
};

// DELETE /api/applications/:id
// ChirpStack deletes the application together with all its devices, so the devices of this application
// that are saved in the dashboard are removed too (same clean-up as deleting a device in Device Creation).
const deleteApplication = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const id = req.params.id;
  try {
    try {
      await chirpstack.deleteApplication(id);
    } catch (err) {
      if (!err.notFound) throw err; // already gone in ChirpStack: still clean up the dashboard
    }

    const nodes = (await Node.find()).filter((n) => (n.applicationId || "").toLowerCase() === id.toLowerCase());
    for (const node of nodes) {
      await Node.findByIdAndDelete(node._id);
      delete deviceNames[node.devEui.toLowerCase()];
      await unsubscribeTopic(node.mqttTopic, node._id);
      await FeedData.deleteMany({ devEui: node.devEui });
    }

    console.log(`🗑️  Application deleted from ChirpStack: ${id} (${nodes.length} device(s) removed from the dashboard)`);
    res.json({ message: "Application deleted successfully", devicesRemoved: nodes.length });
  } catch (err) {
    console.error("❌ ChirpStack application delete error:", err.message);
    sendError(res, err, "Failed to delete application");
  }
};

module.exports = { getApplications, getApplication, createApplication, updateApplication, deleteApplication };
