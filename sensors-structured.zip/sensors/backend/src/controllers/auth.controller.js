const { auth, AUTH_DISABLED } = require("../services/auth.instance");

const isSecure = (req) => req.secure || req.headers["x-forwarded-proto"] === "https" || process.env.COOKIE_SECURE === "true";

// POST /api/auth/login   Body: { username, password }
const login = (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== "string" || typeof password !== "string" || !username || !password) {
    return res.status(400).json({ error: "Enter your username and password" });
  }
  if (username.length > 200 || password.length > 1000) return res.status(400).json({ error: "Username or password is too long" });

  if (!AUTH_DISABLED && !auth.checkCredentials(username, password)) {
    console.warn(`⚠️  Failed login for "${username.slice(0, 50).replace(/[^\w.@-]/g, "?")}" from ${req.ip}`);
    return res.status(401).json({ error: "Invalid username or password" });
  }
  res.setHeader("Set-Cookie", auth.sessionCookie(auth.createToken(username), { secure: isSecure(req) }));
  res.json({ user: { username } });
};

// GET /api/auth/me  -> the logged in user, or 401
const me = (req, res) => {
  if (AUTH_DISABLED) return res.json({ user: { username: "dev" }, authDisabled: true });
  const session = auth.sessionFromHeaders(req.headers);
  if (!session) return res.status(401).json({ error: "Not logged in" });
  res.json({ user: { username: session.username } });
};

// POST /api/auth/logout
const logout = (req, res) => {
  res.setHeader("Set-Cookie", auth.clearCookie({ secure: isSecure(req) }));
  res.json({ message: "Logged out" });
};

module.exports = { login, me, logout };
