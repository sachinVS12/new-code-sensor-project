const chirpstack = require("../services/chirpstack.service");

// Tells the UI whether ChirpStack sync is on, and which device profiles can be chosen
const getStatus = async (req, res) => {
  const status = {
    enabled: chirpstack.isEnabled(),
    defaultDeviceProfileId: chirpstack.defaultDeviceProfileId(),
    deviceProfiles: [],
    regions: [],
  };
  if (status.enabled) {
    try {
      status.deviceProfiles = await chirpstack.listDeviceProfiles();
    } catch (err) {
      status.error = err.message;
    }
    try {
      status.regions = await chirpstack.listRegions();
    } catch (err) {
      status.regionsError = err.message;
    }
  }
  res.json(status);
};

module.exports = { getStatus };
