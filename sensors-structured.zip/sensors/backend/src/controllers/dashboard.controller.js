const Gateway = require("../models/Gateway");
const Node = require("../models/Node");
const SensorData = require("../models/SensorData");
const Downlink = require("../models/Downlink");
const { GATEWAY_ACTIVE_MINUTES } = require("../config/env");
const { normEui } = require("../utils/eui");

// Dashboard summary (gateways active/offline + chart data).
// A gateway is "active" if it forwarded an uplink in the last GATEWAY_ACTIVE_MINUTES
// (matched by gatewayId on the saved uplinks); otherwise it is "offline".
const getDashboard = async (req, res) => {
  try {
    const now = Date.now();
    const activeCutoff = now - GATEWAY_ACTIVE_MINUTES * 60 * 1000;
    const since24h = new Date(now - 24 * 60 * 60 * 1000);

    const [gateways, lastSeenRows, perGatewayRows, hourlyRows, deviceCount, downlinkRows] =
      await Promise.all([
        Gateway.find({}).lean(),
        SensorData.aggregate([
          { $match: { gatewayId: { $nin: [null, ""] } } },
          { $group: { _id: "$gatewayId", lastSeen: { $max: "$timestamp" } } },
        ]),
        SensorData.aggregate([
          { $match: { timestamp: { $gte: since24h }, gatewayId: { $nin: [null, ""] } } },
          { $group: { _id: "$gatewayId", count: { $sum: 1 } } },
        ]),
        SensorData.aggregate([
          { $match: { timestamp: { $gte: since24h }, "decodedPayload.kind": { $ne: "partial" } } }, // a saved partial dataset is not an uplink
          {
            $group: {
              _id: { $dateToString: { format: "%Y-%m-%dT%H:00:00.000Z", date: "$timestamp" } },
              count: { $sum: 1 },
            },
          },
        ]),
        Node.countDocuments({}),
        Downlink.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
      ]);

    // merge rows whose gatewayId only differs by case / separators
    const lastSeenByEui = new Map();
    for (const r of lastSeenRows) {
      const k = normEui(r._id);
      const t = r.lastSeen ? new Date(r.lastSeen).getTime() : 0;
      if (t > (lastSeenByEui.get(k) || 0)) lastSeenByEui.set(k, t);
    }
    const countByEui = new Map();
    for (const r of perGatewayRows) {
      const k = normEui(r._id);
      countByEui.set(k, (countByEui.get(k) || 0) + r.count);
    }

    const gatewayList = gateways.map((g) => {
      const k = normEui(g.gatewayEui);
      const last = lastSeenByEui.get(k) || null;
      return {
        id: String(g._id),
        name: g.gatewayName,
        eui: g.gatewayEui,
        mode: g.mode,
        lastSeen: last ? new Date(last).toISOString() : null,
        status: last && last >= activeCutoff ? "active" : "offline",
        uplinks24h: countByEui.get(k) || 0,
      };
    });

    // uplinks per gateway (registered gateways first, then any unregistered ones that were heard)
    const registered = new Set(gateways.map((g) => normEui(g.gatewayEui)));
    const uplinksPerGateway = gatewayList.map((g) => ({ label: g.name, value: g.uplinks24h }));
    for (const [k, count] of countByEui) {
      if (!registered.has(k)) uplinksPerGateway.push({ label: k, value: count });
    }

    // last 24 hourly buckets (UTC hour starts), zero-filled
    const hourMs = 60 * 60 * 1000;
    const currentHour = Math.floor(now / hourMs) * hourMs;
    const hourlyMap = new Map(hourlyRows.map((r) => [r._id, r.count]));
    const uplinksPerHour = [];
    for (let i = 23; i >= 0; i--) {
      const iso = new Date(currentHour - i * hourMs).toISOString();
      uplinksPerHour.push({ hour: iso, count: hourlyMap.get(iso) || 0 });
    }

    const downlinkByStatus = { queued: 0, transmitted: 0, acknowledged: 0, failed: 0 };
    for (const r of downlinkRows) if (r._id in downlinkByStatus) downlinkByStatus[r._id] = r.count;

    res.json({
      generatedAt: new Date(now).toISOString(),
      activeMinutes: GATEWAY_ACTIVE_MINUTES,
      totals: {
        gateways: gatewayList.length,
        active: gatewayList.filter((g) => g.status === "active").length,
        offline: gatewayList.filter((g) => g.status === "offline").length,
        devices: deviceCount,
        uplinks24h: uplinksPerHour.reduce((sum, h) => sum + h.count, 0),
      },
      gateways: gatewayList,
      uplinksPerHour,
      uplinksPerGateway,
      downlinkByStatus,
    });
  } catch (err) {
    console.error("❌ Error building dashboard:", err.message);
    res.status(500).json({ error: "Failed to load dashboard" });
  }
};

module.exports = { getDashboard };
