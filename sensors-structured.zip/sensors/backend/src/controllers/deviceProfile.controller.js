const chirpstack = require("../services/chirpstack.service");

// Values ChirpStack v4 accepts for these fields
const REGIONS = ["EU868", "US915", "CN779", "EU433", "AU915", "CN470", "AS923", "AS923_2", "AS923_3", "AS923_4", "KR920", "IN865", "RU864", "ISM2400"];
const MAC_VERSIONS = ["LORAWAN_1_0_0", "LORAWAN_1_0_1", "LORAWAN_1_0_2", "LORAWAN_1_0_3", "LORAWAN_1_0_4", "LORAWAN_1_1_0"];
const REG_PARAMS = ["A", "B", "RP002_1_0_0", "RP002_1_0_1", "RP002_1_0_2", "RP002_1_0_3", "RP002_1_0_4"];
const CODECS = ["NONE", "CAYENNE_LPP", "JS"];

const notEnabled = (res) =>
  res.status(400).json({ error: "ChirpStack sync is off. Set CHIRPSTACK_API_URL and CHIRPSTACK_API_TOKEN in backend/.env." });

const sendError = (res, err, fallback) => {
  let status = 502;
  if (err.status === 400) status = 400;
  else if (err.notFound) status = 404;
  else if (err.alreadyExists) status = 409;
  res.status(status).json({ error: `ChirpStack: ${err.message || fallback}` });
};

// Checks the form body (create and edit). Returns { error } or { profile }.
function parseProfile(b = {}) {
  const name = String(b.name || "").trim();
  if (!name) return { error: "Name is required" };

  const region = String(b.region || "").trim().toUpperCase();
  if (!REGIONS.includes(region)) return { error: `Region must be one of: ${REGIONS.join(", ")}` };

  const macVersion = String(b.macVersion || "LORAWAN_1_0_3");
  if (!MAC_VERSIONS.includes(macVersion)) return { error: "Invalid MAC version" };

  const regParamsRevision = String(b.regParamsRevision || "A");
  if (!REG_PARAMS.includes(regParamsRevision)) return { error: "Invalid regional parameters revision" };

  const payloadCodecRuntime = String(b.payloadCodecRuntime || "NONE");
  if (!CODECS.includes(payloadCodecRuntime)) return { error: "Invalid payload codec" };

  const uplinkInterval = Number(b.uplinkInterval);
  if (!Number.isInteger(uplinkInterval) || uplinkInterval < 1) {
    return { error: "Expected uplink interval must be a whole number of seconds (1 or more)" };
  }
  const deviceStatusReqInterval = b.deviceStatusReqInterval === undefined || b.deviceStatusReqInterval === "" ? 1 : Number(b.deviceStatusReqInterval);
  if (!Number.isInteger(deviceStatusReqInterval) || deviceStatusReqInterval < 0) {
    return { error: "Device-status request frequency must be 0 or more (requests per day)" };
  }

  const supportsClassC = !!b.supportsClassC;
  let classCTimeout;
  if (supportsClassC) {
    classCTimeout = Number(b.classCTimeout);
    if (!Number.isInteger(classCTimeout) || classCTimeout < 1) {
      return { error: "Class-C confirmed downlink timeout must be a whole number of seconds (1 or more)" };
    }
  }

  return {
    profile: {
      name,
      description: String(b.description || "").trim(),
      region,
      macVersion,
      regParamsRevision,
      adrAlgorithmId: "default",
      uplinkInterval,
      deviceStatusReqInterval,
      flushQueueOnActivate: !!b.flushQueueOnActivate,
      supportsOtaa: !!b.supportsOtaa,
      supportsClassB: !!b.supportsClassB,
      supportsClassC,
      classCTimeout,
      payloadCodecRuntime,
      payloadCodecScript: typeof b.payloadCodecScript === "string" ? b.payloadCodecScript : "",
    },
  };
}

// GET /api/device-profiles
const getDeviceProfiles = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    res.json(await chirpstack.listDeviceProfilesDetailed());
  } catch (err) {
    console.error("❌ ChirpStack device profile list error:", err.message);
    sendError(res, err, "Failed to load device profiles");
  }
};

// GET /api/device-profiles/:id  (what the edit form is filled with)
const getDeviceProfile = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    const p = await chirpstack.findDeviceProfile(req.params.id);
    if (!p) return res.status(404).json({ error: "Device profile not found in ChirpStack" });
    res.json({
      id: p.id,
      name: p.name || "",
      description: p.description || "",
      region: p.region,
      macVersion: p.macVersion,
      regParamsRevision: p.regParamsRevision,
      uplinkInterval: p.uplinkInterval,
      deviceStatusReqInterval: p.deviceStatusReqInterval,
      flushQueueOnActivate: !!p.flushQueueOnActivate,
      supportsOtaa: !!p.supportsOtaa,
      supportsClassB: !!p.supportsClassB,
      supportsClassC: !!p.supportsClassC,
      classCTimeout: p.classCTimeout,
      payloadCodecRuntime: p.payloadCodecRuntime || "NONE",
      payloadCodecScript: p.payloadCodecScript || "",
    });
  } catch (err) {
    console.error("❌ ChirpStack device profile read error:", err.message);
    sendError(res, err, "Failed to load device profile");
  }
};

// POST /api/device-profiles
const createDeviceProfile = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const { error, profile } = parseProfile(req.body);
  if (error) return res.status(400).json({ error });

  try {
    const r = await chirpstack.createDeviceProfile(profile);
    console.log(`✅ Device profile created in ChirpStack: ${profile.name} (${r.id})`);
    res.status(201).json({ message: "Device profile created successfully", id: r.id, name: profile.name });
  } catch (err) {
    console.error("❌ ChirpStack device profile create error:", err.message);
    sendError(res, err, "Failed to create device profile");
  }
};

// PUT /api/device-profiles/:id
const updateDeviceProfile = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const { error, profile } = parseProfile(req.body);
  if (error) return res.status(400).json({ error });

  try {
    await chirpstack.updateDeviceProfile(req.params.id, profile);
    console.log(`✅ Device profile updated in ChirpStack: ${profile.name} (${req.params.id})`);
    res.json({ message: "Device profile updated successfully", id: req.params.id, name: profile.name });
  } catch (err) {
    console.error("❌ ChirpStack device profile update error:", err.message);
    sendError(res, err, "Failed to update device profile");
  }
};

// DELETE /api/device-profiles/:id
const deleteDeviceProfile = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    await chirpstack.deleteDeviceProfile(req.params.id);
    console.log(`🗑️  Device profile deleted from ChirpStack: ${req.params.id}`);
    res.json({ message: "Device profile deleted successfully" });
  } catch (err) {
    console.error("❌ ChirpStack device profile delete error:", err.message);
    if (err.notFound) return res.status(404).json({ error: "Device profile not found in ChirpStack (already deleted?)" });
    res.status(502).json({
      error: `ChirpStack: ${err.message}. If devices still use this profile, move them to another profile first.`,
    });
  }
};

module.exports = { getDeviceProfiles, getDeviceProfile, createDeviceProfile, updateDeviceProfile, deleteDeviceProfile };
