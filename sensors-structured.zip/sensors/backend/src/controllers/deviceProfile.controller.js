const chirpstack = require("../services/chirpstack.service");

// Values ChirpStack v4 accepts for these fields
const REGIONS = ["EU868", "US915", "CN779", "EU433", "AU915", "CN470", "AS923", "AS923_2", "AS923_3", "AS923_4", "KR920", "IN865", "RU864", "ISM2400"];
const MAC_VERSIONS = ["LORAWAN_1_0_0", "LORAWAN_1_0_1", "LORAWAN_1_0_2", "LORAWAN_1_0_3", "LORAWAN_1_0_4", "LORAWAN_1_1_0"];
const REG_PARAMS = ["A", "B", "RP002_1_0_0", "RP002_1_0_1", "RP002_1_0_2", "RP002_1_0_3", "RP002_1_0_4"];
const CODECS = ["NONE", "CAYENNE_LPP", "JS"];

const notEnabled = (res) =>
  res.status(400).json({ error: "ChirpStack sync is off. Set CHIRPSTACK_API_URL and CHIRPSTACK_API_TOKEN in backend/.env." });

const sendError = (res, err, fallback) => {
  const status = err.status === 400 || err.alreadyExists ? (err.alreadyExists ? 409 : 400) : 502;
  res.status(status).json({ error: `ChirpStack: ${err.message || fallback}` });
};

// GET /api/device-profiles
const getDeviceProfiles = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  try {
    res.json(await chirpstack.listDeviceProfilesDetailed());
  } catch (err) {
    console.error("❌ ChirpStack device profile list error:", err.message);
    sendError(res, err, "Failed to load device profiles");
  }
};

// POST /api/device-profiles
const createDeviceProfile = async (req, res) => {
  if (!chirpstack.isEnabled()) return notEnabled(res);
  const b = req.body || {};
  const name = String(b.name || "").trim();
  if (!name) return res.status(400).json({ error: "Name is required" });

  const region = String(b.region || "").trim().toUpperCase();
  if (!REGIONS.includes(region)) return res.status(400).json({ error: `Region must be one of: ${REGIONS.join(", ")}` });

  const macVersion = String(b.macVersion || "LORAWAN_1_0_3");
  if (!MAC_VERSIONS.includes(macVersion)) return res.status(400).json({ error: "Invalid MAC version" });

  const regParamsRevision = String(b.regParamsRevision || "A");
  if (!REG_PARAMS.includes(regParamsRevision)) return res.status(400).json({ error: "Invalid regional parameters revision" });

  const payloadCodecRuntime = String(b.payloadCodecRuntime || "NONE");
  if (!CODECS.includes(payloadCodecRuntime)) return res.status(400).json({ error: "Invalid payload codec" });

  const uplinkInterval = Number(b.uplinkInterval);
  if (!Number.isInteger(uplinkInterval) || uplinkInterval < 1) {
    return res.status(400).json({ error: "Expected uplink interval must be a whole number of seconds (1 or more)" });
  }
  const deviceStatusReqInterval = b.deviceStatusReqInterval === undefined || b.deviceStatusReqInterval === "" ? 1 : Number(b.deviceStatusReqInterval);
  if (!Number.isInteger(deviceStatusReqInterval) || deviceStatusReqInterval < 0) {
    return res.status(400).json({ error: "Device-status request frequency must be 0 or more (requests per day)" });
  }

  const supportsOtaa = !!b.supportsOtaa;
  const supportsClassB = !!b.supportsClassB;
  const supportsClassC = !!b.supportsClassC;
  let classCTimeout;
  if (supportsClassC) {
    classCTimeout = Number(b.classCTimeout);
    if (!Number.isInteger(classCTimeout) || classCTimeout < 1) {
      return res.status(400).json({ error: "Class-C confirmed downlink timeout must be a whole number of seconds (1 or more)" });
    }
  }

  try {
    const r = await chirpstack.createDeviceProfile({
      name,
      description: String(b.description || "").trim(),
      region,
      macVersion,
      regParamsRevision,
      adrAlgorithmId: "default",
      uplinkInterval,
      deviceStatusReqInterval,
      flushQueueOnActivate: !!b.flushQueueOnActivate,
      supportsOtaa,
      supportsClassB,
      supportsClassC,
      classCTimeout,
      payloadCodecRuntime,
      payloadCodecScript: typeof b.payloadCodecScript === "string" ? b.payloadCodecScript : "",
    });
    console.log(`✅ Device profile created in ChirpStack: ${name} (${r.id})`);
    res.status(201).json({ message: "Device profile created successfully", id: r.id, name });
  } catch (err) {
    console.error("❌ ChirpStack device profile create error:", err.message);
    sendError(res, err, "Failed to create device profile");
  }
};

module.exports = { getDeviceProfiles, createDeviceProfile };
