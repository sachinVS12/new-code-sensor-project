const crypto = require("crypto");
const Node = require("../models/Node");
const FeedData = require("../models/FeedData");
const Downlink = require("../models/Downlink");
const mqttService = require("../services/mqtt.service");
const { broadcastDownlinkUpdate } = require("../services/websocket.service");
const { DOWNLINK_CHUNK_BYTES, MAX_DOWNLINK_CHUNKS, parseDownlinkData } = require("../services/downlink.service");

// Feed Data -> POST /api/downlinks publishes to ChirpStack's
//   application/<appId>/device/<devEui>/command/down
// Queue     -> GET  /api/downlinks lists what was sent and its status:
//   queued -> transmitted (txack event) -> acknowledged (ack event, confirmed only)
const sendDownlink = async (req, res) => {
  try {
    const { devEui, fPort, confirmed, format, data } = req.body;

    const eui = String(devEui || "").trim().toLowerCase();
    const node = await Node.findOne({ devEui: eui });
    if (!node) return res.status(404).json({ error: "Device not found" });

    const port = Number(fPort);
    if (!Number.isInteger(port) || port < 1 || port > 223) {
      return res.status(400).json({ error: "FPort must be a whole number from 1 to 223" });
    }
    const allowedPort = await FeedData.findOne({ devEui: node.devEui, framePort: port });
    if (!allowedPort) {
      return res.status(400).json({ error: "FPort is not in this device's saved Feed Data. Upload it in the Feed Data tab first." });
    }

    let bytes;
    try {
      bytes = parseDownlinkData(format, data);
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
    if (bytes.length === 0) {
      return res.status(400).json({ error: "Data is required" });
    }

    // Split into fixed 240-byte chunks: 240 bytes = 1 chunk, 300 bytes = 240 + 60
    const chunks = [];
    for (let i = 0; i < bytes.length; i += DOWNLINK_CHUNK_BYTES) {
      chunks.push(bytes.subarray(i, i + DOWNLINK_CHUNK_BYTES));
    }
    if (chunks.length > MAX_DOWNLINK_CHUNKS) {
      return res.status(400).json({
        error: `Data is too long: ${bytes.length} bytes needs ${chunks.length} chunks (maximum ${MAX_DOWNLINK_CHUNKS} chunks of ${DOWNLINK_CHUNK_BYTES} bytes)`,
      });
    }

    const topic = `application/${node.applicationId}/device/${node.devEui}/command/down`;
    const downlinks = [];
    const messageId = crypto.randomUUID();   // ties all chunks of this message together
    const sentAt = new Date();               // same time on every chunk so they list together
    let failure = "";                        // set when a chunk cannot be sent

    // Every submitted chunk is saved to the database first (so it always shows on the Task page),
    // then sent in order. If one chunk fails, it and the rest are saved as "failed".
    for (const [i, chunk] of chunks.entries()) {
      const payload = {
        devEui: node.devEui,
        confirmed: !!confirmed,
        fPort: port,
        data: chunk.toString("base64"),
      };

      const downlink = await Downlink.create({
        devEui: node.devEui,
        deviceName: node.deviceName,
        applicationId: node.applicationId,
        fPort: port,
        confirmed: !!confirmed,
        data: payload.data,
        dataHex: chunk.toString("hex").toUpperCase(),
        messageId,
        chunkIndex: i + 1,
        chunkTotal: chunks.length,
        status: failure ? "failed" : "queued",
        error: failure ? "Not sent because an earlier chunk failed" : "",
        createdAt: sentAt,
      });
      downlinks.push(downlink);
      broadcastDownlinkUpdate(downlink, "created");

      if (failure) continue;

      try {
        await mqttService.publish(topic, JSON.stringify(payload));
        console.log(`⬇️  Downlink chunk ${i + 1}/${chunks.length} queued for ${node.deviceName} (${node.devEui}) fPort ${port}: ${chunk.length} bytes`);
      } catch (e) {
        failure = e.message || "Failed to publish to the MQTT broker";
        downlink.status = "failed";
        downlink.error = failure;
        await downlink.save();
        broadcastDownlinkUpdate(downlink);
        console.error(`❌ Chunk ${i + 1}/${chunks.length} failed for ${node.deviceName}:`, failure);
      }
    }

    if (failure) {
      return res.status(502).json({
        error: `${failure}. Your data was saved on the Task page as Failed.`,
        downlinks,
      });
    }

    res.status(201).json({
      message: chunks.length === 1 ? "Downlink queued" : `${chunks.length} downlink chunks queued`,
      totalBytes: bytes.length,
      chunks: chunks.length,
      downlinks,
    });
  } catch (err) {
    console.error("❌ Error sending downlink:", err.message);
    res.status(500).json({ error: "Failed to send downlink" });
  }
};

const getDownlinks = async (req, res) => {
  try {
    const filter = {};
    if (req.query.devEui) filter.devEui = String(req.query.devEui).toLowerCase();
    if (req.query.status) filter.status = String(req.query.status);
    const list = await Downlink.find(filter).sort({ createdAt: -1, chunkIndex: 1 }).limit(200);
    res.json(list);
  } catch (err) {
    console.error("❌ Error fetching downlinks:", err.message);
    res.status(500).json({ error: "Failed to fetch downlinks" });
  }
};

// Removes the entry from this list only (ChirpStack's own device queue is not touched)
const deleteDownlink = async (req, res) => {
  try {
    const removed = await Downlink.findByIdAndDelete(req.params.id);
    if (!removed) return res.status(404).json({ error: "Downlink not found" });
    broadcastDownlinkUpdate(removed, "deleted");
    res.json({ message: "Downlink removed" });
  } catch (err) {
    res.status(500).json({ error: "Failed to remove downlink" });
  }
};

module.exports = { sendDownlink, getDownlinks, deleteDownlink };
