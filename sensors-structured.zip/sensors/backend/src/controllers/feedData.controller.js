const Node = require("../models/Node");
const FeedData = require("../models/FeedData");

// Uploaded Excel / CSV rows, stored per device.
// The browser reads the file and sends rows: [{ framePort, purpose }].
const saveFeedData = async (req, res) => {
  try {
    const { devEui, fileName, rows } = req.body;

    const eui = String(devEui || "").trim().toLowerCase();
    const node = await Node.findOne({ devEui: eui });
    if (!node) return res.status(404).json({ error: "Device not found" });

    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: "No rows to save" });
    }
    if (rows.length > 500) {
      return res.status(400).json({ error: "Too many rows (maximum 500)" });
    }

    // one row per frame port (if a port repeats, the last one wins)
    const byPort = new Map();
    for (const [i, r] of rows.entries()) {
      const port = Number(r.framePort);
      const purpose = String(r.purpose ?? "").trim();
      if (!Number.isInteger(port) || port < 1 || port > 223) {
        return res.status(400).json({ error: `Row ${i + 1}: Frame Port must be a whole number from 1 to 223` });
      }
      if (!purpose || purpose.length > 200) {
        return res.status(400).json({ error: `Row ${i + 1}: Purpose is required (max 200 characters)` });
      }
      byPort.set(port, purpose);
    }

    // replace this device's previous upload
    const removed = await FeedData.deleteMany({ devEui: node.devEui });
    const docs = [...byPort].map(([framePort, purpose]) => ({
      devEui: node.devEui,
      deviceName: node.deviceName,
      framePort,
      purpose,
      sourceFile: String(fileName || "").slice(0, 200),
    }));
    await FeedData.insertMany(docs);

    console.log(`📄 Feed data saved for ${node.deviceName}: ${docs.length} row(s), replaced ${removed.deletedCount}`);
    res.status(201).json({ message: "Feed data saved", saved: docs.length, replaced: removed.deletedCount });
  } catch (err) {
    console.error("❌ Error saving feed data:", err.message);
    res.status(500).json({ error: "Failed to save feed data" });
  }
};

const getFeedData = async (req, res) => {
  try {
    const eui = String(req.query.devEui || "").trim().toLowerCase();
    if (!eui) return res.status(400).json({ error: "devEui is required" });
    const rows = await FeedData.find({ devEui: eui }).sort({ framePort: 1 });
    const node = await Node.findOne({ devEui: eui }, "deviceName").lean();   // current name of the device
    res.json(rows.map((r) => ({ ...r.toObject(), deviceName: node ? node.deviceName : r.deviceName }))); 
  } catch (err) {
    console.error("❌ Error fetching feed data:", err.message);
    res.status(500).json({ error: "Failed to fetch feed data" });
  }
};

const clearFeedData = async (req, res) => {
  try {
    const eui = String(req.query.devEui || "").trim().toLowerCase();
    if (!eui) return res.status(400).json({ error: "devEui is required" });
    const result = await FeedData.deleteMany({ devEui: eui });
    res.json({ message: "Feed data cleared", deleted: result.deletedCount });
  } catch (err) {
    console.error("❌ Error clearing feed data:", err.message);
    res.status(500).json({ error: "Failed to clear feed data" });
  }
};

module.exports = { saveFeedData, getFeedData, clearFeedData };
