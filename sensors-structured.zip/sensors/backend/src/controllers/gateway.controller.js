const Gateway = require("../models/Gateway");
const Node = require("../models/Node");
const chirpstack = require("../services/chirpstack.service");
const { EUI_REGEX } = require("../utils/eui");
const { REGIONS } = require("../utils/regions");

// undefined = not sent, "" = no region, otherwise one of REGIONS (upper-cased)
const parseRegion = (v) => (typeof v === "string" ? v.trim().toUpperCase() : undefined);
const REGION_ERROR = `Region ID must be one of: ${REGIONS.join(", ")}`;

// When ChirpStack sync is on (CHIRPSTACK_API_URL + CHIRPSTACK_API_TOKEN) the gateway is created in ChirpStack first.
const createGateway = async (req, res) => {
  let createdInChirpstack = false;
  let eui = "";
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;
    const regionId = parseRegion(req.body.regionId);
    if (regionId && !REGIONS.includes(regionId)) return res.status(400).json({ error: REGION_ERROR });

    if (!gatewayName || !gatewayEui || !destinationIp || !port || !mode) {
      return res.status(400).json({ error: "All fields are required" });
    }
    eui = String(gatewayEui).trim().toLowerCase();

    const exists = await Gateway.findOne({ $or: [{ gatewayEui: eui }, { gatewayName }] });
    if (exists) return res.status(409).json({ error: "Gateway name or EUI already exists" });

    let cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      if (!EUI_REGEX.test(eui)) {
        return res.status(400).json({ error: "Gateway EUI must be 16 hex characters" });
      }
      try {
        const r = await chirpstack.createGateway({ gatewayEui: eui, gatewayName: String(gatewayName).trim(), regionId });
        createdInChirpstack = r.created;
        cs = { enabled: true, ...r };
        console.log(
          r.created
            ? `✅ Gateway created in ChirpStack: ${gatewayName} (${eui})`
            : `ℹ️  Gateway already exists in ChirpStack: ${eui}`
        );
      } catch (err) {
        console.error("❌ ChirpStack gateway error:", err.message);
        return res.status(err.status === 400 ? 400 : 502).json({ error: `ChirpStack: ${err.message}` });
      }
    }

    const newGateway = new Gateway({
      gatewayName,
      gatewayEui: eui,
      destinationIp,
      port,
      mode,
      regionId: regionId || "",
    });

    await newGateway.save();
    console.log(`✅ Gateway created: ${gatewayName} (${eui})`);
    res.status(201).json({ message: "Gateway created successfully", gateway: newGateway, chirpstack: cs });
  } catch (err) {
    if (createdInChirpstack) {
      chirpstack.deleteGateway(eui).catch((e) => console.error("⚠️  Could not undo ChirpStack gateway:", e.message));
    }
    console.error("❌ Error creating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to create gateway" });
  }
};

const getGateways = async (req, res) => {
  try {
    const gateways = await Gateway.find({});
    res.json(gateways);
  } catch (err) {
    console.error("❌ Error fetching gateways:", err.message);
    res.status(500).json({ error: "Failed to fetch gateways" });
  }
};

// GET /api/gateways/:id
const getGateway = async (req, res) => {
  try {
    const gateway = await Gateway.findById(req.params.id);
    if (!gateway) return res.status(404).json({ error: "Gateway not found" });
    res.json(gateway);
  } catch (err) {
    console.error("❌ Error fetching gateway:", err.message);
    res.status(500).json({ error: "Failed to fetch gateway" });
  }
};

const deleteGateway = async (req, res) => {
  try {
    const deleted = await Gateway.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Gateway not found" });

    // devices that used this gateway keep working, they just have no gateway any more
    const unlinked = await Node.updateMany({ gatewayId: deleted._id }, { $set: { gatewayId: null } });

    // remove it from ChirpStack too (a gateway that is already gone there is fine)
    const cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      try {
        await chirpstack.deleteGateway(deleted.gatewayEui);
        cs.deleted = true;
      } catch (err) {
        if (err.notFound) {
          cs.notFound = true;
        } else {
          console.error("⚠️  Could not delete gateway in ChirpStack:", err.message);
          cs.warning = `Removed here, but could not be removed from ChirpStack: ${err.message}`;
        }
      }
    }

    console.log(`✅ Gateway deleted: ${req.params.id}`);
    res.json({ message: "Gateway deleted successfully", nodesUnlinked: unlinked.modifiedCount || 0, chirpstack: cs });
  } catch (err) {
    console.error("❌ Error deleting gateway:", err.message);
    res.status(500).json({ error: "Failed to delete gateway" });
  }
};

// When ChirpStack sync is on the gateway is updated in ChirpStack first
// (if the EUI changed, the new gateway is created there and the old one removed).
const updateGateway = async (req, res) => {
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;
    const regionId = parseRegion(req.body.regionId);
    if (regionId && !REGIONS.includes(regionId)) return res.status(400).json({ error: REGION_ERROR });

    if (!gatewayName || !gatewayEui || !destinationIp || !port || !mode) {
      return res.status(400).json({ error: "All fields are required" });
    }
    const eui = String(gatewayEui).trim().toLowerCase();

    const old = await Gateway.findById(req.params.id);
    if (!old) return res.status(404).json({ error: "Gateway not found" });

    const clash = await Gateway.findOne({
      _id: { $ne: old._id },
      $or: [{ gatewayEui: eui }, { gatewayName }],
    });
    if (clash) return res.status(409).json({ error: "Gateway name or EUI already exists" });

    let cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      if (!EUI_REGEX.test(eui)) {
        return res.status(400).json({ error: "Gateway EUI must be 16 hex characters" });
      }
      try {
        const r = await chirpstack.updateGateway({
          oldGatewayEui: String(old.gatewayEui).trim().toLowerCase(),
          gatewayEui: eui,
          gatewayName: String(gatewayName).trim(),
          // an old gateway without a saved region: leave its ChirpStack tags alone unless a region is chosen
          regionId: regionId === "" && !old.regionId ? undefined : regionId,
        });
        cs = { enabled: true, ...r };
        console.log(`✅ Gateway synced to ChirpStack: ${eui}`);
      } catch (err) {
        console.error("❌ ChirpStack gateway error:", err.message);
        return res.status(err.status === 400 ? 400 : 502).json({ error: `ChirpStack: ${err.message}` });
      }
    }

    const updatedGateway = await Gateway.findByIdAndUpdate(
      req.params.id,
      { gatewayName, gatewayEui: eui, destinationIp, port, mode, regionId: regionId ?? old.regionId ?? "" },
      { new: true, runValidators: true }
    );
    console.log(`✅ Gateway updated: ${req.params.id}`);
    res.json({ message: "Gateway updated successfully", gateway: updatedGateway, chirpstack: cs });
  } catch (err) {
    console.error("❌ Error updating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to update gateway" });
  }
};

module.exports = { createGateway, getGateways, deleteGateway, updateGateway, getGateway };
