const Gateway = require("../models/Gateway");
const chirpstack = require("../services/chirpstack.service");
const { EUI_REGEX } = require("../utils/eui");

// When ChirpStack sync is on (CHIRPSTACK_API_URL + CHIRPSTACK_API_TOKEN) the gateway is created in ChirpStack first.
const createGateway = async (req, res) => {
  let createdInChirpstack = false;
  let eui = "";
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;

    if (!gatewayName || !gatewayEui || !destinationIp || !port || !mode) {
      return res.status(400).json({ error: "All fields are required" });
    }
    eui = String(gatewayEui).trim().toLowerCase();

    const exists = await Gateway.findOne({ $or: [{ gatewayEui: eui }, { gatewayName }] });
    if (exists) return res.status(409).json({ error: "Gateway name or EUI already exists" });

    let cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      if (!EUI_REGEX.test(eui)) {
        return res.status(400).json({ error: "Gateway EUI must be 16 hex characters" });
      }
      try {
        const r = await chirpstack.createGateway({ gatewayEui: eui, gatewayName: String(gatewayName).trim() });
        createdInChirpstack = r.created;
        cs = { enabled: true, ...r };
        console.log(
          r.created
            ? `✅ Gateway created in ChirpStack: ${gatewayName} (${eui})`
            : `ℹ️  Gateway already exists in ChirpStack: ${eui}`
        );
      } catch (err) {
        console.error("❌ ChirpStack gateway error:", err.message);
        return res.status(err.status === 400 ? 400 : 502).json({ error: `ChirpStack: ${err.message}` });
      }
    }

    const newGateway = new Gateway({
      gatewayName,
      gatewayEui: eui,
      destinationIp,
      port,
      mode,
      chirpstackSynced: createdInChirpstack,
    });

    await newGateway.save();
    console.log(`✅ Gateway created: ${gatewayName} (${eui})`);
    res.status(201).json({ message: "Gateway created successfully", gateway: newGateway, chirpstack: cs });
  } catch (err) {
    if (createdInChirpstack) {
      chirpstack.deleteGateway(eui).catch((e) => console.error("⚠️  Could not undo ChirpStack gateway:", e.message));
    }
    console.error("❌ Error creating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to create gateway" });
  }
};

const getGateways = async (req, res) => {
  try {
    const gateways = await Gateway.find({});
    res.json(gateways);
  } catch (err) {
    console.error("❌ Error fetching gateways:", err.message);
    res.status(500).json({ error: "Failed to fetch gateways" });
  }
};

const deleteGateway = async (req, res) => {
  try {
    const deleted = await Gateway.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: "Gateway not found" });

    // remove it from ChirpStack too, but only if this app created it there
    const cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled && deleted.chirpstackSynced) {
      try {
        await chirpstack.deleteGateway(deleted.gatewayEui);
        cs.deleted = true;
      } catch (err) {
        console.error("⚠️  Could not delete gateway in ChirpStack:", err.message);
        cs.warning = `Removed here, but could not be removed from ChirpStack: ${err.message}`;
      }
    }

    console.log(`✅ Gateway deleted: ${req.params.id}`);
    res.json({ message: "Gateway deleted successfully", chirpstack: cs });
  } catch (err) {
    console.error("❌ Error deleting gateway:", err.message);
    res.status(500).json({ error: "Failed to delete gateway" });
  }
};

const updateGateway = async (req, res) => {
  try {
    const { gatewayName, gatewayEui, destinationIp, port, mode } = req.body;
    const updatedGateway = await Gateway.findByIdAndUpdate(
      req.params.id,
      { gatewayName, gatewayEui, destinationIp, port, mode },
      { new: true, runValidators: true }
    );
    if (!updatedGateway) return res.status(404).json({ error: "Gateway not found" });
    console.log(`✅ Gateway updated: ${req.params.id}`);
    res.json({ message: "Gateway updated successfully", gateway: updatedGateway });
  } catch (err) {
    console.error("❌ Error updating gateway:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Gateway name or EUI already exists" });
    }
    res.status(500).json({ error: "Failed to update gateway" });
  }
};

module.exports = { createGateway, getGateways, deleteGateway, updateGateway };
