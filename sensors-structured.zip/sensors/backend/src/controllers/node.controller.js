const Node = require("../models/Node");
const Gateway = require("../models/Gateway");
const FeedData = require("../models/FeedData");
const { deviceNames } = require("../services/deviceRegistry");
const { buildTopic, subscribeTopic, unsubscribeTopic } = require("../services/mqtt.service");
const { EUI_REGEX } = require("../utils/eui");
const { OBJECT_ID, UUID } = require("../utils/ids");
const { nodeJson, nodesJson, gatewayNames } = require("../services/nodeView");
const chirpstack = require("../services/chirpstack.service");

// A device points to everything else by ID:
//   applicationId    ChirpStack application (UUID)      deviceProfileId  ChirpStack device profile (UUID)
//   gatewayId        gateway of this dashboard (ObjectId, "" = none)      devEui  the device itself
// The ChirpStack IDs are checked against ChirpStack when sync is on, the gateway ID against the gateways here.

// Checks gatewayId. Returns { gatewayId } (null = none) or { error }.
async function resolveGateway(raw) {
  const id = String(raw || "").trim();
  if (!id) return { gatewayId: null };
  if (!OBJECT_ID.test(id)) return { error: "Invalid gateway id" };
  const g = await Gateway.findById(id).lean();
  if (!g) return { error: "Gateway not found. Choose one from the list." };
  return { gatewayId: g._id };
}

// With ChirpStack sync on: the application and device profile must exist there.
// Returns { status, error } or null.
async function checkChirpstackRefs(applicationId, deviceProfileId) {
  if (!chirpstack.isEnabled()) return null;
  if (!UUID.test(applicationId)) {
    return { status: 400, error: "Application ID must be a ChirpStack application ID. Choose one from the list." };
  }
  if (deviceProfileId && !UUID.test(deviceProfileId)) {
    return { status: 400, error: "Device profile must be a ChirpStack device profile ID. Choose one from the list." };
  }
  try {
    if (!(await chirpstack.findApplication(applicationId))) {
      return { status: 400, error: "Application not found in ChirpStack. Create it on the Application page or choose another." };
    }
    if (deviceProfileId && !(await chirpstack.findDeviceProfile(deviceProfileId))) {
      return { status: 400, error: "Device profile not found in ChirpStack. Choose one from the list." };
    }
  } catch (err) {
    return { status: err.status === 400 ? 400 : 502, error: `ChirpStack: ${err.message}` };
  }
  return null;
}

// Body: { deviceName, devEui, applicationId } (+ optional mode, gatewayId, deviceProfileId, appKey)
// mqttTopic is generated automatically.
// When ChirpStack sync is on (CHIRPSTACK_API_URL + CHIRPSTACK_API_TOKEN) the device is created in ChirpStack first.
const createNode = async (req, res) => {
  let createdInChirpstack = false;
  let eui = "";
  try {
    const { deviceName, devEui, applicationId, mode, gatewayId, deviceProfileId, appKey } = req.body;

    if (!deviceName?.trim() || !devEui?.trim() || !applicationId?.trim()) {
      return res.status(400).json({ error: "Device name, DevEUI and Application ID are required" });
    }
    eui = devEui.trim().toLowerCase();
    if (!EUI_REGEX.test(eui)) {
      return res.status(400).json({ error: "DevEUI must be 16 hex characters" });
    }
    const appId = applicationId.trim();

    const gw = await resolveGateway(gatewayId);
    if (gw.error) return res.status(400).json({ error: gw.error });

    // the profile the device ends up with: the chosen one, else the default of the server
    const profileId = (deviceProfileId || "").trim() || (chirpstack.isEnabled() ? chirpstack.defaultDeviceProfileId() || "" : "");
    const refError = await checkChirpstackRefs(appId, profileId);
    if (refError) return res.status(refError.status).json({ error: refError.error });

    // check duplicates first so nothing is created in ChirpStack for a device that cannot be saved here
    const exists = await Node.findOne({ $or: [{ devEui: eui }, { deviceName: deviceName.trim() }] });
    if (exists) return res.status(409).json({ error: "Device name or DevEUI already exists" });

    let cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      try {
        const r = await chirpstack.createDevice({
          devEui: eui,
          deviceName: deviceName.trim(),
          applicationId: appId,
          deviceProfileId: profileId,
          mode: mode || "OTAA",
          appKey,
        });
        createdInChirpstack = r.created;
        cs = { enabled: true, ...r };
        console.log(
          r.created
            ? `✅ Device created in ChirpStack: ${deviceName.trim()} (${eui})`
            : `ℹ️  Device already exists in ChirpStack: ${eui}`
        );
      } catch (err) {
        console.error("❌ ChirpStack device error:", err.message);
        return res.status(err.status === 400 ? 400 : 502).json({ error: `ChirpStack: ${err.message}` });
      }
    }

    const newNode = new Node({
      deviceName: deviceName.trim(),
      devEui: eui,
      applicationId: appId,
      mqttTopic: buildTopic(appId, eui),
      mode: mode || "OTAA",
      gatewayId: gw.gatewayId,
      deviceProfileId: profileId,
    });

    await newNode.save();

    deviceNames[newNode.devEui] = newNode.deviceName;
    subscribeTopic(newNode.mqttTopic);

    console.log(`✅ Node created: ${newNode.deviceName} (${newNode.devEui})`);
    console.log(`📡 MQTT topic: ${newNode.mqttTopic}`);
    res.status(201).json({ message: "Node created successfully", node: nodeJson(newNode, await gatewayNames()), chirpstack: cs });
  } catch (err) {
    // saving failed after the device was created in ChirpStack: undo it there
    if (createdInChirpstack) {
      chirpstack.deleteDevice(eui).catch((e) => console.error("⚠️  Could not undo ChirpStack device:", e.message));
    }
    console.error("❌ Error creating node:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Device name or DevEUI already exists" });
    }
    res.status(500).json({ error: "Failed to create node" });
  }
};

// GET /api/nodes
const getNodes = async (req, res) => {
  try {
    const nodes = await Node.find({});
    res.json(await nodesJson(nodes));
  } catch (err) {
    console.error("❌ Error fetching nodes:", err.message);
    res.status(500).json({ error: "Failed to fetch nodes" });
  }
};

// GET /api/nodes/:id
const getNode = async (req, res) => {
  try {
    const node = await Node.findById(req.params.id);
    if (!node) return res.status(404).json({ error: "Node not found" });
    res.json(nodeJson(node, await gatewayNames()));
  } catch (err) {
    console.error("❌ Error fetching node:", err.message);
    res.status(500).json({ error: "Failed to fetch node" });
  }
};

// When ChirpStack sync is on the device is updated in ChirpStack first. If the DevEUI or the Application ID
// changed, ChirpStack cannot edit it in place, so the device is created again there (see chirpstack.service).
const updateNode = async (req, res) => {
  try {
    const { deviceName, devEui, applicationId, mode, gatewayId, deviceProfileId, appKey } = req.body;

    if (!deviceName?.trim() || !devEui?.trim() || !applicationId?.trim()) {
      return res.status(400).json({ error: "Device name, DevEUI and Application ID are required" });
    }
    const eui = devEui.trim().toLowerCase();
    if (!EUI_REGEX.test(eui)) {
      return res.status(400).json({ error: "DevEUI must be 16 hex characters" });
    }
    const appId = applicationId.trim();

    const old = await Node.findById(req.params.id);
    if (!old) return res.status(404).json({ error: "Node not found" });

    const gw = await resolveGateway(gatewayId);
    if (gw.error) return res.status(400).json({ error: gw.error });

    // no profile chosen = keep the one the device has
    const profileId = (deviceProfileId || "").trim() || old.deviceProfileId || "";
    const refError = await checkChirpstackRefs(appId, profileId);
    if (refError) return res.status(refError.status).json({ error: refError.error });

    const clash = await Node.findOne({
      _id: { $ne: old._id },
      $or: [{ devEui: eui }, { deviceName: deviceName.trim() }],
    });
    if (clash) return res.status(409).json({ error: "Device name or DevEUI already exists" });

    let cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      try {
        const args = {
          devEui: eui,
          deviceName: deviceName.trim(),
          applicationId: appId,
          deviceProfileId: profileId,
          mode: mode || "OTAA",
          appKey,
        };
        const moved = old.devEui.toLowerCase() !== eui || old.applicationId.toLowerCase() !== appId.toLowerCase();
        const r = moved
          ? await chirpstack.replaceDevice({ oldDevEui: old.devEui.toLowerCase(), ...args })
          : await chirpstack.updateDevice(args);
        cs = { enabled: true, ...r };
        console.log(`✅ Device synced to ChirpStack: ${eui}`);
      } catch (err) {
        console.error("❌ ChirpStack device error:", err.message);
        return res.status(err.status === 400 ? 400 : 502).json({ error: `ChirpStack: ${err.message}` });
      }
    }

    const updated = await Node.findByIdAndUpdate(
      req.params.id,
      {
        deviceName: deviceName.trim(),
        devEui: eui,
        applicationId: appId,
        mqttTopic: buildTopic(appId, eui),
        mode: mode || "OTAA",
        gatewayId: gw.gatewayId,
        deviceProfileId: profileId,
      },
      { new: true, runValidators: true }
    );

    delete deviceNames[old.devEui.toLowerCase()];
    deviceNames[updated.devEui] = updated.deviceName;

    if (old.mqttTopic !== updated.mqttTopic) {
      await unsubscribeTopic(old.mqttTopic, old._id);
      subscribeTopic(updated.mqttTopic);
    }

    console.log(`✅ Node updated: ${updated.deviceName} (${updated.devEui})`);
    res.json({ message: "Node updated successfully", node: nodeJson(updated, await gatewayNames()), chirpstack: cs });
  } catch (err) {
    console.error("❌ Error updating node:", err.message);
    if (err.code === 11000) {
      return res.status(409).json({ error: "Device name or DevEUI already exists" });
    }
    res.status(500).json({ error: "Failed to update node" });
  }
};

const deleteNode = async (req, res) => {
  try {
    const node = await Node.findByIdAndDelete(req.params.id);
    if (!node) return res.status(404).json({ error: "Node not found" });
    delete deviceNames[node.devEui.toLowerCase()];
    await unsubscribeTopic(node.mqttTopic, node._id);
    await FeedData.deleteMany({ devEui: node.devEui });

    // remove it from ChirpStack too (a device that is already gone there is fine)
    const cs = { enabled: chirpstack.isEnabled() };
    if (cs.enabled) {
      try {
        await chirpstack.deleteDevice(node.devEui);
        cs.deleted = true;
      } catch (err) {
        if (err.notFound) {
          cs.notFound = true;
        } else {
          console.error("⚠️  Could not delete device in ChirpStack:", err.message);
          cs.warning = `Removed here, but could not be removed from ChirpStack: ${err.message}`;
        }
      }
    }

    console.log(`✅ Node deleted: ${req.params.id}`);
    res.json({ message: "Node deleted successfully", chirpstack: cs });
  } catch (err) {
    console.error("❌ Error deleting node:", err.message);
    res.status(500).json({ error: "Failed to delete node" });
  }
};

module.exports = { createNode, getNodes, getNode, updateNode, deleteNode };
