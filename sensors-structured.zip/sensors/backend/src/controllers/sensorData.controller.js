const SensorData = require("../models/SensorData");

// Latest uplink per device (used to fill the tabular view on page load)
const getLatest = async (req, res) => {
  try {
    const rows = await SensorData.aggregate([
      // a saved "partial" dataset is a summary of earlier chunks (no RSSI / SNR of its own): never the latest uplink
      { $match: { "decodedPayload.kind": { $ne: "partial" } } },
      { $sort: { timestamp: -1 } },
      { $group: { _id: "$devEui", doc: { $first: "$$ROOT" } } },
    ]);
    res.json(rows.map((r) => r.doc));
  } catch (err) {
    console.error("❌ Error fetching latest data:", err.message);
    res.status(500).json({ error: "Failed to fetch latest data" });
  }
};

module.exports = { getLatest };
