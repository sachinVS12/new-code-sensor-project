// ─── Chunked-dataset devices (STM32 node sending the ADC dataset) ───
// Every uplink on the ADC port (FPort 2 by default) starts with a 3-byte header, followed by the data:
//
//   byte 0   packet type   00 = single dataset (16-bit samples)
//                          01 = batch dataset  (16-bit samples)
//                          02 = probe (SF/DR info)
//                          03 = packed dataset (12-bit samples, 2 samples in every 3 bytes)
//   byte 1   total chunks  1 to 255
//   byte 2   chunk number  0-based (00, 01, 02, ...)
//   byte 3+  data          ADC samples, or probe info
//
// Examples:
//   00 40 00 ...  single dataset, 64 chunks in total, chunk 0
//   01 26 25 ...  batch dataset, 38 chunks in total, chunk 37 (the last one)
//   03 20 00 ...  packed 12-bit dataset, 32 chunks in total, chunk 0
//   02 01 00 05   probe packet, byte 3 is the data rate being tested (DR5)
//
// Settings (backend/.env, all optional):
//   CHUNK_DEVICE_EUIS    extra DevEUIs (comma separated) that send this format
//   CHUNK_FPORT          uplink port of the ADC data (default 2)
//   CHUNK_PACK12_LAYOUT  bit order of the packed 12-bit samples, "msb" (default, what the node firmware sends) or "lsb" - see unpack12()
//   CHUNK_PARTIAL_TIMEOUT_SECONDS  an unfinished dataset is saved as a "partial" after this many seconds without a new chunk
//                        (default 120, 0 = off). It is also saved as partial when a new dataset starts before the old one finished.
const CHUNK_DEVICES = new Set([
  "50c6c10d19c40cce", // mohan
]);
const HEADER_SIZE = 3;
const TYPE_SINGLE = 0;
const TYPE_BATCH = 1;
const TYPE_PROBE = 2;
const TYPE_PACK12 = 3;
const TYPE_NAMES = {
  [TYPE_SINGLE]: "single dataset",
  [TYPE_BATCH]: "batch dataset",
  [TYPE_PROBE]: "probe",
  [TYPE_PACK12]: "packed 12-bit dataset",
};
const PACK12_SAMPLES_PER_DATASET = 4096; // firmware: ADC_SAMPLE_COUNT (6144 packed bytes)

// Is this DevEUI one that sends the chunked format? (read at call time so .env is always loaded)
function isChunkDevice(devEui) {
  if (CHUNK_DEVICES.has(devEui)) return true;
  return (process.env.CHUNK_DEVICE_EUIS || "")
    .split(",")
    .map((x) => x.trim().toLowerCase())
    .includes(devEui);
}

function chunkFPort() {
  const n = Number(process.env.CHUNK_FPORT);
  return Number.isInteger(n) && n >= 0 && n <= 255 ? n : 2;
}

function pack12Layout() {
  return String(process.env.CHUNK_PACK12_LAYOUT || "msb").trim().toLowerCase() === "lsb" ? "lsb" : "msb";
}

// 12-bit samples, two in every 3 bytes (b0 b1 b2 -> samples a, b):
//   "msb" (default): a = b0 << 4 | b1 >> 4          b = (b1 & 0x0F) << 8 | b2    (high byte first)
//   "lsb":           a = b0 | (b1 & 0x0F) << 8      b = (b1 >> 4) | b2 << 4      (low byte first)
// The node firmware (Pack12) sends "msb": out[0] = a >> 4; out[1] = ((a & 0x0F) << 4) | (b >> 8); out[2] = b & 0xFF.
// seconds of silence after which an unfinished dataset is flushed as "partial" (0 = never)
function partialTimeoutMs() {
  const raw = process.env.CHUNK_PARTIAL_TIMEOUT_SECONDS;
  if (raw === undefined || String(raw).trim() === "") return 120 * 1000;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? n * 1000 : 120 * 1000;
}

function unpack12(data, layout) {
  const out = [];
  for (let i = 0; i + 2 < data.length; i += 3) {
    const b0 = data[i];
    const b1 = data[i + 1];
    const b2 = data[i + 2];
    if (layout === "msb") {
      out.push((b0 << 4) | (b1 >> 4), ((b1 & 0x0f) << 8) | b2);
    } else {
      out.push(b0 | ((b1 & 0x0f) << 8), (b1 >> 4) | (b2 << 4));
    }
  }
  return out;
}

const chunkSessions = {}; // devEui -> { type, total, chunks[], received }

function statsOf(samples) {
  let min = Infinity;
  let max = -Infinity;
  let sum = 0;
  for (const v of samples) {
    if (v < min) min = v;
    if (v > max) max = v;
    sum += v;
  }
  return { min, max, avg: Number((sum / samples.length).toFixed(2)) };
}

// An unfinished dataset, kept so it can be saved and flagged instead of being lost.
// Deliberately has NO top-level "samples" / "avg": the dashboard treats those as a complete dataset.
// partialSamples = the chunks that DID arrive, in chunk order (missing chunks leave a gap, see missingChunks).
function buildPartial(s, reason) {
  const receivedChunkList = [];
  const missingChunks = [];
  s.chunks.forEach((c, i) => (c ? receivedChunkList : missingChunks).push(i));
  const partialSamples = [].concat(...s.chunks.filter(Boolean));
  return {
    kind: "partial",
    partial: true,
    reason, // "new-dataset" (next dataset started first) or "timeout" (no chunk for a while)
    datasetKind: s.datasetKind,
    sampleBits: s.sampleBits,
    packLayout: s.packLayout,
    header: { type: s.type, total: s.total },
    receivedChunks: s.received,
    totalChunks: s.total,
    receivedChunkList,
    missingChunks,
    sampleCount: partialSamples.length,
    partialSamples,
    stats: partialSamples.length ? statsOf(partialSamples) : null,
    lastChunkAt: new Date(s.lastChunkAt).toISOString(),
  };
}

// Close the unfinished dataset of a device now (used by the timeout in uplink.service). Returns the partial, or null.
function flushIncomplete(devEui, reason = "timeout") {
  const s = chunkSessions[devEui];
  if (!s || s.received >= s.total) return null;
  delete chunkSessions[devEui];
  return buildPartial(s, reason);
}

function decodeChunkPacket(devEui, fPort, b64) {
  const buf = Buffer.from(b64, "base64");
  const hex = buf.toString("hex");

  if (fPort !== chunkFPort()) return { error: `Unhandled FPort ${fPort}`, hex };
  if (buf.length < HEADER_SIZE) return { error: "Payload too short", hex };

  // ---- 3-byte header ----
  const type = buf[0];
  const total = buf[1];
  const index = buf[2];
  const headerHex = buf.subarray(0, HEADER_SIZE).toString("hex");

  // Probe packet (data-rate test): "02 01 00 <DR>"
  if (type === TYPE_PROBE) {
    if (buf.length < HEADER_SIZE + 1) return { error: "Probe packet too short", hex };
    return { kind: "probe", type, dataRate: buf[3], hex };
  }

  if (type !== TYPE_SINGLE && type !== TYPE_BATCH && type !== TYPE_PACK12) {
    return { error: `Unknown packet type ${type} (${buf.length} bytes)`, hex };
  }
  if (total < 1) return { error: "Total chunks must be 1 to 255", hex };
  if (index >= total) {
    return { error: `Chunk number ${index} is outside the dataset (${total} chunks)`, hex };
  }

  const data = buf.subarray(HEADER_SIZE);
  if (data.length === 0) return { error: "Chunk has no data", hex };

  // ---- samples inside THIS chunk ----
  const packed = type === TYPE_PACK12;
  const layout = pack12Layout();
  let chunkSamples;
  if (packed) {
    if (data.length % 3 !== 0) {
      return { error: `Packed data length ${data.length} is not a multiple of 3 bytes (2 samples of 12 bit)`, hex };
    }
    chunkSamples = unpack12(data, layout);
  } else {
    if (data.length % 2 !== 0) {
      return { error: `Data length ${data.length} is not a whole number of 16-bit samples`, hex };
    }
    chunkSamples = []; // 16-bit little-endian
    for (let i = 0; i + 1 < data.length; i += 2) chunkSamples.push(data.readUInt16LE(i));
  }

  // ---- collect chunks per device until every chunk of the dataset has arrived ----
  let s = chunkSessions[devEui];
  let previousIncomplete = false;
  let discardedPartial = null; // the unfinished dataset this chunk replaces, if any
  // a new dataset starts when the type/total changes, or chunk 0 arrives again
  if (!s || s.type !== type || s.total !== total || (index === 0 && s.chunks[0] !== null)) {
    previousIncomplete = !!s && s.received < s.total;
    if (previousIncomplete) discardedPartial = buildPartial(s, "new-dataset");
    s = chunkSessions[devEui] = {
      type,
      total,
      datasetKind: type === TYPE_BATCH ? "batch" : packed ? "packed" : "single",
      sampleBits: packed ? 12 : 16,
      packLayout: packed ? layout : undefined,
      chunks: new Array(total).fill(null),
      received: 0,
      lastChunkAt: Date.now(),
    };
  }
  s.lastChunkAt = Date.now();

  const duplicate = s.chunks[index] !== null; // a resent chunk just overwrites
  s.chunks[index] = chunkSamples;
  if (!duplicate) s.received++;

  const complete = s.received >= s.total;
  const result = {
    kind: complete ? "dataset" : "chunk",
    datasetKind: type === TYPE_BATCH ? "batch" : packed ? "packed" : "single",
    sampleBits: packed ? 12 : 16,
    packLayout: packed ? layout : undefined,
    header: {
      hex: headerHex,
      type,
      total,
      chunk: index,
    },
    chunkSamples,
    chunksReceived: s.received,
    receivedChunks: s.received,
    totalChunks: s.total,
    duplicate,
    previousIncomplete,
    previousMissing: discardedPartial ? discardedPartial.missingChunks.length : 0,
    discardedPartial, // taken out again by uplink.service (saved as its own "partial" row)
    battery: null, // not sent by the node yet
    hex,
  };

  if (complete) {
    const samples = [].concat(...s.chunks);
    const { min, max, avg } = statsOf(samples);
    result.samples = samples;
    result.sampleCount = samples.length;
    result.min = min;
    result.max = max;
    result.avg = avg;
    if (packed && samples.length !== PACK12_SAMPLES_PER_DATASET) {
      result.warning = `Dataset has ${samples.length} samples, expected ${PACK12_SAMPLES_PER_DATASET}`;
    }
    delete chunkSessions[devEui];
  }
  return result;
}

function printChunkResult(deviceName, devEui, r) {
  const line = "━".repeat(63);

  if (r.error) {
    console.log(`Decode error  : ${r.error}`);
    return;
  }

  if (r.kind === "probe") {
    console.log(`Probe packet  : data-rate test at DR${r.dataRate} (no samples, ignored)`);
    return;
  }

  const hdrHex = r.header.hex.match(/../g).join(" ");
  console.log(line);
  console.log(`📦 CHUNK RECEIVED - ${deviceName} (${devEui})`);
  console.log(line);
  console.log(`HEADER (3 B)  : ${hdrHex}`);
  console.log(`  Type        : ${r.header.type} (${TYPE_NAMES[r.header.type]})`);
  console.log(`  Total chunks: ${r.header.total}`);
  console.log(`  Chunk number: ${r.header.chunk} (0-based)`);
  if (r.sampleBits === 12) console.log(`Samples       : 12-bit packed (layout ${r.packLayout})`);
  console.log(`Battery       : N/A (not sent by node yet)`);
  console.log(`Chunk samples : [${r.chunkSamples.join(", ")}]`);
  console.log(
    `Progress      : ${r.receivedChunks}/${r.totalChunks} chunk(s)` +
      (r.duplicate ? "  (duplicate chunk, overwritten)" : ""),
  );
  if (r.previousIncomplete) {
    console.log(`⚠️  Previous dataset was incomplete (${r.previousMissing} chunk(s) missing) and was saved as partial`);
  }

  if (r.kind === "dataset") {
    console.log(line);
    console.log(`✅ DATASET COMPLETE - ${deviceName} (${devEui})`);
    console.log(line);
    console.log(`Samples       : ${r.sampleCount}`);
    if (r.warning) console.log(`⚠️  ${r.warning}`);
    console.log(`Stats         : min=${r.min} | max=${r.max} | avg=${r.avg}`);
    console.log(`All Samples   : [${r.samples.join(", ")}]`);
  }
  console.log(line);
}

function printPartialResult(deviceName, devEui, p) {
  const line = "━".repeat(63);
  console.log(line);
  console.log(`⚠️  PARTIAL DATASET - ${deviceName} (${devEui})`);
  console.log(line);
  console.log(`Reason        : ${p.reason === "timeout" ? "no new chunk for a while" : "a new dataset started first"}`);
  console.log(`Chunks        : ${p.receivedChunks}/${p.totalChunks} received, ${p.missingChunks.length} missing`);
  console.log(`Missing chunks: [${p.missingChunks.join(", ")}]`);
  console.log(`Samples        : ${p.sampleCount} (from the received chunks only)`);
  if (p.stats) console.log(`Stats         : min=${p.stats.min} | max=${p.stats.max} | avg=${p.stats.avg}`);
  console.log(line);
}

module.exports = {
  CHUNK_DEVICES,
  isChunkDevice,
  decodeChunkPacket,
  printChunkResult,
  printPartialResult,
  flushIncomplete,
  partialTimeoutMs,
};
