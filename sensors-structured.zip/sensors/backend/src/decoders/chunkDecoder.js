// ─── Chunked-dataset devices (STM32 node sending the ADC dataset) ───
// Every uplink on the ADC port (FPort 2) starts with a 3-byte header, followed by the data:
//
//   byte 0   packet type   00 = single dataset, 01 = batch dataset, 02 = probe (SF/DR info)
//   byte 1   total chunks  1 to 255
//   byte 2   chunk number  0-based (00, 01, 02, ...)
//   byte 3+  data          ADC samples (uint16, little-endian), or probe info
//
// Examples:
//   00 40 00 ...  single dataset, 64 chunks in total, chunk 0
//   01 26 25 ...  batch dataset, 38 chunks in total, chunk 37 (the last one)
//   02 01 00 05   probe packet, byte 3 is the data rate being tested (DR5)
const CHUNK_DEVICES = new Set([
  "50c6c10d19c40cce", // mohan
]);
const HEADER_SIZE = 3;
const TYPE_SINGLE = 0;
const TYPE_BATCH = 1;
const TYPE_PROBE = 2;
const TYPE_NAMES = { [TYPE_SINGLE]: "single dataset", [TYPE_BATCH]: "batch dataset", [TYPE_PROBE]: "probe" };

const chunkSessions = {}; // devEui -> { type, total, chunks[], received }

function decodeChunkPacket(devEui, fPort, b64) {
  const buf = Buffer.from(b64, "base64");
  const hex = buf.toString("hex");

  if (fPort !== 2) return { error: `Unhandled FPort ${fPort}`, hex };
  if (buf.length < HEADER_SIZE) return { error: "Payload too short", hex };

  // ---- 3-byte header ----
  const type = buf[0];
  const total = buf[1];
  const index = buf[2];
  const headerHex = buf.subarray(0, HEADER_SIZE).toString("hex");

  // Probe packet (data-rate test): "02 01 00 <DR>"
  if (type === TYPE_PROBE) {
    if (buf.length < HEADER_SIZE + 1) return { error: "Probe packet too short", hex };
    return { kind: "probe", type, dataRate: buf[3], hex };
  }

  if (type !== TYPE_SINGLE && type !== TYPE_BATCH) {
    return { error: `Unknown packet type ${type} (${buf.length} bytes)`, hex };
  }
  if (total < 1) return { error: "Total chunks must be 1 to 255", hex };
  if (index >= total) {
    return { error: `Chunk number ${index} is outside the dataset (${total} chunks)`, hex };
  }

  const data = buf.subarray(HEADER_SIZE);
  if (data.length === 0) return { error: "Chunk has no data", hex };
  if (data.length % 2 !== 0) {
    return { error: `Data length ${data.length} is not a whole number of 16-bit samples`, hex };
  }

  // ---- samples inside THIS chunk (16-bit little-endian) ----
  const chunkSamples = [];
  for (let i = 0; i + 1 < data.length; i += 2) chunkSamples.push(data.readUInt16LE(i));

  // ---- collect chunks per device until every chunk of the dataset has arrived ----
  let s = chunkSessions[devEui];
  let previousIncomplete = false;
  // a new dataset starts when the type/total changes, or chunk 0 arrives again
  if (!s || s.type !== type || s.total !== total || (index === 0 && s.chunks[0] !== null)) {
    previousIncomplete = !!s && s.received < s.total;
    s = chunkSessions[devEui] = {
      type,
      total,
      chunks: new Array(total).fill(null),
      received: 0,
    };
  }

  const duplicate = s.chunks[index] !== null; // a resent chunk just overwrites
  s.chunks[index] = chunkSamples;
  if (!duplicate) s.received++;

  const complete = s.received >= s.total;
  const result = {
    kind: complete ? "dataset" : "chunk",
    datasetKind: type === TYPE_BATCH ? "batch" : "single",
    header: {
      hex: headerHex,
      type,
      total,
      chunk: index,
    },
    chunkSamples,
    chunksReceived: s.received,
    receivedChunks: s.received,
    totalChunks: s.total,
    duplicate,
    previousIncomplete,
    battery: null, // not sent by the node yet
    hex,
  };

  if (complete) {
    const samples = [].concat(...s.chunks);
    let min = Infinity;
    let max = -Infinity;
    let sum = 0;
    for (const v of samples) {
      if (v < min) min = v;
      if (v > max) max = v;
      sum += v;
    }
    result.samples = samples;
    result.sampleCount = samples.length;
    result.min = min;
    result.max = max;
    result.avg = Number((sum / samples.length).toFixed(2));
    delete chunkSessions[devEui];
  }
  return result;
}

function printChunkResult(deviceName, devEui, r) {
  const line = "━".repeat(63);

  if (r.error) {
    console.log(`Decode error  : ${r.error}`);
    return;
  }

  if (r.kind === "probe") {
    console.log(`Probe packet  : data-rate test at DR${r.dataRate} (no samples, ignored)`);
    return;
  }

  const hdrHex = r.header.hex.match(/../g).join(" ");
  console.log(line);
  console.log(`📦 CHUNK RECEIVED - ${deviceName} (${devEui})`);
  console.log(line);
  console.log(`HEADER (3 B)  : ${hdrHex}`);
  console.log(`  Type        : ${r.header.type} (${TYPE_NAMES[r.header.type]})`);
  console.log(`  Total chunks: ${r.header.total}`);
  console.log(`  Chunk number: ${r.header.chunk} (0-based)`);
  console.log(`Battery       : N/A (not sent by node yet)`);
  console.log(`Chunk samples : [${r.chunkSamples.join(", ")}]`);
  console.log(
    `Progress      : ${r.receivedChunks}/${r.totalChunks} chunk(s)` +
      (r.duplicate ? "  (duplicate chunk, overwritten)" : ""),
  );
  if (r.previousIncomplete) {
    console.log(`⚠️  Previous dataset was incomplete and has been discarded`);
  }

  if (r.kind === "dataset") {
    console.log(line);
    console.log(`✅ DATASET COMPLETE - ${deviceName} (${devEui})`);
    console.log(line);
    console.log(`Samples       : ${r.sampleCount}`);
    console.log(`Stats         : min=${r.min} | max=${r.max} | avg=${r.avg}`);
    console.log(`All Samples   : [${r.samples.join(", ")}]`);
  }
  console.log(line);
}

module.exports = { CHUNK_DEVICES, decodeChunkPacket, printChunkResult };
