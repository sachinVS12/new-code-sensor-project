// ─── RAK5146 / WisBlock FPort-2 decoder ──────────────────
function decodeRak5146(fPort, b64) {
  const buf = Buffer.from(b64, "base64");

  if (fPort !== 2) {
    return { error: `Unhandled FPort ${fPort}`, hex: buf.toString("hex") };
  }
  if (buf.length < 8) {
    return { error: "Payload too short", hex: buf.toString("hex") };
  }

  const version = buf[0];
  const type = buf[1];
  const reserved = buf[2];
  const count = buf[3];
  const duration = buf.readUInt16BE(4);
  const batteryRaw = buf.readUInt16BE(6);

  const samples = [];
  for (let i = 8; i + 1 < buf.length; i += 2) {
    samples.push(buf.readUInt16BE(i));
  }

  // Filter out outlier values (likely transmission errors)
  // Remove values > 10000 which are clearly spurious (normal ADC samples are < 5000)
  const filteredSamples = samples.filter(s => s < 10000);

  // Additional filtering: use interquartile range (IQR) method for robust outlier detection
  if (filteredSamples.length > 20) {
    const sorted = [...filteredSamples].sort((a, b) => a - b);
    const q1 = sorted[Math.floor(sorted.length * 0.25)];
    const q3 = sorted[Math.floor(sorted.length * 0.75)];
    const iqr = q3 - q1;
    const lowerBound = q1 - 1.5 * iqr;
    const upperBound = q3 + 1.5 * iqr;

    const iqrFiltered = filteredSamples.filter(s => s >= lowerBound && s <= upperBound);
    if (iqrFiltered.length > filteredSamples.length * 0.6) {
      console.log(`⚠️  IQR filtering: removed ${filteredSamples.length - iqrFiltered.length} samples (Q1=${q1}, Q3=${q3}, IQR=${iqr})`);
      filteredSamples.length = 0;
      filteredSamples.push(...iqrFiltered);
    }
  }

  // If we filtered out some outliers, use the filtered array
  if (filteredSamples.length > 0 && filteredSamples.length < samples.length) {
    console.log(`⚠️  Total filtered: ${samples.length - filteredSamples.length} outlier samples`);
    // Replace samples array with filtered version
    samples.length = 0;
    samples.push(...filteredSamples);
  }

  const min = samples.length ? Math.min(...samples) : null;
  const max = samples.length ? Math.max(...samples) : null;
  const avg = samples.length
    ? Number((samples.reduce((a, b) => a + b, 0) / samples.length).toFixed(2))
    : null;

  return {
    version,
    type,
    reserved,
    count,
    duration,
    batteryRaw,
    batteryV: (batteryRaw / 100).toFixed(2),
    sampleCount: samples.length,
    min,
    max,
    avg,
    samples,
    samplesPreview: samples.slice(0, 16),
    hex: buf.toString("hex"),
  };
}

module.exports = { decodeRak5146 };
