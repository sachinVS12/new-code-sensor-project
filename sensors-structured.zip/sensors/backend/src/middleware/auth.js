const { isAllowedOrigin } = require("../services/websocket.service");

// Every /api route except /api/auth needs a valid session (cookie). authDisabled = AUTH_DISABLED=true (development only).
function createRequireAuth(auth, { authDisabled = false } = {}) {
  return function requireAuth(req, res, next) {
    if (authDisabled) return next();
    const session = auth.sessionFromHeaders(req.headers);
    if (!session) return res.status(401).json({ error: "Not logged in" });
    req.user = session;
    next();
  };
}

// Cross-site request protection for changes (POST / PUT / PATCH / DELETE): the cookie is SameSite=Strict already,
// and a browser also sends the Origin of the page that made the request, which must be this site (or an allowed one).
function originGuard(req, res, next) {
  if (req.method === "GET" || req.method === "HEAD" || req.method === "OPTIONS") return next();
  const origin = req.headers.origin;
  if (origin && !isAllowedOrigin(origin, req.headers.host)) {
    return res.status(403).json({ error: "Request from an unknown origin was refused" });
  }
  next();
}

module.exports = { createRequireAuth, originGuard };
