// Basic hardening for the HTTP API and the built frontend: security headers, a request rate limit and
// JSON error replies. No extra packages needed.

// ── security headers ─────────────────────────────────────
// CSP only on pages (not on /api replies). Turn it off with DISABLE_CSP=true if a custom setup needs it.
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'", // the UI uses inline styles
  "img-src 'self' data: blob:",
  "connect-src 'self' ws: wss:",
  "object-src 'none'",
  "base-uri 'self'",
  "frame-ancestors 'none'",
].join("; ");

function securityHeaders(req, res, next) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  if (req.secure || req.headers["x-forwarded-proto"] === "https") {
    res.setHeader("Strict-Transport-Security", "max-age=15552000; includeSubDomains");
  }
  if (!req.path.startsWith("/api") && process.env.DISABLE_CSP !== "true") {
    res.setHeader("Content-Security-Policy", CSP);
  }
  next();
}

// ── rate limit (per client IP, in memory) ────────────────
// RATE_LIMIT_PER_MINUTE (default 600, 0 = off). Behind a reverse proxy set TRUST_PROXY=1 so the real client IP is used.
function createRateLimiter({ max, windowMs = 60 * 1000, now = () => Date.now() } = {}) {
  const hits = new Map();
  const timer = setInterval(() => {
    const t = now();
    for (const [ip, h] of hits) if (h.resetAt <= t) hits.delete(ip);
  }, windowMs);
  if (timer.unref) timer.unref();

  const middleware = (req, res, next) => {
    if (!max || max <= 0) return next();
    const ip = req.ip || (req.socket && req.socket.remoteAddress) || "unknown";
    const t = now();
    let h = hits.get(ip);
    if (!h || h.resetAt <= t) {
      h = { count: 0, resetAt: t + windowMs };
      hits.set(ip, h);
    }
    h.count++;
    res.setHeader("RateLimit-Limit", String(max));
    res.setHeader("RateLimit-Remaining", String(Math.max(0, max - h.count)));
    if (h.count > max) {
      res.setHeader("Retry-After", String(Math.max(1, Math.ceil((h.resetAt - t) / 1000))));
      return res.status(429).json({ error: "Too many requests. Please wait a moment and try again." });
    }
    next();
  };
  middleware.hits = hits;
  return middleware;
}

// ── errors always as JSON ────────────────────────────────
const apiNotFound = (req, res) => res.status(404).json({ error: "API route not found" });

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err && err.type === "entity.parse.failed") return res.status(400).json({ error: "Invalid JSON in the request body" });
  if (err && err.type === "entity.too.large") return res.status(413).json({ error: "Request body is too large" });
  console.error("❌ Unhandled error:", err && err.message ? err.message : err); // never send the stack to the client
  res.status(500).json({ error: "Internal server error" });
}

module.exports = { securityHeaders, createRateLimiter, apiNotFound, errorHandler, CSP };
