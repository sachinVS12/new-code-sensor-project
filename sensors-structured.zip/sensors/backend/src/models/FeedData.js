const mongoose = require('mongoose');

// Rows uploaded on the Downlink > Feed Data tab (Excel / CSV: "Frame Port" + "Purpose"),
// stored per device.
const feedDataSchema = new mongoose.Schema({
  devEui: { type: String, required: true, index: true },
  deviceName: { type: String, required: true },
  framePort: { type: Number, required: true, min: 1, max: 223 },
  purpose: { type: String, required: true, trim: true, maxlength: 200 },
  sourceFile: { type: String, default: '' }
}, { timestamps: true });

feedDataSchema.index({ devEui: 1, framePort: 1 }, { unique: true });

module.exports = mongoose.model('FeedData', feedDataSchema);
