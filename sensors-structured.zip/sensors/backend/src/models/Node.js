const mongoose = require('mongoose');

const nodeSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true,
    unique: true
  },
  devEui: {
    type: String,
    required: true,
    unique: true
  },
  applicationId: {
    type: String,
    required: true
  },
  mqttTopic: {
    type: String,
    required: true
  },
  mode: {
    type: String,
    enum: ['OTAA', 'ABP'],
    default: 'OTAA'
  },
  // the gateway this device uses, by the gateway's ID (null = none). The name is looked up when needed.
  gatewayId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Gateway',
    default: null
  },
  // ChirpStack device profile of this device, by its ID ('' = not known)
  deviceProfileId: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Node', nodeSchema);
