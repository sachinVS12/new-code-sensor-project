const mongoose = require('mongoose');

const nodeSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true,
    unique: true
  },
  devEui: {
    type: String,
    required: true,
    unique: true
  },
  applicationId: {
    type: String,
    required: true
  },
  mqttTopic: {
    type: String,
    required: true
  },
  mode: {
    type: String,
    enum: ['OTAA', 'ABP'],
    default: 'OTAA'
  },
  gateway: {
    type: String,
    default: ''
  },
  // true when this app created it in ChirpStack (so deleting it here removes it there too)
  chirpstackSynced: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Node', nodeSchema);
