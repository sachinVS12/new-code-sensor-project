const mongoose = require('mongoose');

const sensorDataSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true
  },
  devEui: {
    type: String,
    required: true,
    index: true
  },
  // indexed in services/migrations.js (ensureSensorDataRetention): plain index, or a TTL index when
  // SENSOR_DATA_RETENTION_DAYS is set
  timestamp: {
    type: Date,
    required: true
  },
  rssi: {
    type: Number
  },
  snr: {
    type: Number
  },
  fPort: {
    type: Number
  },
  data: {
    type: String
  },
  decodedPayload: {
    type: mongoose.Schema.Types.Mixed
  },
  gatewayId: {
    type: String
  },
  frequency: {
    type: Number
  },
  dataRate: {
    type: String
  },
  spreadingFactor: {
    type: Number
  },
  fCnt: {
    type: Number
  }
}, {
  timestamps: true
});

// Index for efficient queries
sensorDataSchema.index({ devEui: 1, timestamp: -1 });

module.exports = mongoose.model('SensorData', sensorDataSchema);
