const express = require("express");
const c = require("../controllers/application.controller");

const router = express.Router();

router.get("/", c.getApplications);
router.post("/", c.createApplication);

module.exports = router;
