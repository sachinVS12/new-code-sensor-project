const express = require("express");
const c = require("../controllers/application.controller");

const { validateUuid } = require("../utils/ids");

const router = express.Router();
router.param("id", validateUuid);

router.get("/", c.getApplications);
router.post("/", c.createApplication);
router.get("/:id", c.getApplication);
router.put("/:id", c.updateApplication);
router.delete("/:id", c.deleteApplication);

module.exports = router;
