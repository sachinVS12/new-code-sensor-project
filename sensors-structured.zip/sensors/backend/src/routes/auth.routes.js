const express = require("express");
const c = require("../controllers/auth.controller");
const { createRateLimiter } = require("../middleware/security");

const router = express.Router();

// 10 login attempts per 15 minutes from one IP (guessing passwords is slow)
router.post("/login", createRateLimiter({ max: 10, windowMs: 15 * 60 * 1000 }), c.login);
router.get("/me", c.me);
router.post("/logout", c.logout);

module.exports = router;
