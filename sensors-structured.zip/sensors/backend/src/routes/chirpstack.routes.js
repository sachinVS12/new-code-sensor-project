const express = require("express");
const c = require("../controllers/chirpstack.controller");

const router = express.Router();

router.get("/status", c.getStatus);

module.exports = router;
