const express = require("express");
const c = require("../controllers/dashboard.controller");

const router = express.Router();

router.get("/", c.getDashboard);

module.exports = router;
