const express = require("express");
const c = require("../controllers/deviceProfile.controller");

const router = express.Router();

router.get("/", c.getDeviceProfiles);
router.post("/", c.createDeviceProfile);

module.exports = router;
