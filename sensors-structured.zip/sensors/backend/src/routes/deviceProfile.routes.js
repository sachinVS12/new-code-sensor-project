const express = require("express");
const c = require("../controllers/deviceProfile.controller");

const { validateUuid } = require("../utils/ids");

const router = express.Router();
router.param("id", validateUuid);

router.get("/", c.getDeviceProfiles);
router.post("/", c.createDeviceProfile);
router.get("/:id", c.getDeviceProfile);
router.put("/:id", c.updateDeviceProfile);
router.delete("/:id", c.deleteDeviceProfile);

module.exports = router;
