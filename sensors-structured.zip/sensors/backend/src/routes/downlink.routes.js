const express = require("express");
const c = require("../controllers/downlink.controller");

const { validateObjectId } = require("../utils/ids");

const router = express.Router();
router.param("id", validateObjectId);

router.get("/", c.getDownlinks);
router.post("/", c.sendDownlink);
router.delete("/:id", c.deleteDownlink);

module.exports = router;
