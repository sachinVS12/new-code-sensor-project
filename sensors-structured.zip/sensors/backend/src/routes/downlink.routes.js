const express = require("express");
const c = require("../controllers/downlink.controller");

const router = express.Router();

router.get("/", c.getDownlinks);
router.post("/", c.sendDownlink);
router.delete("/:id", c.deleteDownlink);

module.exports = router;
