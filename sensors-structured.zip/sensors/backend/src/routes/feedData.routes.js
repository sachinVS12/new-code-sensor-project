const express = require("express");
const c = require("../controllers/feedData.controller");

const router = express.Router();

router.get("/", c.getFeedData);
router.post("/", c.saveFeedData);
router.delete("/", c.clearFeedData);

module.exports = router;
