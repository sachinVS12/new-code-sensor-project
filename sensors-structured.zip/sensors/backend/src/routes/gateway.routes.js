const express = require("express");
const c = require("../controllers/gateway.controller");

const { validateObjectId } = require("../utils/ids");

const router = express.Router();
router.param("id", validateObjectId);

router.get("/", c.getGateways);
router.post("/", c.createGateway);
router.get("/:id", c.getGateway);
router.put("/:id", c.updateGateway);
router.delete("/:id", c.deleteGateway);

module.exports = router;
