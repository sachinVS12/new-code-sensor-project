const express = require("express");
const c = require("../controllers/gateway.controller");

const router = express.Router();

router.get("/", c.getGateways);
router.post("/", c.createGateway);
router.put("/:id", c.updateGateway);
router.delete("/:id", c.deleteGateway);

module.exports = router;
