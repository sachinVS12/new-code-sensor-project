const express = require("express");

const router = express.Router();

router.use("/nodes", require("./node.routes"));
router.use("/gateways", require("./gateway.routes"));
router.use("/downlinks", require("./downlink.routes"));
router.use("/feed-data", require("./feedData.routes"));
router.use("/chirpstack", require("./chirpstack.routes"));
router.use("/device-profiles", require("./deviceProfile.routes"));
router.use("/applications", require("./application.routes"));
router.use("/dashboard", require("./dashboard.routes"));
router.use("/", require("./sensorData.routes")); // GET /api/latest

module.exports = router;
