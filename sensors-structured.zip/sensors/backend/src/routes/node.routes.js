const express = require("express");
const c = require("../controllers/node.controller");

const { validateObjectId } = require("../utils/ids");

const router = express.Router();
router.param("id", validateObjectId);

router.get("/", c.getNodes);
router.post("/", c.createNode);
router.get("/:id", c.getNode);
router.put("/:id", c.updateNode);
router.delete("/:id", c.deleteNode);

module.exports = router;
