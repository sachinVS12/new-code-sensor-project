const express = require("express");
const c = require("../controllers/node.controller");

const router = express.Router();

router.get("/", c.getNodes);
router.post("/", c.createNode);
router.put("/:id", c.updateNode);
router.delete("/:id", c.deleteNode);

module.exports = router;
