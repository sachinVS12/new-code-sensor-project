const express = require("express");
const c = require("../controllers/sensorData.controller");

const router = express.Router();

router.get("/latest", c.getLatest);

module.exports = router;
