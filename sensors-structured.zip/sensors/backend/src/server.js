const http = require("http");
const { PORT, BROWSER_LOG_STREAM, SENSOR_DATA_RETENTION_DAYS } = require("./config/env");        // loads .env and validates it first
const app = require("./app");
const { connectDB } = require("./config/db");
const Node = require("./models/Node");
const { deviceNames } = require("./services/deviceRegistry");
const { migrateNodeReferences, ensureSensorDataRetention } = require("./services/migrations");
const { initWebSocket, hookConsoleToWebSocket } = require("./services/websocket.service");
const { connectMqtt, disconnectMqtt, subscribeTopic } = require("./services/mqtt.service");

const server = http.createServer(app);

// Load device names from MongoDB on startup and subscribe to each device's topic
async function loadDeviceNames() {
  try {
    const nodes = await Node.find({});
    nodes.forEach((node) => {
      deviceNames[node.devEui.toLowerCase()] = node.deviceName;
      subscribeTopic(node.mqttTopic);
    });
    console.log(`📋 Loaded ${Object.keys(deviceNames).length} device names from database`);
  } catch (err) {
    console.error("❌ Error loading device names:", err.message);
  }
}

async function start() {
  initWebSocket(server);
  if (BROWSER_LOG_STREAM) hookConsoleToWebSocket(); // off by default: server logs (payloads, device info) must not go to every browser
  connectMqtt();
  await connectDB();
  try {
    await migrateNodeReferences();
    await ensureSensorDataRetention(SENSOR_DATA_RETENTION_DAYS);
  } catch (err) {
    console.error("❌ Migration error:", err.message);
  }
  await loadDeviceNames();

  server.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
}

// ─── Graceful shutdown ───────────────────────────────────
const shutdown = () => {
  console.log("\n🛑 Shutting down...");
  disconnectMqtt(() => {
    server.close(() => process.exit(0));
  });
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

start();
