const crypto = require("crypto");
const { AUTH_DISABLED, ADMIN_USERNAME, ADMIN_PASSWORD, ADMIN_PASSWORD_HASH, AUTH_SECRET, SESSION_HOURS } = require("../config/env");
const { createAuth } = require("./auth.service");

if (!AUTH_DISABLED && !AUTH_SECRET) {
  console.warn("⚠️  AUTH_SECRET is not set: a random one is used, so everyone is logged out whenever the server restarts. Set AUTH_SECRET in .env.");
}
if (!AUTH_DISABLED && !ADMIN_PASSWORD_HASH && ADMIN_PASSWORD) {
  console.warn("⚠️  ADMIN_PASSWORD is stored as plain text in .env. Use ADMIN_PASSWORD_HASH instead (npm run hash-password).");
}
if (AUTH_DISABLED) console.warn("⚠️  AUTH_DISABLED=true: the dashboard has NO login. Use this for development only.");

const auth = createAuth({
  username: ADMIN_USERNAME,
  password: ADMIN_PASSWORD,
  passwordHash: ADMIN_PASSWORD_HASH,
  secret: AUTH_SECRET || crypto.randomBytes(32).toString("hex"),
  sessionHours: SESSION_HOURS,
});

module.exports = { auth, AUTH_DISABLED };
