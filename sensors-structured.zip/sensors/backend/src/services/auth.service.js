const crypto = require("crypto");

// Login for the dashboard: one user, a signed session cookie (no extra packages).
//   password   stored as a scrypt hash (ADMIN_PASSWORD_HASH, made with: npm run hash-password) or, for a quick start, plain (ADMIN_PASSWORD)
//   session    "payload.signature" token: payload = { u: username, exp }, signature = HMAC-SHA256 with AUTH_SECRET
//   cookie     HttpOnly (JavaScript cannot read it), SameSite=Strict, Secure on HTTPS
const COOKIE_NAME = "sensors_session";

const sha256 = (v) => crypto.createHash("sha256").update(String(v)).digest();
// compares two strings in constant time (lengths are hidden by hashing both first)
const safeEqual = (a, b) => crypto.timingSafeEqual(sha256(a), sha256(b));

// ── password hashes: scrypt$N$r$p$salt$hash (base64) ─────
function hashPassword(password, { N = 16384, r = 8, p = 1 } = {}) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, 32, { N, r, p });
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64")}$${hash.toString("base64")}`;
}

function verifyHash(password, stored) {
  const parts = String(stored).split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, N, r, p, salt, hash] = parts;
  try {
    const expected = Buffer.from(hash, "base64");
    const actual = crypto.scryptSync(String(password), Buffer.from(salt, "base64"), expected.length, { N: +N, r: +r, p: +p });
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function parseCookies(header) {
  const out = {};
  String(header || "")
    .split(";")
    .forEach((part) => {
      const i = part.indexOf("=");
      if (i < 0) return;
      const k = part.slice(0, i).trim();
      if (k) {
        try {
          out[k] = decodeURIComponent(part.slice(i + 1).trim());
        } catch {
          /* ignore a broken cookie */
        }
      }
    });
  return out;
}

// config: { username, password, passwordHash, secret, sessionHours }
function createAuth(config) {
  const secret = config.secret || crypto.randomBytes(32).toString("hex");
  const sessionMs = (config.sessionHours || 12) * 60 * 60 * 1000;

  const sign = (data) => crypto.createHmac("sha256", secret).update(data).digest("base64url");

  function createToken(username, now = Date.now()) {
    const payload = Buffer.from(JSON.stringify({ u: username, exp: now + sessionMs })).toString("base64url");
    return `${payload}.${sign(payload)}`;
  }

  // returns { username } for a valid, unexpired token, otherwise null
  function verifyToken(token, now = Date.now()) {
    if (typeof token !== "string") return null;
    const [payload, signature, extra] = token.split(".");
    if (!payload || !signature || extra !== undefined) return null;
    const expected = Buffer.from(sign(payload));
    const given = Buffer.from(signature);
    if (expected.length !== given.length || !crypto.timingSafeEqual(expected, given)) return null;
    try {
      const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
      if (!data || typeof data.u !== "string" || typeof data.exp !== "number" || data.exp <= now) return null;
      return { username: data.u };
    } catch {
      return null;
    }
  }

  // both parts are always checked, so a wrong username takes as long as a wrong password
  function checkCredentials(username, password) {
    const userOk = safeEqual(username ?? "", config.username ?? "");
    let passOk = false;
    if (config.passwordHash) passOk = verifyHash(password ?? "", config.passwordHash);
    else if (config.password) passOk = safeEqual(password ?? "", config.password);
    return userOk && passOk;
  }

  function sessionFromHeaders(headers) {
    return verifyToken(parseCookies(headers && headers.cookie)[COOKIE_NAME]);
  }

  function sessionCookie(token, { secure = false } = {}) {
    return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(sessionMs / 1000)}${secure ? "; Secure" : ""}`;
  }

  function clearCookie({ secure = false } = {}) {
    return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure ? "; Secure" : ""}`;
  }

  return { createToken, verifyToken, checkCredentials, sessionFromHeaders, sessionCookie, clearCookie };
}

module.exports = { COOKIE_NAME, createAuth, hashPassword, verifyHash, parseCookies, safeEqual };
