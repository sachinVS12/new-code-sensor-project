const {
  CHIRPSTACK_API_URL,
  CHIRPSTACK_API_TOKEN,
  CHIRPSTACK_TENANT_ID,
  CHIRPSTACK_DEVICE_PROFILE_ID,
} = require("../config/env");

// Talks to the ChirpStack v4 REST API (the "chirpstack-rest-api" proxy, usually http://<server>:8090).
// Authentication: an API key, sent as "Grpc-Metadata-Authorization: Bearer <key>".

const HEX32 = /^[0-9a-fA-F]{32}$/;
const ZERO_KEY = "00000000000000000000000000000000";

class ChirpstackError extends Error {
  constructor(message, status = 0, alreadyExists = false) {
    super(message);
    this.name = "ChirpstackError";
    this.status = status;
    this.alreadyExists = alreadyExists;
  }
}

const isEnabled = () => !!(CHIRPSTACK_API_URL && CHIRPSTACK_API_TOKEN);
const defaultDeviceProfileId = () => CHIRPSTACK_DEVICE_PROFILE_ID;

async function request(method, path, body) {
  const url = CHIRPSTACK_API_URL.replace(/\/+$/, "") + path;
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Grpc-Metadata-Authorization": `Bearer ${CHIRPSTACK_API_TOKEN}`,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(10000),
    });
  } catch (err) {
    const why = err.cause?.code || err.name || err.message;
    throw new ChirpstackError(
      `Cannot reach the ChirpStack REST API at ${CHIRPSTACK_API_URL} (${why}). Is chirpstack-rest-api running?`
    );
  }

  const text = await res.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    /* not JSON */
  }

  if (!res.ok) {
    const msg = data.message || text || `HTTP ${res.status}`;
    // gRPC code 6 = ALREADY_EXISTS (HTTP 409), 16 = UNAUTHENTICATED, 7 = PERMISSION_DENIED
    if (res.status === 409 || data.code === 6) throw new ChirpstackError(msg, 409, true);
    if (res.status === 401 || res.status === 403 || data.code === 16 || data.code === 7) {
      throw new ChirpstackError(`ChirpStack rejected the API key (${msg}). Check CHIRPSTACK_API_TOKEN.`, res.status);
    }
    throw new ChirpstackError(msg, res.status);
  }
  return data;
}

// ── tenant (needed to create gateways) ───────────────────
let cachedTenantId = CHIRPSTACK_TENANT_ID;
async function getTenantId() {
  if (cachedTenantId) return cachedTenantId;
  let data;
  try {
    data = await request("GET", "/api/tenants?limit=1");
  } catch (err) {
    throw new ChirpstackError(`Could not detect the ChirpStack tenant (${err.message}). Set CHIRPSTACK_TENANT_ID in backend/.env.`, err.status);
  }
  const id = data.result && data.result[0] && data.result[0].id;
  if (!id) throw new ChirpstackError("No ChirpStack tenant found. Set CHIRPSTACK_TENANT_ID in backend/.env.", 400);
  cachedTenantId = id;
  return id;
}

// ── gateways ─────────────────────────────────────────────
async function createGateway({ gatewayEui, gatewayName }) {
  const tenantId = await getTenantId();
  try {
    await request("POST", "/api/gateways", {
      gateway: {
        gateway_id: gatewayEui,
        name: gatewayName,
        description: "Created from the LoRaWAN dashboard",
        tenant_id: tenantId,
        stats_interval: 30,
      },
    });
    return { created: true, alreadyExisted: false };
  } catch (err) {
    if (err.alreadyExists) return { created: false, alreadyExisted: true };
    throw err;
  }
}

const deleteGateway = (gatewayEui) => request("DELETE", `/api/gateways/${gatewayEui}`);

// ── devices ──────────────────────────────────────────────
// Creates the device and, for OTAA with an AppKey, its keys.
// The Application must already exist in ChirpStack (its ID is the one entered in the form).
async function createDevice({ devEui, deviceName, applicationId, deviceProfileId, mode, appKey }) {
  const profileId = (deviceProfileId || CHIRPSTACK_DEVICE_PROFILE_ID || "").trim();
  if (!profileId) {
    throw new ChirpstackError(
      "Device Profile is required to create the device in ChirpStack (choose one in the form or set CHIRPSTACK_DEVICE_PROFILE_ID).",
      400
    );
  }
  const key = (appKey || "").trim();
  if (key && !HEX32.test(key)) {
    throw new ChirpstackError("Application Key must be 32 hex characters", 400);
  }

  try {
    await request("POST", "/api/devices", {
      device: {
        dev_eui: devEui,
        name: deviceName,
        description: "Created from the LoRaWAN dashboard",
        application_id: applicationId,
        device_profile_id: profileId,
        is_disabled: false,
        skip_fcnt_check: false,
      },
    });
  } catch (err) {
    if (err.alreadyExists) return { created: false, alreadyExisted: true };
    throw err;
  }

  const result = { created: true, alreadyExisted: false };

  if (mode === "ABP") {
    result.warning = "ABP device created without activation. Add the DevAddr and session keys in ChirpStack.";
    return result;
  }
  if (!key) {
    result.warning = "Device created without an Application Key. Add it in ChirpStack (Keys tab) before the device can join.";
    return result;
  }

  try {
    // LoRaWAN 1.0.x: the AppKey goes into nwk_key. app_key is unused (zeros).
    await request("POST", `/api/devices/${devEui}/keys`, {
      device_keys: { dev_eui: devEui, nwk_key: key, app_key: ZERO_KEY },
    });
  } catch (err) {
    // do not leave a half-configured device behind
    try {
      await deleteDevice(devEui);
    } catch {
      /* ignore */
    }
    throw new ChirpstackError(`Device keys could not be saved in ChirpStack: ${err.message}`, err.status);
  }
  return result;
}

const deleteDevice = (devEui) => request("DELETE", `/api/devices/${devEui}`);

// ── lists for the form ───────────────────────────────────
async function listDeviceProfiles() {
  const tenantId = await getTenantId();
  const data = await request("GET", `/api/device-profiles?limit=100&tenant_id=${encodeURIComponent(tenantId)}`);
  return (data.result || []).map((p) => ({ id: p.id, name: p.name }));
}

module.exports = {
  ChirpstackError,
  isEnabled,
  defaultDeviceProfileId,
  createGateway,
  deleteGateway,
  createDevice,
  deleteDevice,
  listDeviceProfiles,
};
