const {
  CHIRPSTACK_API_URL,
  CHIRPSTACK_API_TOKEN,
  CHIRPSTACK_TENANT_ID,
  CHIRPSTACK_DEVICE_PROFILE_ID,
} = require("../config/env");

// Talks to the ChirpStack v4 REST API (the "chirpstack-rest-api" proxy, usually http://<server>:8090).
// Authentication: an API key, sent as "Grpc-Metadata-Authorization: Bearer <key>".

const HEX32 = /^[0-9a-fA-F]{32}$/;
const ZERO_KEY = "00000000000000000000000000000000";

class ChirpstackError extends Error {
  constructor(message, status = 0, alreadyExists = false, notFound = false) {
    super(message);
    this.name = "ChirpstackError";
    this.status = status;
    this.alreadyExists = alreadyExists;
    this.notFound = notFound;
  }
}

const isEnabled = () => !!(CHIRPSTACK_API_URL && CHIRPSTACK_API_TOKEN);
const defaultDeviceProfileId = () => CHIRPSTACK_DEVICE_PROFILE_ID;

async function request(method, path, body) {
  const url = CHIRPSTACK_API_URL.replace(/\/+$/, "") + path;
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Grpc-Metadata-Authorization": `Bearer ${CHIRPSTACK_API_TOKEN}`,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(10000),
    });
  } catch (err) {
    const why = err.cause?.code || err.name || err.message;
    throw new ChirpstackError(
      `Cannot reach the ChirpStack REST API at ${CHIRPSTACK_API_URL} (${why}). Is chirpstack-rest-api running?`
    );
  }

  const text = await res.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    /* not JSON */
  }

  if (!res.ok) {
    const msg = data.message || text || `HTTP ${res.status}`;
    // gRPC code 6 = ALREADY_EXISTS (HTTP 409), 16 = UNAUTHENTICATED, 7 = PERMISSION_DENIED
    if (res.status === 409 || data.code === 6) throw new ChirpstackError(msg, 409, true);
    // gRPC code 5 = NOT_FOUND (HTTP 404)
    if (res.status === 404 || data.code === 5) throw new ChirpstackError(msg, 404, false, true);
    if (res.status === 401 || res.status === 403 || data.code === 16 || data.code === 7) {
      throw new ChirpstackError(`ChirpStack rejected the API key (${msg}). Check CHIRPSTACK_API_TOKEN.`, res.status);
    }
    throw new ChirpstackError(msg, res.status);
  }
  return data;
}

// ── tenant (needed to create gateways) ───────────────────
let cachedTenantId = CHIRPSTACK_TENANT_ID;
async function getTenantId() {
  if (cachedTenantId) return cachedTenantId;
  let data;
  try {
    data = await request("GET", "/api/tenants?limit=1");
  } catch (err) {
    throw new ChirpstackError(`Could not detect the ChirpStack tenant (${err.message}). Set CHIRPSTACK_TENANT_ID in backend/.env.`, err.status);
  }
  const id = data.result && data.result[0] && data.result[0].id;
  if (!id) throw new ChirpstackError("No ChirpStack tenant found. Set CHIRPSTACK_TENANT_ID in backend/.env.", 400);
  cachedTenantId = id;
  return id;
}

// ── gateways ─────────────────────────────────────────────
async function createGateway({ gatewayEui, gatewayName }) {
  const tenantId = await getTenantId();
  try {
    await request("POST", "/api/gateways", {
      gateway: {
        gateway_id: gatewayEui,
        name: gatewayName,
        description: "Created from the LoRaWAN dashboard",
        tenant_id: tenantId,
        stats_interval: 30,
      },
    });
    return { created: true, alreadyExisted: false };
  } catch (err) {
    if (err.alreadyExists) return { created: false, alreadyExisted: true };
    throw err;
  }
}

const deleteGateway = (gatewayEui) => request("DELETE", `/api/gateways/${gatewayEui}`);

async function findGateway(gatewayEui) {
  try {
    const data = await request("GET", `/api/gateways/${gatewayEui}`);
    return data.gateway || null;
  } catch (err) {
    if (err.notFound) return null;
    throw err;
  }
}

// Edit: a gateway that is not in ChirpStack yet is created. ChirpStack cannot change a gateway's ID (EUI),
// so when the EUI changed the new gateway is created first and the old one is removed afterwards.
async function updateGateway({ oldGatewayEui, gatewayEui, gatewayName }) {
  const cur = await findGateway(oldGatewayEui);

  if (gatewayEui !== oldGatewayEui) {
    const r = await createGateway({ gatewayEui, gatewayName });
    if (cur) {
      try {
        await deleteGateway(oldGatewayEui);
      } catch (err) {
        if (!err.notFound) r.warning = `The old gateway ${oldGatewayEui} could not be removed from ChirpStack: ${err.message}`;
      }
    }
    return { ...r, replaced: !!cur };
  }

  if (!cur) return createGateway({ gatewayEui, gatewayName });

  // PUT replaces the whole gateway, so start from what ChirpStack has (location, tags, ...)
  await request("PUT", `/api/gateways/${gatewayEui}`, { gateway: { ...cur, name: gatewayName } });
  return { updated: true };
}

// ── devices ──────────────────────────────────────────────
// Creates the device and, for OTAA with an AppKey, its keys.
// The Application must already exist in ChirpStack (its ID is the one entered in the form).
async function createDevice({ devEui, deviceName, applicationId, deviceProfileId, mode, appKey }) {
  const profileId = (deviceProfileId || CHIRPSTACK_DEVICE_PROFILE_ID || "").trim();
  if (!profileId) {
    throw new ChirpstackError(
      "Device Profile is required to create the device in ChirpStack (choose one in the form or set CHIRPSTACK_DEVICE_PROFILE_ID).",
      400
    );
  }
  const key = (appKey || "").trim();
  if (key && !HEX32.test(key)) {
    throw new ChirpstackError("Application Key must be 32 hex characters", 400);
  }

  try {
    await request("POST", "/api/devices", {
      device: {
        dev_eui: devEui,
        name: deviceName,
        description: "Created from the LoRaWAN dashboard",
        application_id: applicationId,
        device_profile_id: profileId,
        is_disabled: false,
        skip_fcnt_check: false,
      },
    });
  } catch (err) {
    if (err.alreadyExists) return { created: false, alreadyExisted: true };
    throw err;
  }

  const result = { created: true, alreadyExisted: false };

  if (mode === "ABP") {
    result.warning = "ABP device created without activation. Add the DevAddr and session keys in ChirpStack.";
    return result;
  }
  if (!key) {
    result.warning = "Device created without an Application Key. Add it in ChirpStack (Keys tab) before the device can join.";
    return result;
  }

  try {
    // LoRaWAN 1.0.x: the AppKey goes into nwk_key. app_key is unused (zeros).
    await request("POST", `/api/devices/${devEui}/keys`, {
      device_keys: { dev_eui: devEui, nwk_key: key, app_key: ZERO_KEY },
    });
  } catch (err) {
    // do not leave a half-configured device behind
    try {
      await deleteDevice(devEui);
    } catch {
      /* ignore */
    }
    throw new ChirpstackError(`Device keys could not be saved in ChirpStack: ${err.message}`, err.status);
  }
  return result;
}

const deleteDevice = (devEui) => request("DELETE", `/api/devices/${devEui}`);

async function findDevice(devEui) {
  try {
    const data = await request("GET", `/api/devices/${devEui}`);
    return data.device || null;
  } catch (err) {
    if (err.notFound) return null;
    throw err;
  }
}

async function findDeviceKeys(devEui) {
  try {
    const data = await request("GET", `/api/devices/${devEui}/keys`);
    return data.deviceKeys || null;
  } catch (err) {
    if (err.notFound) return null;
    throw err;
  }
}

// Saves the AppKey (LoRaWAN 1.0.x: nwk_key). Updates the keys, or creates them if the device has none yet.
async function saveDeviceKeys(devEui, appKey) {
  const cur = await findDeviceKeys(devEui);
  const body = { device_keys: { dev_eui: devEui, nwk_key: appKey, app_key: (cur && cur.appKey) || ZERO_KEY } };
  if (cur) await request("PUT", `/api/devices/${devEui}/keys`, body);
  else await request("POST", `/api/devices/${devEui}/keys`, body);
}

function checkAppKey(appKey) {
  const key = (appKey || "").trim();
  if (key && !HEX32.test(key)) throw new ChirpstackError("Application Key must be 32 hex characters", 400);
  return key;
}

// Edit (same DevEUI and same Application): updates the name, device profile and, if given, the AppKey.
// A device that is not in ChirpStack yet is created.
async function updateDevice({ devEui, deviceName, applicationId, deviceProfileId, mode, appKey }) {
  const key = checkAppKey(appKey);
  const cur = await findDevice(devEui);
  if (!cur) return createDevice({ devEui, deviceName, applicationId, deviceProfileId, mode, appKey: key });

  // PUT replaces the whole device, so start from what ChirpStack has (description, tags, variables, ...)
  const next = { ...cur, name: deviceName };
  if (deviceProfileId) next.deviceProfileId = deviceProfileId;
  await request("PUT", `/api/devices/${devEui}`, { device: next });

  if (mode !== "ABP" && key) await saveDeviceKeys(devEui, key);
  return { updated: true };
}

// Edit where the DevEUI or the Application changed. ChirpStack cannot change either of them on an existing
// device, so the device is created again (profile and AppKey are taken from the old one unless given).
async function replaceDevice({ oldDevEui, devEui, deviceName, applicationId, deviceProfileId, mode, appKey }) {
  const key = checkAppKey(appKey);
  const old = await findDevice(oldDevEui);
  const oldKeys = old ? await findDeviceKeys(oldDevEui) : null;

  const make = () =>
    createDevice({
      devEui,
      deviceName,
      applicationId,
      deviceProfileId: deviceProfileId || (old && old.deviceProfileId) || "",
      mode,
      appKey: key || (oldKeys && oldKeys.nwkKey) || "",
    });

  if (oldDevEui !== devEui) {
    // new EUI: create it first, so a failure leaves the old device untouched
    const r = await make();
    if (old) {
      try {
        await deleteDevice(oldDevEui);
      } catch (err) {
        if (!err.notFound) r.warning = `The old device ${oldDevEui} could not be removed from ChirpStack: ${err.message}`;
      }
    }
    return { ...r, replaced: !!old };
  }

  // same EUI, other application: delete, then create again (and put the old one back if that fails)
  if (!old) return make();
  await deleteDevice(oldDevEui);
  try {
    return { ...(await make()), replaced: true };
  } catch (err) {
    try {
      await createDevice({
        devEui: oldDevEui,
        deviceName: old.name,
        applicationId: old.applicationId,
        deviceProfileId: old.deviceProfileId,
        mode: oldKeys ? "OTAA" : "ABP",
        appKey: oldKeys && oldKeys.nwkKey,
      });
    } catch {
      /* could not restore */
    }
    throw err;
  }
}

// ── lists for the form ───────────────────────────────────
async function listDeviceProfiles() {
  const tenantId = await getTenantId();
  const data = await request("GET", `/api/device-profiles?limit=100&tenant_id=${encodeURIComponent(tenantId)}`);
  return (data.result || []).map((p) => ({ id: p.id, name: p.name }));
}

module.exports = {
  ChirpstackError,
  isEnabled,
  defaultDeviceProfileId,
  createGateway,
  updateGateway,
  deleteGateway,
  createDevice,
  updateDevice,
  replaceDevice,
  deleteDevice,
  listDeviceProfiles,
};
