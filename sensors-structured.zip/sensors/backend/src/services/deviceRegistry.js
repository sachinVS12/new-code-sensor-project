// devEui (lower-case) -> device name. Filled from MongoDB on startup and kept in sync by the node controller.
const deviceNames = {};

module.exports = { deviceNames };
