const Downlink = require("../models/Downlink");
const { broadcastDownlinkUpdate } = require("./websocket.service");

const DOWNLINK_CHUNK_BYTES = 240;   // fixed chunk size: each downlink carries at most 240 bytes
const MAX_DOWNLINK_CHUNKS = 50;    // safety cap per request (50 x 240 = 12000 bytes)

function parseDownlinkData(format, raw) {
  const text = String(raw ?? "");
  if (format === "hex") {
    const hex = text.replace(/0x/gi, "").replace(/[\s:,-]/g, "");
    if (!hex || hex.length % 2 !== 0 || !/^[0-9a-fA-F]+$/.test(hex)) {
      throw new Error("Hex data must have an even number of hex digits (0-9, A-F)");
    }
    return Buffer.from(hex, "hex");
  }
  if (format === "base64") {
    const b64 = text.replace(/\s/g, "");
    if (!b64 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64) || b64.length % 4 !== 0) {
      throw new Error("Invalid base64 data");
    }
    return Buffer.from(b64, "base64");
  }
  if (format === "text") {
    if (!text) throw new Error("Data is required");
    return Buffer.from(text, "utf8");
  }
  throw new Error("Format must be hex, text or base64");
}

// txack / ack events from ChirpStack move the oldest matching queue entry forward
async function handleDownlinkEvent(topic, data) {
  try {
    const devEui = (data.deviceInfo?.devEui || data.devEui || "").toLowerCase();
    if (!devEui) return;

    if (topic.endsWith("/event/txack")) {
      const updated = await Downlink.findOneAndUpdate(
        { devEui, status: "queued" },
        { status: "transmitted", fCntDown: data.fCntDown, transmittedAt: new Date() },
        { sort: { createdAt: 1, chunkIndex: 1 }, new: true }
      );
      if (updated) {
        broadcastDownlinkUpdate(updated);
        console.log(`⬇️  Downlink transmitted: ${updated.deviceName} (${devEui})`);
      }
    } else if (topic.endsWith("/event/ack") && data.acknowledged !== false) {
      const updated = await Downlink.findOneAndUpdate(
        { devEui, status: "transmitted", confirmed: true },
        { status: "acknowledged", acknowledgedAt: new Date() },
        { sort: { createdAt: 1, chunkIndex: 1 }, new: true }
      );
      if (updated) {
        broadcastDownlinkUpdate(updated);
        console.log(`✅ Downlink acknowledged: ${updated.deviceName} (${devEui})`);
      }
    }
  } catch (err) {
    console.error("❌ Error handling downlink event:", err.message);
  }
}

module.exports = {
  DOWNLINK_CHUNK_BYTES,
  MAX_DOWNLINK_CHUNKS,
  parseDownlinkData,
  handleDownlinkEvent,
};
