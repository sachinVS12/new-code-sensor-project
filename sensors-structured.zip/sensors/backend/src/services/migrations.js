const Node = require("../models/Node");
const Gateway = require("../models/Gateway");

// Older devices stored the gateway NAME in a "gateway" field. Devices now point to the gateway by ID (gatewayId).
// Runs at every start; it only touches devices that still have the old field.
async function migrateNodeReferences() {
  const col = Node.collection;
  const legacy = await col.find({ gateway: { $exists: true } }).toArray();
  let linked = 0;
  let dropped = 0;
  for (const doc of legacy) {
    const update = { $unset: { gateway: "" } };
    if (doc.gateway && !doc.gatewayId) {
      const g = await Gateway.findOne({ gatewayName: doc.gateway }).lean();
      if (g) {
        update.$set = { gatewayId: g._id };
        linked++;
      } else {
        dropped++; // the old name no longer matches any gateway
      }
    }
    await col.updateOne({ _id: doc._id }, update);
  }
  if (legacy.length) {
    console.log(`🔧 Migrated ${legacy.length} device(s) to gateway IDs (${linked} linked, ${dropped} without a matching gateway)`);
  }
  return { checked: legacy.length, linked, dropped };
}

module.exports = { migrateNodeReferences };

// ── sensor data retention ────────────────────────────────
// days > 0: MongoDB deletes uplinks older than that many days (TTL index on "timestamp").
// days = 0: nothing is deleted (the plain index is used). Runs at every start, so changing the setting is enough.
async function ensureSensorDataRetention(days) {
  const SensorData = require("../models/SensorData");
  const col = SensorData.collection;
  const wanted = days > 0 ? Math.round(days * 24 * 60 * 60) : null;

  let indexes = [];
  try {
    indexes = await col.indexes();
  } catch (err) {
    if (err.codeName !== "NamespaceNotFound" && err.code !== 26) throw err; // no data yet: no indexes
  }
  const current = indexes.find((i) => Object.keys(i.key).length === 1 && i.key.timestamp === 1);

  if (current && (current.expireAfterSeconds ?? null) === wanted) {
    // already as wanted
  } else if (current && wanted !== null && current.expireAfterSeconds !== undefined) {
    await SensorData.db.db.command({ collMod: col.collectionName, index: { keyPattern: { timestamp: 1 }, expireAfterSeconds: wanted } });
  } else {
    if (current) await col.dropIndex(current.name); // a plain index and a TTL index cannot both exist on the same key
    await col.createIndex({ timestamp: 1 }, wanted === null ? {} : { expireAfterSeconds: wanted });
  }

  if (wanted === null) {
    console.log("🗄️  Sensor data is kept forever (set SENSOR_DATA_RETENTION_DAYS in .env to delete old uplinks automatically)");
  } else {
    console.log(`🗄️  Sensor data older than ${days} day(s) is deleted automatically`);
  }
}

module.exports.ensureSensorDataRetention = ensureSensorDataRetention;
