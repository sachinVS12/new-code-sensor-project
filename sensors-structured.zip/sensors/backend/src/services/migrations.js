const Node = require("../models/Node");
const Gateway = require("../models/Gateway");

// Older devices stored the gateway NAME in a "gateway" field. Devices now point to the gateway by ID (gatewayId).
// Runs at every start; it only touches devices that still have the old field.
async function migrateNodeReferences() {
  const col = Node.collection;
  const legacy = await col.find({ gateway: { $exists: true } }).toArray();
  let linked = 0;
  let dropped = 0;
  for (const doc of legacy) {
    const update = { $unset: { gateway: "" } };
    if (doc.gateway && !doc.gatewayId) {
      const g = await Gateway.findOne({ gatewayName: doc.gateway }).lean();
      if (g) {
        update.$set = { gatewayId: g._id };
        linked++;
      } else {
        dropped++; // the old name no longer matches any gateway
      }
    }
    await col.updateOne({ _id: doc._id }, update);
  }
  if (legacy.length) {
    console.log(`🔧 Migrated ${legacy.length} device(s) to gateway IDs (${linked} linked, ${dropped} without a matching gateway)`);
  }
  return { checked: legacy.length, linked, dropped };
}

module.exports = { migrateNodeReferences };
