const mqtt = require("mqtt");
const fs = require("fs");
const path = require("path");
const Node = require("../models/Node");
const { rootDir, MQTT_HOST, MQTT_USERNAME, MQTT_PASSWORD, MQTT_CA_CERT } = require("../config/env");
const { handleMqttMessage } = require("./uplink.service");

let client = null;

// ─── Build connection options ────────────────────────────
const connectOptions = {
  clientId: `chirpstack-sub-${Math.random().toString(16).slice(2, 10)}`,
  username: MQTT_USERNAME?.trim() || undefined,
  password: MQTT_PASSWORD?.trim() || undefined,
  reconnectPeriod: 5000,
  connectTimeout: 10_000,
  clean: true,
  keepalive: 60,
};

// Attach CA if using TLS
if (MQTT_HOST.startsWith("mqtts://")) {
  const caPath = MQTT_CA_CERT || "./certs/ca.pem";
  try {
    connectOptions.ca = fs.readFileSync(path.resolve(rootDir, caPath));
    connectOptions.rejectUnauthorized = true;
    console.log(`🔐 Loaded CA from ${caPath}`);
  } catch (err) {
    console.error(`❌ Cannot read CA file at ${caPath}:`, err.message);
    process.exit(1);
  }
}

// ─── Dynamic MQTT topics ─────────────────────────────────
// A device's topic is generated from its Application ID + DevEUI and saved
// with the device. The broker subscription is added/removed as devices are
// created, edited and deleted - no restart and no .env topic needed.
const buildTopic = (applicationId, devEui) =>
  `application/${applicationId}/device/${devEui}/event/up`;

const subscribedTopics = new Set();

// Besides a device's uplink topic, also follow its downlink status events
// (txack = sent to the radio, ack = confirmed by the device).
const relatedTopics = (topic) =>
  topic.endsWith("/event/up")
    ? [
        topic,
        topic.replace(/\/event\/up$/, "/event/txack"),
        topic.replace(/\/event\/up$/, "/event/ack"),
      ]
    : [topic];

function subscribeTopic(topic) {
  if (!topic) return;
  relatedTopics(topic).forEach((t) => {
    subscribedTopics.add(t);
    if (client && client.connected) {
      client.subscribe(t, { qos: 0 }, (err) => {
        if (err) console.error(`❌ Subscribe failed (${t}):`, err.message);
        else console.log(`📡 Subscribed to: ${t}`);
      });
    }
  });
}

async function unsubscribeTopic(topic, excludeId) {
  if (!topic) return;
  // keep the subscription if another saved device still uses this topic
  const stillUsed = await Node.exists({ mqttTopic: topic, _id: { $ne: excludeId } });
  if (stillUsed) return;
  relatedTopics(topic).forEach((t) => {
    subscribedTopics.delete(t);
    if (client && client.connected) {
      client.unsubscribe(t, (err) => {
        if (err) console.error(`❌ Unsubscribe failed (${t}):`, err.message);
        else console.log(`🔕 Unsubscribed from: ${t}`);
      });
    }
  });
}

function isConnected() {
  return !!client && client.connected;
}

// Publish a message to the broker (rejects if the broker is not connected)
function publish(topic, message) {
  return new Promise((resolve, reject) => {
    if (!isConnected()) return reject(new Error("MQTT broker is not connected"));
    client.publish(topic, message, { qos: 0 }, (err) => (err ? reject(err) : resolve()));
  });
}

function connectMqtt() {
  client = mqtt.connect(MQTT_HOST, connectOptions);

  client.on("connect", () => {
    console.log(`✅ Connected to MQTT: ${MQTT_HOST}`);
    // (Re)subscribe to every saved device topic (subscriptions are lost on reconnect)
    if (subscribedTopics.size) {
      client.subscribe([...subscribedTopics], { qos: 0 }, (err) => {
        if (err) console.error("❌ Subscribe failed:", err.message);
      });
    }
    console.log(`⏳ Subscribed to ${subscribedTopics.size} topic(s), waiting for data...\n`);
  });

  client.on("message", handleMqttMessage);
  client.on("error", (err) => console.error("❌ MQTT error:", err.message));
  client.on("reconnect", () => console.log("🔄 Reconnecting to MQTT..."));
  client.on("offline", () => console.log("⚠️  MQTT offline"));
  client.on("close", () => console.log("🔌 MQTT connection closed"));
  return client;
}

function disconnectMqtt(cb) {
  if (!client) return cb && cb();
  client.end(false, {}, cb);
}

module.exports = {
  buildTopic,
  subscribeTopic,
  unsubscribeTopic,
  isConnected,
  publish,
  connectMqtt,
  disconnectMqtt,
};
