const Gateway = require("../models/Gateway");

// Devices are stored with the ID of their gateway; the API also returns the gateway's current name
// (gatewayName) so the screens can show it. gatewayId is always a string ("" = no gateway).
async function gatewayNames() {
  const list = await Gateway.find({}, "gatewayName").lean();
  return new Map(list.map((g) => [String(g._id), g.gatewayName]));
}

function nodeJson(node, names) {
  const o = typeof node.toObject === "function" ? node.toObject() : { ...node };
  const gid = o.gatewayId ? String(o.gatewayId) : "";
  o.gatewayId = gid;
  o.gatewayName = gid ? names.get(gid) || "" : "";
  o.deviceProfileId = o.deviceProfileId || "";
  return o;
}

async function nodesJson(nodes) {
  const names = await gatewayNames();
  return nodes.map((n) => nodeJson(n, names));
}

module.exports = { nodeJson, nodesJson, gatewayNames };
