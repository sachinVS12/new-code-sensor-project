const SensorData = require("../models/SensorData");
const { deviceNames } = require("./deviceRegistry");
const { handleDownlinkEvent } = require("./downlink.service");
const { broadcastSensorData } = require("./websocket.service");
const {
  isChunkDevice,
  decodeChunkPacket,
  printChunkResult,
  printPartialResult,
  flushIncomplete,
  partialTimeoutMs,
} = require("../decoders/chunkDecoder");
const { decodeRak5146 } = require("../decoders/rak5146Decoder");

// ── Unfinished chunk datasets ───────────────────────────────────────────────
// A dataset that never gets all its chunks is saved as its own row with decodedPayload.kind = "partial"
// (which chunks arrived / are missing). It happens when a new dataset starts first, or when no chunk
// arrives for CHUNK_PARTIAL_TIMEOUT_SECONDS. It is only saved, not broadcast: it has no rssi/snr of its own
// and the live dashboard is for complete datasets and arriving chunks.
const partialTimers = new Map(); // devEui -> timeout

function savePartial(deviceName, devEui, fPort, partial) {
  printPartialResult(deviceName, devEui, partial);
  new SensorData({
    deviceName,
    devEui,
    timestamp: partial.lastChunkAt, // when its last chunk arrived
    fPort,
    decodedPayload: partial,
  })
    .save()
    .then(() => console.log(`💾 Partial dataset saved (${partial.receivedChunks}/${partial.totalChunks} chunks)`))
    .catch((err) => console.error("❌ Error saving partial dataset:", err.message));
}

// after every chunk: (re)start the countdown; a finished dataset stops it
function trackPartialTimeout(deviceName, devEui, fPort, result) {
  if (result.kind === "dataset") {
    clearTimeout(partialTimers.get(devEui));
    partialTimers.delete(devEui);
    return;
  }
  if (result.kind !== "chunk") return;
  const ms = partialTimeoutMs();
  clearTimeout(partialTimers.get(devEui));
  if (ms <= 0) return;
  const timer = setTimeout(() => {
    partialTimers.delete(devEui);
    const partial = flushIncomplete(devEui, "timeout");
    if (partial) savePartial(deviceName, devEui, fPort, partial);
  }, ms);
  timer.unref?.(); // never keeps the process alive
  partialTimers.set(devEui, timer);
}

// Every message received from the MQTT broker (uplinks + downlink txack/ack events)
function handleMqttMessage(receivedTopic, message) {
  try {
    const data = JSON.parse(message.toString());

    // Downlink status events are not uplinks
    if (receivedTopic.endsWith("/event/txack") || receivedTopic.endsWith("/event/ack")) {
      handleDownlinkEvent(receivedTopic, data);
      return;
    }

    const devEui = (data.deviceInfo?.devEui || "").toLowerCase();
    const deviceName = deviceNames[devEui] || "Unknown";
    const appIdFromTopic = receivedTopic.split("/")[1];
    const rx =
      Array.isArray(data.rxInfo) && data.rxInfo.length ? data.rxInfo[0] : null;
    // spreading factor exists only for LoRa. FSK (DR7) has none, and data.dr is a data rate number, not an SF.
    const modulation = data.txInfo?.modulation;
    const spreadingFactor =
      modulation?.lora?.spreadingFactor ?? (modulation?.fsk ? undefined : data.dr ?? undefined);

    console.log("──────────────────────────────────────────");
    console.log(`Topic         : ${receivedTopic}`);
    console.log(`App ID        : ${appIdFromTopic}`);
    console.log(`Device        : ${deviceName}`);
    console.log(`DevEUI        : ${devEui}`);
    console.log(
      `Profile       : ${data.deviceInfo?.deviceProfileName || "N/A"}`,
    );
    console.log(`Received at   : ${data.time || "N/A"}`);
    console.log(`FCnt          : ${data.fCnt ?? "N/A"}`);
    console.log(`FPort         : ${data.fPort ?? "N/A"}`);
    console.log(`Raw payload   : ${data.data || "N/A"}`);

    // Decode payload if FPort 2
    let decodedPayload = null;
    if (data.data && data.fPort != null && isChunkDevice(devEui)) {
      // Chunked-dataset device: 3-byte header + 16-bit or packed 12-bit samples
      decodedPayload = decodeChunkPacket(devEui, data.fPort, data.data);
      // the dataset this chunk replaced, if it was unfinished: saved separately, kept out of this chunk's own row
      const discarded = decodedPayload.discardedPartial;
      delete decodedPayload.discardedPartial;
      printChunkResult(deviceName, devEui, decodedPayload);
      if (discarded) savePartial(deviceName, devEui, data.fPort, discarded);
      trackPartialTimeout(deviceName, devEui, data.fPort, decodedPayload);
    } else if (data.data && data.fPort != null) {
      decodedPayload = decodeRak5146(data.fPort, data.data);
      if (decodedPayload.error) {
        console.log(`Decode error  : ${decodedPayload.error}`);
      } else {
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`📊 PAYLOAD DECODED - ${deviceName} (${devEui})`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`Version       : ${decodedPayload.version}`);
        console.log(`Type          : 0x${decodedPayload.type.toString(16).padStart(2, "0")}`);
        console.log(`Count         : ${decodedPayload.count}`);
        console.log(`Duration      : ${decodedPayload.duration} ms`);
        console.log(`Battery       : ${decodedPayload.batteryV} V (raw ${decodedPayload.batteryRaw})`);
        console.log(`Samples       : ${decodedPayload.sampleCount}`);
        console.log(`Stats         : min=${decodedPayload.min} | max=${decodedPayload.max} | avg=${decodedPayload.avg}`);
        console.log(`All Samples   : [${decodedPayload.samples.join(', ')}]`);
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
      }
    } else if (data.object) {
      console.log(`Decoded object: ${JSON.stringify(data.object)}`);
    }
    if (rx) {
      console.log(`RSSI          : ${rx.rssi} dBm`);
      console.log(`SNR           : ${rx.snr} dB`);
      console.log(`Gateway       : ${rx.gatewayId || "N/A"}`);
      console.log(
        `Frequency     : ${
          rx.frequency ? (rx.frequency / 1e6).toFixed(3) + " MHz" : "N/A"
        }`,
      );
      console.log(`DataRate      : ${rx.dataRate?.modulation || "N/A"}`);
    }
    console.log("──────────────────────────────────────────\n");

    // Save to MongoDB
    const sensorData = new SensorData({
      deviceName,
      devEui,
      timestamp: data.time || new Date(),
      rssi: rx?.rssi,
      snr: rx?.snr,
      fPort: data.fPort,
      data: data.data,
      decodedPayload: decodedPayload,
      gatewayId: rx?.gatewayId,
      frequency: rx?.frequency,
      dataRate: rx?.dataRate?.modulation,
      spreadingFactor,
      fCnt: data.fCnt
    });

    sensorData.save()
      .then(() => {
        console.log("💾 Saved to MongoDB");
      })
      .catch((err) => {
        console.error("❌ Error saving to MongoDB:", err.message);
      });

    // Broadcast to WebSocket clients
    broadcastSensorData({
      deviceName,
      devEui,
      topic: receivedTopic,
      spreadingFactor,
      timestamp: data.time || new Date().toISOString(),
      rssi: rx?.rssi,
      snr: rx?.snr,
      fPort: data.fPort,
      data: data.data,
      decodedPayload: decodedPayload,
    });
  } catch (err) {
    console.error("❌ Message parsing error:", err.message);
  }
}

module.exports = { handleMqttMessage };
