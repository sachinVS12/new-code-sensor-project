const WebSocket = require("ws");
const { ALLOWED_ORIGINS } = require("../config/env");

let wss = null;

const LOOPBACK = new Set(["localhost", "127.0.0.1", "[::1]"]);

// Browsers send an Origin header on a WebSocket connection. Accept: no Origin (not a browser), the same host that
// serves the page, localhost (development), or an origin listed in ALLOWED_ORIGINS. Anything else is another website
// trying to read the live data through the visitor's browser.
function isAllowedOrigin(origin, host, allowed = ALLOWED_ORIGINS) {
  if (!origin) return true;
  let url;
  try {
    url = new URL(origin);
  } catch {
    return false;
  }
  if (allowed.includes(origin) || allowed.includes(url.origin)) return true;
  if (LOOPBACK.has(url.hostname)) return true;
  return !!host && url.host.toLowerCase() === String(host).toLowerCase();
}

// Attach the WebSocket server to the HTTP server (browser connects to /socket)
function initWebSocket(server) {
  wss = new WebSocket.Server({
    server,
    path: "/socket",
    verifyClient: (info) => isAllowedOrigin(info.origin, info.req.headers.host),
  });
  console.log("🌐 WebSocket server initialized");
  return wss;
}

function sendToAll(message) {
  if (!wss) return;
  wss.clients.forEach((c) => {
    if (c.readyState === WebSocket.OPEN) c.send(message);
  });
}

// Broadcast sensor data to all connected WebSocket clients
function broadcastSensorData(data) {
  const clientCount = wss ? wss.clients.size : 0;
  console.log(`📡 Broadcasting uplink of ${data.devEui || "device"} to ${clientCount} WebSocket clients`); // summary only, never the payload
  sendToAll(JSON.stringify(data));
}

// Broadcast console logs to all connected WebSocket clients
function broadcastLog(message) {
  sendToAll(JSON.stringify({ type: "log", message }));
}

// Push a downlink change (created / updated / deleted) with the full record to every open page,
// so the Task page shows new Queued / Transmitted / Acknowledged times at once without reloading
function broadcastDownlinkUpdate(downlink, event = "updated") {
  sendToAll(JSON.stringify({ type: "downlink", event, downlink }));
}

// Make every console.log also show up in the browser log panel
function hookConsoleToWebSocket() {
  const originalLog = console.log;
  console.log = function (...args) {
    originalLog.apply(console, args);
    const message = args.map((arg) => (typeof arg === "object" ? JSON.stringify(arg) : String(arg))).join(" ");
    broadcastLog(message);
  };
}

module.exports = {
  isAllowedOrigin,
  initWebSocket,
  hookConsoleToWebSocket,
  broadcastSensorData,
  broadcastLog,
  broadcastDownlinkUpdate,
};
