const EUI_REGEX = /^[0-9a-f]{16}$/;
const normEui = (v) => String(v || "").toLowerCase().replace(/[^0-9a-f]/g, "");

module.exports = { EUI_REGEX, normEui };
