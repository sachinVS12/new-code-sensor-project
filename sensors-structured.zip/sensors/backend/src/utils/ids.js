// ID formats used by the API.
//   MongoDB ObjectId (24 hex)  -> devices (nodes), gateways, downlinks   (/api/nodes/:id, /api/gateways/:id, /api/downlinks/:id)
//   ChirpStack UUID            -> applications, device profiles          (/api/applications/:id, /api/device-profiles/:id)
//   DevEUI (16 hex)            -> the ID of a device on the LoRaWAN side (?devEui=...)
const OBJECT_ID = /^[0-9a-f]{24}$/i;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// router.param("id", ...) handlers: a malformed ID is a 400, never a 500 from the database
const validateObjectId = (req, res, next, id) =>
  OBJECT_ID.test(id) ? next() : res.status(400).json({ error: "Invalid id (expected a 24 character hex id)" });

const validateUuid = (req, res, next, id) =>
  UUID.test(id) ? next() : res.status(400).json({ error: "Invalid id (expected a ChirpStack UUID)" });

module.exports = { OBJECT_ID, UUID, validateObjectId, validateUuid };
