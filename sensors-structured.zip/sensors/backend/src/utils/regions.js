// Regions that can be chosen when creating a gateway (keep in sync with frontend/src/utils/regions.js).
// The chosen region is saved on the gateway here and in ChirpStack as the gateway tag "region_id".
const REGIONS = ["EU868", "EU433", "US915", "AU915", "AS923", "IN865", "KR920", "CN470", "RU864"];

module.exports = { REGIONS };
