const Module = require('module'); const assert = require('assert');
const calls = [];
const nodes = [
  { _id: 'n1', devEui: 'AABB', mqttTopic: 't1', applicationId: 'APP-1' },
  { _id: 'n2', devEui: 'CCDD', mqttTopic: 't2', applicationId: 'app-2' },
];
const stubs = {
  '../models/Node': { find: async () => nodes, findByIdAndDelete: async (id) => calls.push('node:' + id) },
  '../models/FeedData': { deleteMany: async (q) => calls.push('feed:' + q.devEui) },
  '../services/deviceRegistry': { deviceNames: { aabb: 'x', ccdd: 'y' } },
  '../services/mqtt.service': { unsubscribeTopic: async (t) => calls.push('unsub:' + t) },
  '../services/chirpstack.service': {
    isEnabled: () => true,
    deleteApplication: async (id) => { calls.push('cs:' + id); if (id === 'gone') { const e = new Error('nf'); e.notFound = true; throw e; } if (id === 'boom') throw new Error('down'); },
    updateApplication: async () => {},
  },
};
const orig = Module._load;
Module._load = function (req, ...rest) { return stubs[req] || orig.call(this, req, ...rest); };
const c = require(require('path').join(__dirname, '..', 'src', 'controllers', 'application.controller.js'));
const res = () => { const r = { code: 200 }; r.status = (n) => { r.code = n; return r; }; r.json = (b) => { r.body = b; return r; }; return r; };
(async () => {
  let r = res(); await c.deleteApplication({ params: { id: 'app-1' } }, r);
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.devicesRemoved, 1);
  assert.deepStrictEqual(calls, ['cs:app-1', 'node:n1', 'unsub:t1', 'feed:AABB']); assert.ok(!('aabb' in stubs['../services/deviceRegistry'].deviceNames)); assert.ok('ccdd' in stubs['../services/deviceRegistry'].deviceNames);
  calls.length = 0; r = res(); await c.deleteApplication({ params: { id: 'gone' } }, r); assert.strictEqual(r.code, 200); assert.strictEqual(r.body.devicesRemoved, 0);
  calls.length = 0; r = res(); await c.deleteApplication({ params: { id: 'boom' } }, r); assert.strictEqual(r.code, 502); assert.deepStrictEqual(calls, ['cs:boom']); // nothing local touched
  r = res(); await c.updateApplication({ params: { id: 'a' }, body: { name: '  ' } }, r); assert.strictEqual(r.code, 400);
  r = res(); await c.updateApplication({ params: { id: 'a' }, body: { name: 'ok' } }, r); assert.strictEqual(r.code, 200);
  console.log('application controller: all checks passed');
})().catch(e => { console.error(e); process.exit(1); });
