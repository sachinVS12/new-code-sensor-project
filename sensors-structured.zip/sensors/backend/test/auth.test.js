// Login checks with stubs (no database or browser): node test/auth.test.js
process.env.MQTT_HOST = 'mqtt://x'; process.env.MONGODB_URI = 'mongodb://x';
process.env.ADMIN_USERNAME = 'admin'; process.env.ADMIN_PASSWORD = 'unused-in-this-test';
const Module = require('module'); const assert = require('assert');
const { createAuth, hashPassword, verifyHash, parseCookies, COOKIE_NAME } = require('../src/services/auth.service.js');

const hash = hashPassword('correct horse battery');
const auth = createAuth({ username: 'admin', passwordHash: hash, secret: 'test-secret', sessionHours: 1 });
const stub = { auth, AUTH_DISABLED: false };
const orig = Module._load;
Module._load = function (req, ...rest) {
  if (req === '../services/auth.instance' || req === './auth.instance') return stub;
  if (req === 'ws') return { Server: function () {}, OPEN: 1 };
  if (req === 'dotenv') return { config() {} };
  return orig.call(this, req, ...rest);
};
const ctrl = require('../src/controllers/auth.controller.js');
const { createRequireAuth, originGuard } = require('../src/middleware/auth.js');
const { isAllowedOrigin } = require('../src/services/websocket.service.js');

const mkRes = () => { const r = { code: 200, headers: {} }; r.setHeader = (k, v) => { r.headers[k] = v; }; r.status = (n) => { r.code = n; return r; }; r.json = (b) => { r.body = b; return r; }; return r; };
const warn = console.warn; console.warn = () => {};

// password hashes
assert.match(hash, /^scrypt\$16384\$8\$1\$/);
assert.ok(verifyHash('correct horse battery', hash)); assert.ok(!verifyHash('wrong', hash)); assert.ok(!verifyHash('x', 'not-a-hash'));
assert.notStrictEqual(hashPassword('same'), hashPassword('same'), 'every hash has its own salt');

// credentials (hash and plain)
assert.ok(auth.checkCredentials('admin', 'correct horse battery'));
assert.ok(!auth.checkCredentials('admin', 'nope')); assert.ok(!auth.checkCredentials('root', 'correct horse battery')); assert.ok(!auth.checkCredentials(undefined, undefined));
const plain = createAuth({ username: 'u', password: 'pw12345678', secret: 's' });
assert.ok(plain.checkCredentials('u', 'pw12345678')); assert.ok(!plain.checkCredentials('u', 'pw1234567'));
assert.ok(!createAuth({ username: 'u', secret: 's' }).checkCredentials('u', ''), 'no password configured = nobody gets in');

// tokens
const now = 1_000_000;
const tok = auth.createToken('admin', now);
assert.deepStrictEqual(auth.verifyToken(tok, now + 1000), { username: 'admin' });
assert.strictEqual(auth.verifyToken(tok, now + 61 * 60 * 1000), null, 'expired after SESSION_HOURS');
const [p, s] = tok.split('.');
assert.strictEqual(auth.verifyToken(`${Buffer.from(JSON.stringify({ u: 'root', exp: now + 1e9 })).toString('base64url')}.${s}`, now), null, 'changed payload');
assert.strictEqual(auth.verifyToken(`${p}.${s.slice(0, -2)}xx`, now), null, 'changed signature');
assert.strictEqual(createAuth({ username: 'admin', passwordHash: hash, secret: 'other' }).verifyToken(tok, now), null, 'other secret');
for (const bad of [undefined, '', 'abc', 'a.b.c', null, 123]) assert.strictEqual(auth.verifyToken(bad, now), null);

// cookies
assert.deepStrictEqual(parseCookies('a=1; b=two%20words; broken'), { a: '1', b: 'two words' });
const c = auth.sessionCookie(tok, { secure: true });
assert.match(c, /HttpOnly/); assert.match(c, /SameSite=Strict/); assert.match(c, /Secure/); assert.match(c, /Max-Age=3600/);
assert.ok(!/Secure/.test(auth.sessionCookie(tok)));
assert.match(auth.clearCookie(), /Max-Age=0/);

// login endpoint
let r = mkRes(); ctrl.login({ body: {}, headers: {} }, r); assert.strictEqual(r.code, 400);
r = mkRes(); ctrl.login({ body: { username: 'admin', password: 'wrong' }, headers: {}, ip: '1.2.3.4' }, r);
assert.strictEqual(r.code, 401); assert.deepStrictEqual(r.body, { error: 'Invalid username or password' }); assert.ok(!r.headers['Set-Cookie']);
r = mkRes(); ctrl.login({ body: { username: 'admin', password: 'correct horse battery' }, headers: { 'x-forwarded-proto': 'https' }, ip: '1.2.3.4' }, r);
assert.strictEqual(r.code, 200); assert.deepStrictEqual(r.body, { user: { username: 'admin' } }); assert.match(r.headers['Set-Cookie'], /Secure/);
const cookie = r.headers['Set-Cookie'].split(';')[0];
assert.ok(cookie.startsWith(COOKIE_NAME + '='));

// me / logout / requireAuth with that cookie
r = mkRes(); ctrl.me({ headers: { cookie } }, r); assert.strictEqual(r.code, 200); assert.strictEqual(r.body.user.username, 'admin');
r = mkRes(); ctrl.me({ headers: {} }, r); assert.strictEqual(r.code, 401);
r = mkRes(); ctrl.logout({ headers: {} }, r); assert.match(r.headers['Set-Cookie'], /Max-Age=0/);
const requireAuth = createRequireAuth(auth);
let passed = false; const req = { headers: { cookie } }; requireAuth(req, mkRes(), () => { passed = true; }); assert.ok(passed); assert.strictEqual(req.user.username, 'admin');
passed = false; r = mkRes(); requireAuth({ headers: {} }, r, () => { passed = true; }); assert.ok(!passed); assert.strictEqual(r.code, 401);
passed = false; r = mkRes(); requireAuth({ headers: { cookie: COOKIE_NAME + '=forged.value' } }, r, () => { passed = true; }); assert.ok(!passed); assert.strictEqual(r.code, 401);
passed = false; createRequireAuth(auth, { authDisabled: true })({ headers: {} }, mkRes(), () => { passed = true; }); assert.ok(passed, 'AUTH_DISABLED');

// cross-site protection for changes
const guard = (method, origin) => { let ok = false; const res = mkRes(); originGuard({ method, headers: { origin, host: 'dash.example.com' } }, res, () => { ok = true; }); return { ok, code: res.code }; };
assert.ok(guard('POST', 'https://dash.example.com').ok); assert.ok(guard('POST', undefined).ok); assert.ok(guard('DELETE', 'http://localhost:5173').ok);
assert.deepStrictEqual(guard('POST', 'https://evil.example'), { ok: false, code: 403 });
assert.ok(guard('GET', 'https://evil.example').ok, 'reading is not a change');
assert.ok(isAllowedOrigin('https://dash.example.com', 'dash.example.com', []));

console.warn = warn;
console.log('login: all checks passed');
