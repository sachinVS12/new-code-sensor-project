const { decodeChunkPacket, isChunkDevice } = require('../src/decoders/chunkDecoder.js');
const assert = require('assert');

const pack = (samples, layout) => {
  const out = [];
  for (let i = 0; i < samples.length; i += 2) {
    const a = samples[i], b = samples[i + 1];
    if (layout === 'msb') out.push(a >> 4, ((a & 0xf) << 4) | (b >> 8), b & 0xff);
    else out.push(a & 0xff, ((a >> 8) & 0xf) | ((b & 0xf) << 4), (b >> 4) & 0xff);
  }
  return Buffer.from(out);
};
const send = (dev, type, total, idx, data, port = 2) =>
  decodeChunkPacket(dev, port, Buffer.concat([Buffer.from([type, total, idx]), data]).toString('base64'));

const original = Array.from({ length: 4096 }, (_, i) => Math.round(2048 + 2000 * Math.sin(i / 20)) & 0xfff);

for (const layout of ['lsb', 'msb']) {
  process.env.CHUNK_PACK12_LAYOUT = layout;
  for (const [chunkBytes, label] of [[192, 'batch 192 B'], [96, 'normal 96 B']]) {
    const bytes = pack(original, layout);
    const total = bytes.length / chunkBytes;
    let last;
    for (let c = 0; c < total; c++) last = send('dev' + layout + chunkBytes, 3, total, c, bytes.subarray(c * chunkBytes, (c + 1) * chunkBytes));
    assert.strictEqual(last.kind, 'dataset', `${layout} ${label}: dataset not complete`);
    assert.deepStrictEqual(last.samples, original, `${layout} ${label}: samples differ`);
    assert.strictEqual(last.sampleCount, 4096);
    assert.strictEqual(last.warning, undefined);
    assert.strictEqual(last.datasetKind, 'packed');
    console.log(`ok  pack12 ${layout} ${label}: ${total} chunks -> 4096 samples`);
  }
}

// the firmware's own Pack12: out[0] = a >> 4; out[1] = ((a & 0x0F) << 4) | (b >> 8); out[2] = b & 0xFF  -> default layout must decode it exactly
{
  delete process.env.CHUNK_PACK12_LAYOUT;
  const firmwarePack12 = (samples) => { const out = []; for (let i = 0; i < samples.length; i += 2) { const a = samples[i], b = samples[i + 1]; out.push(a >> 4, ((a & 0x0F) << 4) | (b >> 8), b & 0xFF); } return Buffer.from(out); };
  const bytes = firmwarePack12(original); const cb = 192; const total = bytes.length / cb; let last;
  for (let c = 0; c < total; c++) last = send('devfw', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb));
  assert.strictEqual(last.kind, 'dataset'); assert.deepStrictEqual(last.samples, original, 'default layout decodes the firmware packing exactly');
  assert.strictEqual(last.packLayout, 'msb');
  process.env.CHUNK_PACK12_LAYOUT = 'lsb';   // the old default would have given wrong values
  let wrong; for (let c = 0; c < total; c++) wrong = send('devfw-lsb', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb));
  assert.notDeepStrictEqual(wrong.samples, original);
  process.env.CHUNK_PACK12_LAYOUT = 'lsb';
  console.log('ok  firmware Pack12 decodes exactly with the default (msb); lsb would not');
}

// out-of-order + duplicate chunk (a resend), 16 chunks of 384 bytes
process.env.CHUNK_PACK12_LAYOUT = 'lsb';
{
  const bytes = pack(original, 'lsb'); const cb = 384; const total = bytes.length / cb;
  const order = [...Array(total).keys()].reverse();
  let last; let dup;
  order.forEach((c, n) => { last = send('devdup', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb)); if (n === 2) dup = send('devdup', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb)); });
  assert.strictEqual(dup.duplicate, true);
  assert.strictEqual(last.kind, 'dataset');
  assert.deepStrictEqual(last.samples, original);
  console.log('ok  out-of-order + duplicate chunk');
}

// old formats still work
{
  const s16 = Buffer.alloc(8); [1, 2, 3, 4000].forEach((v, i) => s16.writeUInt16LE(v, i * 2));
  const r = send('dev16', 0, 1, 0, s16);
  assert.deepStrictEqual(r.samples, [1, 2, 3, 4000]); assert.strictEqual(r.datasetKind, 'single');
  const r2 = send('dev16b', 1, 1, 0, s16); assert.strictEqual(r2.datasetKind, 'batch');
  const pr = send('devp', 2, 1, 0, Buffer.from([5])); assert.strictEqual(pr.kind, 'probe'); assert.strictEqual(pr.dataRate, 5);
  console.log('ok  type 0 / 1 / probe unchanged');
}

// errors
assert.match(send('e1', 3, 4, 0, Buffer.from([1, 2, 3, 4])).error, /multiple of 3/);
assert.match(send('e2', 0, 1, 0, Buffer.from([1, 2, 3])).error, /16-bit/);
assert.match(send('e3', 9, 1, 0, Buffer.from([1, 2])).error, /Unknown packet type 9/);
assert.match(send('e4', 3, 4, 4, Buffer.from([1, 2, 3])).error, /outside/);
assert.match(send('e5', 3, 1, 0, Buffer.from([1, 2, 3]), 7).error, /Unhandled FPort 7/);
// short dataset warns
{ const r = send('e6', 3, 1, 0, pack([1, 2, 3, 4], 'lsb')); assert.strictEqual(r.kind, 'dataset'); assert.match(r.warning, /expected 4096/); }
console.log('ok  error cases + short-dataset warning');

// settings
process.env.CHUNK_FPORT = '3'; assert.ok(!send('p1', 3, 1, 0, pack([1, 2], 'lsb'), 2).kind); assert.strictEqual(send('p1', 3, 1, 0, pack([1, 2], 'lsb'), 3).kind, 'dataset'); delete process.env.CHUNK_FPORT;
process.env.CHUNK_DEVICE_EUIS = 'AABBCCDDEEFF0011, 1122334455667788';
assert.ok(isChunkDevice('aabbccddeeff0011')); assert.ok(isChunkDevice('50c6c10d19c40cce')); assert.ok(!isChunkDevice('0000000000000000'));
console.log('ok  CHUNK_FPORT and CHUNK_DEVICE_EUIS');
