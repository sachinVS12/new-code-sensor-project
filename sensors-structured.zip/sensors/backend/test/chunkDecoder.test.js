const { decodeChunkPacket, isChunkDevice, flushIncomplete, partialTimeoutMs } = require('../src/decoders/chunkDecoder.js');
const assert = require('assert');

const pack = (samples, layout) => {
  const out = [];
  for (let i = 0; i < samples.length; i += 2) {
    const a = samples[i], b = samples[i + 1];
    if (layout === 'msb') out.push(a >> 4, ((a & 0xf) << 4) | (b >> 8), b & 0xff);
    else out.push(a & 0xff, ((a >> 8) & 0xf) | ((b & 0xf) << 4), (b >> 4) & 0xff);
  }
  return Buffer.from(out);
};
const send = (dev, type, total, idx, data, port = 2) =>
  decodeChunkPacket(dev, port, Buffer.concat([Buffer.from([type, total, idx]), data]).toString('base64'));

const original = Array.from({ length: 4096 }, (_, i) => Math.round(2048 + 2000 * Math.sin(i / 20)) & 0xfff);

for (const layout of ['lsb', 'msb']) {
  process.env.CHUNK_PACK12_LAYOUT = layout;
  for (const [chunkBytes, label] of [[192, 'batch 192 B'], [96, 'normal 96 B']]) {
    const bytes = pack(original, layout);
    const total = bytes.length / chunkBytes;
    let last;
    for (let c = 0; c < total; c++) last = send('dev' + layout + chunkBytes, 3, total, c, bytes.subarray(c * chunkBytes, (c + 1) * chunkBytes));
    assert.strictEqual(last.kind, 'dataset', `${layout} ${label}: dataset not complete`);
    assert.deepStrictEqual(last.samples, original, `${layout} ${label}: samples differ`);
    assert.strictEqual(last.sampleCount, 4096);
    assert.strictEqual(last.warning, undefined);
    assert.strictEqual(last.datasetKind, 'packed');
    console.log(`ok  pack12 ${layout} ${label}: ${total} chunks -> 4096 samples`);
  }
}

// the firmware's own Pack12: out[0] = a >> 4; out[1] = ((a & 0x0F) << 4) | (b >> 8); out[2] = b & 0xFF  -> default layout must decode it exactly
{
  delete process.env.CHUNK_PACK12_LAYOUT;
  const firmwarePack12 = (samples) => { const out = []; for (let i = 0; i < samples.length; i += 2) { const a = samples[i], b = samples[i + 1]; out.push(a >> 4, ((a & 0x0F) << 4) | (b >> 8), b & 0xFF); } return Buffer.from(out); };
  const bytes = firmwarePack12(original); const cb = 192; const total = bytes.length / cb; let last;
  for (let c = 0; c < total; c++) last = send('devfw', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb));
  assert.strictEqual(last.kind, 'dataset'); assert.deepStrictEqual(last.samples, original, 'default layout decodes the firmware packing exactly');
  assert.strictEqual(last.packLayout, 'msb');
  process.env.CHUNK_PACK12_LAYOUT = 'lsb';   // the old default would have given wrong values
  let wrong; for (let c = 0; c < total; c++) wrong = send('devfw-lsb', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb));
  assert.notDeepStrictEqual(wrong.samples, original);
  process.env.CHUNK_PACK12_LAYOUT = 'lsb';
  console.log('ok  firmware Pack12 decodes exactly with the default (msb); lsb would not');
}

// out-of-order + duplicate chunk (a resend), 16 chunks of 384 bytes
process.env.CHUNK_PACK12_LAYOUT = 'lsb';
{
  const bytes = pack(original, 'lsb'); const cb = 384; const total = bytes.length / cb;
  const order = [...Array(total).keys()].reverse();
  let last; let dup;
  order.forEach((c, n) => { last = send('devdup', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb)); if (n === 2) dup = send('devdup', 3, total, c, bytes.subarray(c * cb, (c + 1) * cb)); });
  assert.strictEqual(dup.duplicate, true);
  assert.strictEqual(last.kind, 'dataset');
  assert.deepStrictEqual(last.samples, original);
  console.log('ok  out-of-order + duplicate chunk');
}

// old formats still work
{
  const s16 = Buffer.alloc(8); [1, 2, 3, 4000].forEach((v, i) => s16.writeUInt16LE(v, i * 2));
  const r = send('dev16', 0, 1, 0, s16);
  assert.deepStrictEqual(r.samples, [1, 2, 3, 4000]); assert.strictEqual(r.datasetKind, 'single');
  const r2 = send('dev16b', 1, 1, 0, s16); assert.strictEqual(r2.datasetKind, 'batch');
  const pr = send('devp', 2, 1, 0, Buffer.from([5])); assert.strictEqual(pr.kind, 'probe'); assert.strictEqual(pr.dataRate, 5);
  console.log('ok  type 0 / 1 / probe unchanged');
}

// errors
assert.match(send('e1', 3, 4, 0, Buffer.from([1, 2, 3, 4])).error, /multiple of 3/);
assert.match(send('e2', 0, 1, 0, Buffer.from([1, 2, 3])).error, /16-bit/);
assert.match(send('e3', 9, 1, 0, Buffer.from([1, 2])).error, /Unknown packet type 9/);
assert.match(send('e4', 3, 4, 4, Buffer.from([1, 2, 3])).error, /outside/);
assert.match(send('e5', 3, 1, 0, Buffer.from([1, 2, 3]), 7).error, /Unhandled FPort 7/);
// short dataset warns
{ const r = send('e6', 3, 1, 0, pack([1, 2, 3, 4], 'lsb')); assert.strictEqual(r.kind, 'dataset'); assert.match(r.warning, /expected 4096/); }
console.log('ok  error cases + short-dataset warning');

// unfinished datasets are kept as "partial" (38-chunk batch mode, 35 of 38 chunks arrive)
{
  const chunkData = (c) => { const b = Buffer.alloc(8); for (let k = 0; k < 4; k++) b.writeUInt16LE(c * 10 + k, k * 2); return b; }; // 4 samples per chunk
  const lost = [5, 17, 30];
  let r;
  for (let c = 0; c < 38; c++) { if (lost.includes(c)) continue; r = send('devpart', 1, 38, c, chunkData(c)); assert.strictEqual(r.kind, 'chunk'); }
  assert.strictEqual(r.receivedChunks, 35);
  assert.strictEqual(r.discardedPartial, null);
  // the next dataset starts (chunk 0): the unfinished one comes back as a partial
  const next = send('devpart', 1, 38, 0, chunkData(0));
  assert.strictEqual(next.kind, 'chunk');
  assert.strictEqual(next.previousIncomplete, true);
  assert.strictEqual(next.previousMissing, 3);
  const p = next.discardedPartial;
  assert.strictEqual(p.kind, 'partial'); assert.strictEqual(p.partial, true); assert.strictEqual(p.reason, 'new-dataset');
  assert.deepStrictEqual(p.missingChunks, lost);
  assert.strictEqual(p.receivedChunks, 35); assert.strictEqual(p.totalChunks, 38); assert.strictEqual(p.receivedChunkList.length, 35);
  assert.strictEqual(p.sampleCount, 140); assert.strictEqual(p.partialSamples.length, 140);
  assert.strictEqual(p.stats.min, 0); assert.strictEqual(p.stats.max, 373);
  assert.strictEqual(p.datasetKind, 'batch'); assert.strictEqual(p.sampleBits, 16);
  // must never look like a complete dataset to the dashboard
  assert.strictEqual(p.samples, undefined); assert.strictEqual(p.avg, undefined); assert.strictEqual(p.min, undefined);
  // the new dataset still completes normally
  let done; for (let c = 1; c < 38; c++) done = send('devpart', 1, 38, c, chunkData(c));
  assert.strictEqual(done.kind, 'dataset'); assert.strictEqual(done.sampleCount, 152); assert.strictEqual(done.discardedPartial, null);
  console.log('ok  35 of 38 chunks -> partial (3 missing) when the next dataset starts');
}

// timeout flush: partial comes out once, the session is closed, a late chunk starts a new dataset
{
  const four = Buffer.from([1, 0, 2, 0]);
  for (const c of [0, 1, 2]) send('devto', 0, 5, c, four);
  const p = flushIncomplete('devto', 'timeout');
  assert.strictEqual(p.reason, 'timeout'); assert.deepStrictEqual(p.missingChunks, [3, 4]); assert.strictEqual(p.receivedChunks, 3);
  assert.strictEqual(flushIncomplete('devto', 'timeout'), null, 'nothing left to flush');
  const late = send('devto', 0, 5, 3, four);
  assert.strictEqual(late.receivedChunks, 1); assert.strictEqual(late.previousIncomplete, false);
  assert.strictEqual(flushIncomplete('nobody', 'timeout'), null);
  // a complete dataset is never flushed
  send('devfull', 0, 1, 0, four); assert.strictEqual(flushIncomplete('devfull', 'timeout'), null);
  console.log('ok  timeout flush');
}
{
  delete process.env.CHUNK_PARTIAL_TIMEOUT_SECONDS; assert.strictEqual(partialTimeoutMs(), 120000);
  process.env.CHUNK_PARTIAL_TIMEOUT_SECONDS = '0'; assert.strictEqual(partialTimeoutMs(), 0);
  process.env.CHUNK_PARTIAL_TIMEOUT_SECONDS = '30'; assert.strictEqual(partialTimeoutMs(), 30000);
  process.env.CHUNK_PARTIAL_TIMEOUT_SECONDS = 'abc'; assert.strictEqual(partialTimeoutMs(), 120000);
  delete process.env.CHUNK_PARTIAL_TIMEOUT_SECONDS;
  console.log('ok  CHUNK_PARTIAL_TIMEOUT_SECONDS');
}

// a finished dataset lists its chunks (index, sample count, arrival time) so a UI / Excel file can show them and count them
{
  const mk = (c, vals) => { const b = Buffer.alloc(vals.length * 2); vals.forEach((v, k) => b.writeUInt16LE(v, k * 2)); return b; };
  // 5 chunks of different sizes, arriving out of order, chunk 3 sent twice (the resend replaces it)
  const parts = [[1, 2], [3, 4, 5], [6], [7, 8], [9, 10, 11]];
  let r;
  for (const c of [2, 0, 4, 3, 3, 1]) r = send('devchunks', 1, 5, c, mk(c, parts[c]));
  assert.strictEqual(r.kind, 'dataset');
  assert.deepStrictEqual(r.samples, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 'chunks are joined in chunk order');
  assert.strictEqual(r.chunkCount, 5);
  assert.strictEqual(r.chunkCount, r.totalChunks, 'total chunks = the dataset header total');
  assert.deepStrictEqual(r.chunks.map((c) => [c.index, c.sampleCount]), [[0, 2], [1, 3], [2, 1], [3, 2], [4, 3]]);
  assert.strictEqual(r.chunks.reduce((n, c) => n + c.sampleCount, 0), r.sampleCount, 'chunk sample counts add up to the dataset');
  for (const c of r.chunks) assert.ok(!Number.isNaN(Date.parse(c.receivedAt)), 'every chunk has an arrival time');
  assert.strictEqual(r.duplicate, false);

  // the same through a 29-chunk packed dataset: 29 chunks, 4096 samples
  const N = 4096, samples = Array.from({ length: N }, (_, i) => 1470 + (i % 1291));
  const out = []; for (let i = 0; i < N; i += 2) { const a = samples[i], b = samples[i + 1]; out.push(a >> 4, ((a & 15) << 4) | (b >> 8), b & 255); }
  const buf = Buffer.from(out); const cb = 213; const total = Math.ceil(buf.length / cb);
  for (let c = 0; c < total; c++) r = send('devp29', 3, total, c, buf.subarray(c * cb, (c + 1) * cb));
  assert.strictEqual(total, 29); assert.strictEqual(r.chunkCount, 29); assert.strictEqual(r.chunks.length, 29);
  assert.strictEqual(r.chunks.reduce((n, c) => n + c.sampleCount, 0), 4096);
  assert.strictEqual(r.chunks[28].sampleCount, (buf.length - 28 * cb) / 3 * 2, 'the last chunk is the short one');
  // an unfinished dataset reports the chunks it did get
  send('devpc', 1, 4, 0, mk(0, [1])); send('devpc', 1, 4, 2, mk(2, [3, 3]));
  const part = flushIncomplete('devpc', 'timeout');
  assert.deepStrictEqual(part.chunks.map((c) => [c.index, c.sampleCount]), [[0, 1], [2, 2]]);
  console.log('ok  finished dataset lists its chunks (29-chunk packed: 29 chunks, 4096 samples)');
}

// settings
process.env.CHUNK_FPORT = '3'; assert.ok(!send('p1', 3, 1, 0, pack([1, 2], 'lsb'), 2).kind); assert.strictEqual(send('p1', 3, 1, 0, pack([1, 2], 'lsb'), 3).kind, 'dataset'); delete process.env.CHUNK_FPORT;
process.env.CHUNK_DEVICE_EUIS = 'AABBCCDDEEFF0011, 1122334455667788';
assert.ok(isChunkDevice('aabbccddeeff0011')); assert.ok(isChunkDevice('50c6c10d19c40cce')); assert.ok(!isChunkDevice('0000000000000000'));
console.log('ok  CHUNK_FPORT and CHUNK_DEVICE_EUIS');
