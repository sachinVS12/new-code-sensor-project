// Checks the ID rules of the API with stubs (no database or ChirpStack needed): node run: node test/ids.test.js
const Module = require('module'); const assert = require('assert');

const GW_ID = 'a'.repeat(24);
const state = { nodes: [], cs: true, csApps: new Set(['11111111-1111-1111-1111-111111111111']), csProfiles: new Set(['22222222-2222-2222-2222-222222222222']), created: [], gatewayUpdates: [] };
const nodeDoc = (o) => ({ ...o, _id: o._id || 'b'.repeat(24), toObject() { return { ...this, toObject: undefined }; } });
const stubs = {
  '../models/Node': {
    findOne: async (q) => (q.$or ? state.nodes.find((n) => (!q._id || String(n._id) !== String(q._id.$ne)) && q.$or.some((c) => Object.entries(c).every(([k, v]) => n[k] === v))) || null : null),
    findById: async (id) => state.nodes.find((n) => String(n._id) === String(id)) || null,
    find: async () => state.nodes,
    findByIdAndUpdate: async (id, u) => { const n = state.nodes.find((x) => String(x._id) === String(id)); Object.assign(n, u); return n; },
    updateMany: async (q, u) => { state.gatewayUpdates.push([q, u]); return { modifiedCount: 2 }; },
    // eslint-disable-next-line
    __proto__: null,
  },
  '../models/Gateway': {
    findById: (id) => ({ lean: async () => (String(id) === GW_ID ? { _id: id, gatewayName: 'gw-1' } : null) }),
    find: () => ({ lean: async () => [{ _id: GW_ID, gatewayName: 'gw-1' }] }),
    findByIdAndDelete: async () => ({ _id: GW_ID, gatewayEui: 'aabbccddeeff0011' }),
  },
  '../models/FeedData': { deleteMany: async () => {} },
  '../services/deviceRegistry': { deviceNames: {} },
  '../services/mqtt.service': { buildTopic: (a, e) => `application/${a}/device/${e}/event/up`, subscribeTopic() {}, unsubscribeTopic: async () => {} },
  '../services/chirpstack.service': {
    isEnabled: () => state.cs,
    defaultDeviceProfileId: () => '22222222-2222-2222-2222-222222222222',
    findApplication: async (id) => (state.csApps.has(id) ? { id } : null),
    findDeviceProfile: async (id) => (state.csProfiles.has(id) ? { id } : null),
    createDevice: async (a) => { state.created.push(a); return { created: true }; },
    updateDevice: async () => ({ updated: true }),
    replaceDevice: async () => ({ updated: true }),
    deleteDevice: async () => {},
    deleteGateway: async () => {},
  },
};
const orig = Module._load;
Module._load = function (req, ...rest) { return stubs[req] || orig.call(this, req, ...rest); };
// make `new Node(...)` work for create
stubs['../models/Node'] = Object.assign(function Node(data) { Object.assign(this, data); this._id = 'c'.repeat(24); this.save = async () => { state.nodes.push(nodeDoc(this)); }; this.toObject = function () { const { save, toObject, ...rest } = this; return rest; }; }, stubs['../models/Node']);

const nodes = require('../src/controllers/node.controller.js');
const gateways = require('../src/controllers/gateway.controller.js');
const { validateObjectId, validateUuid } = require('../src/utils/ids.js');
const res = () => { const r = { code: 200 }; r.status = (n) => { r.code = n; return r; }; r.json = (b) => { r.body = b; return r; }; return r; };
const body = (o) => ({ deviceName: 'dev1', devEui: '0011223344556677', applicationId: '11111111-1111-1111-1111-111111111111', ...o });

(async () => {
  // ID format middleware
  let nexted = false; let r = res(); validateObjectId({}, r, () => { nexted = true; }, 'xyz'); assert.strictEqual(r.code, 400); assert.ok(!nexted);
  validateObjectId({}, res(), () => { nexted = true; }, GW_ID); assert.ok(nexted);
  r = res(); validateUuid({}, r, () => {}, 'not-a-uuid'); assert.strictEqual(r.code, 400);
  nexted = false; validateUuid({}, res(), () => { nexted = true; }, '11111111-1111-1111-1111-111111111111'); assert.ok(nexted);

  // create: gateway by ID, profile defaulted and stored
  r = res(); await nodes.createNode({ body: body({ gatewayId: GW_ID }) }, r);
  assert.strictEqual(r.code, 201, JSON.stringify(r.body));
  assert.strictEqual(r.body.node.gatewayId, GW_ID); assert.strictEqual(r.body.node.gatewayName, 'gw-1');
  assert.strictEqual(r.body.node.deviceProfileId, '22222222-2222-2222-2222-222222222222');
  assert.strictEqual(state.created[0].deviceProfileId, '22222222-2222-2222-2222-222222222222');

  // create: unknown / malformed references are 400
  r = res(); await nodes.createNode({ body: body({ deviceName: 'd2', devEui: '0011223344556688', gatewayId: 'f'.repeat(24) }) }, r); assert.strictEqual(r.code, 400); assert.match(r.body.error, /Gateway not found/);
  r = res(); await nodes.createNode({ body: body({ deviceName: 'd2', devEui: '0011223344556688', gatewayId: 'nope' }) }, r); assert.strictEqual(r.code, 400); assert.match(r.body.error, /Invalid gateway id/);
  r = res(); await nodes.createNode({ body: body({ deviceName: 'd2', devEui: '0011223344556688', applicationId: '99999999-9999-9999-9999-999999999999' }) }, r); assert.strictEqual(r.code, 400); assert.match(r.body.error, /Application not found/);
  r = res(); await nodes.createNode({ body: body({ deviceName: 'd2', devEui: '0011223344556688', applicationId: 'my-app' }) }, r); assert.strictEqual(r.code, 400); assert.match(r.body.error, /Application ID must be a ChirpStack/);
  r = res(); await nodes.createNode({ body: body({ deviceName: 'd2', devEui: '0011223344556688', deviceProfileId: '88888888-8888-8888-8888-888888888888' }) }, r); assert.strictEqual(r.code, 400); assert.match(r.body.error, /Device profile not found/);
  r = res(); await nodes.createNode({ body: body() }, r); assert.strictEqual(r.code, 409);
  assert.strictEqual(state.nodes.length, 1, 'nothing saved for the rejected requests');

  // list shows the gateway name; edit without a profile keeps the stored one; unlinking the gateway
  r = res(); await nodes.getNodes({}, r); assert.strictEqual(r.body[0].gatewayName, 'gw-1');
  r = res(); await nodes.updateNode({ params: { id: 'c'.repeat(24) }, body: body({ gatewayId: '' }) }, r);
  assert.strictEqual(r.code, 200, JSON.stringify(r.body)); assert.strictEqual(r.body.node.gatewayId, ''); assert.strictEqual(r.body.node.deviceProfileId, '22222222-2222-2222-2222-222222222222');
  r = res(); await nodes.getNode({ params: { id: 'd'.repeat(24) } }, r); assert.strictEqual(r.code, 404);

  // sync off: any application text is accepted (no ChirpStack to ask)
  state.cs = false;
  r = res(); await nodes.createNode({ body: body({ deviceName: 'd3', devEui: '0011223344556699', applicationId: 'my-app' }) }, r); assert.strictEqual(r.code, 201);
  state.cs = true;

  // deleting a gateway unlinks its devices
  r = res(); await gateways.deleteGateway({ params: { id: GW_ID } }, r);
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.nodesUnlinked, 2); assert.deepStrictEqual(state.gatewayUpdates[0][1], { $set: { gatewayId: null } });
  console.log('ID rules: all checks passed');
})().catch((e) => { console.error(e); process.exit(1); });
