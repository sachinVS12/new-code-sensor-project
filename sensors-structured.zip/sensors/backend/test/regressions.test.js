// Regression tests for bugs found in the full review. Run: node test/regressions.test.js
const Module = require('module');
const path = require('path');
const assert = require('assert');

const src = (...p) => path.join(__dirname, '..', 'src', ...p);
const res = () => { const r = { code: 200 }; r.status = (n) => { r.code = n; return r; }; r.json = (b) => { r.body = b; return r; }; return r; };

const pipelines = { sensor: [] };
const saved = [];
class GatewayModel {
  constructor(d) { Object.assign(this, d); }
  async save() { saved.push(this); return this; }
}
GatewayModel.findOne = async (q) => { GatewayModel.lastQuery = q; return null; };
GatewayModel.find = () => ({ lean: async () => [] });

const stubs = {
  '../config/env': { GATEWAY_ACTIVE_MINUTES: 15 },
  '../models/SensorData': { aggregate: async (p) => { pipelines.sensor.push(p); return []; } },
  '../models/Node': { countDocuments: async () => 0 },
  '../models/Downlink': { aggregate: async () => [] },
  '../models/Gateway': GatewayModel,
  '../models/FeedData': {},
  '../services/deviceRegistry': { deviceNames: {} },
  '../services/mqtt.service': { buildTopic: () => 't', subscribeTopic() {}, unsubscribeTopic: async () => {} },
  '../services/nodeView': { nodeJson: (n) => n, nodesJson: async (n) => n, gatewayNames: async () => new Map() },
  '../services/chirpstack.service': { isEnabled: () => false, defaultDeviceProfileId: () => '' },
};
const orig = Module._load;
Module._load = function (req, ...rest) { return stubs[req] || orig.call(this, req, ...rest); };

(async () => {
  // 1. a saved "partial" dataset is never the latest uplink and never counts as an uplink on the dashboard
  const { getLatest } = require(src('controllers', 'sensorData.controller.js'));
  await getLatest({}, res());
  const latest = pipelines.sensor.pop();
  assert.deepStrictEqual(latest[0], { $match: { 'decodedPayload.kind': { $ne: 'partial' } } }, 'getLatest must filter partial rows before sorting');

  const { getDashboard } = require(src('controllers', 'dashboard.controller.js'));
  const r = res(); await getDashboard({}, r);
  assert.strictEqual(r.code, 200);
  const hourly = pipelines.sensor.find((p) => p[0].$match && p[0].$match.timestamp && !p[0].$match.gatewayId);
  assert.ok(hourly, 'hourly pipeline found');
  assert.deepStrictEqual(hourly[0].$match['decodedPayload.kind'], { $ne: 'partial' }, 'hourly uplink count must skip partial rows');
  console.log('ok  partial rows are not "latest" and not counted as uplinks');

  // 2. device fields that are not text are a 400, not a crash (.trim is not a function)
  const nodes = require(src('controllers', 'node.controller.js'));
  for (const fn of [nodes.createNode, nodes.updateNode]) {
    const rr = res();
    await fn({ params: { id: 'x' }, body: { deviceName: 123, devEui: '0011223344556677', applicationId: 'a' } }, rr);
    assert.strictEqual(rr.code, 400); assert.match(rr.body.error, /required/);
    const r2 = res();
    await fn({ params: { id: 'x' }, body: { deviceName: { a: 1 }, devEui: ['x'], applicationId: null } }, r2);
    assert.strictEqual(r2.code, 400);
  }
  console.log('ok  non-text device fields -> 400');

  // 3. gateway name is trimmed before the duplicate check and before saving
  const gw = require(src('controllers', 'gateway.controller.js'));
  const g = res();
  await gw.createGateway({ body: { gatewayName: '  gw-1  ', gatewayEui: 'AABBCCDDEEFF0011', destinationIp: '1.2.3.4', port: '1700', mode: 'local' } }, g);
  assert.strictEqual(g.code, 201);
  assert.strictEqual(saved[0].gatewayName, 'gw-1');
  assert.deepStrictEqual(GatewayModel.lastQuery.$or[1], { gatewayName: 'gw-1' });
  const blank = res();
  await gw.createGateway({ body: { gatewayName: '   ', gatewayEui: 'AABBCCDDEEFF0011', destinationIp: '1.2.3.4', port: '1700', mode: 'local' } }, blank);
  assert.strictEqual(blank.code, 400);
  console.log('ok  gateway name trimmed; blank name rejected');

  console.log('regressions: all checks passed');
})().catch((e) => { console.error(e); process.exit(1); });
