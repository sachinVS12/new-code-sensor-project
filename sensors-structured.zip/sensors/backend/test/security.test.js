// Hardening checks with stubs (no database, broker or browser needed): node test/security.test.js
process.env.MQTT_HOST = 'mqtt://x'; process.env.MONGODB_URI = 'mongodb://x';
const Module = require('module'); const assert = require('assert');

// ---- fake SensorData collection to see which index calls are made ----
const calls = [];
const state = { indexes: [] };
const fakeCollection = {
  collectionName: 'sensordatas',
  indexes: async () => state.indexes,
  dropIndex: async (n) => { calls.push('drop:' + n); state.indexes = state.indexes.filter((i) => i.name !== n); },
  createIndex: async (k, o) => { calls.push('create:' + JSON.stringify(o)); state.indexes.push({ name: 'timestamp_1', key: k, ...(o.expireAfterSeconds !== undefined ? { expireAfterSeconds: o.expireAfterSeconds } : {}) }); },
};
const stubs = {
  '../models/SensorData': { collection: fakeCollection, db: { db: { command: async (c) => { calls.push('collMod:' + c.index.expireAfterSeconds); state.indexes[0].expireAfterSeconds = c.index.expireAfterSeconds; } } } },
  '../models/Node': {}, '../models/Gateway': {},
  ws: { Server: function () {}, OPEN: 1 }, dotenv: { config() {} },   // packages are not needed for these checks
};
const orig = Module._load;
Module._load = function (req, ...rest) { return stubs[req] || orig.call(this, req, ...rest); };

const { securityHeaders, createRateLimiter, apiNotFound, errorHandler } = require('../src/middleware/security.js');
const { isAllowedOrigin } = require('../src/services/websocket.service.js');
const { ensureSensorDataRetention } = require('../src/services/migrations.js');

const mkRes = () => { const r = { code: 200, headers: {} }; r.setHeader = (k, v) => { r.headers[k] = v; }; r.status = (n) => { r.code = n; return r; }; r.json = (b) => { r.body = b; return r; }; return r; };

(async () => {
  // security headers
  let r = mkRes(); let ok = false; securityHeaders({ path: '/', headers: {} }, r, () => { ok = true; });
  assert.ok(ok); assert.strictEqual(r.headers['X-Content-Type-Options'], 'nosniff'); assert.strictEqual(r.headers['X-Frame-Options'], 'DENY');
  assert.match(r.headers['Content-Security-Policy'], /default-src 'self'/); assert.ok(!r.headers['Strict-Transport-Security']);
  r = mkRes(); securityHeaders({ path: '/api/nodes', headers: { 'x-forwarded-proto': 'https' } }, r, () => {});
  assert.ok(!r.headers['Content-Security-Policy'], 'no CSP on API replies'); assert.match(r.headers['Strict-Transport-Security'], /max-age/);

  // rate limit
  let t = 1000; const lim = createRateLimiter({ max: 3, windowMs: 60000, now: () => t });
  const hit = (ip) => { const res = mkRes(); let passed = false; lim({ ip }, res, () => { passed = true; }); return { res, passed }; };
  assert.ok(hit('1.1.1.1').passed && hit('1.1.1.1').passed && hit('1.1.1.1').passed);
  const blocked = hit('1.1.1.1'); assert.ok(!blocked.passed); assert.strictEqual(blocked.res.code, 429); assert.ok(Number(blocked.res.headers['Retry-After']) >= 1);
  assert.ok(hit('2.2.2.2').passed, 'another IP is not affected');
  t += 61000; assert.ok(hit('1.1.1.1').passed, 'window resets');
  const off = createRateLimiter({ max: 0 }); let p = false; off({ ip: 'x' }, mkRes(), () => { p = true; }); assert.ok(p, 'max 0 = off');

  // JSON errors
  r = mkRes(); errorHandler({ type: 'entity.parse.failed' }, {}, r, () => {}); assert.strictEqual(r.code, 400);
  r = mkRes(); errorHandler({ type: 'entity.too.large' }, {}, r, () => {}); assert.strictEqual(r.code, 413);
  const log = console.error; console.error = () => {}; r = mkRes(); errorHandler(new Error('secret db detail'), {}, r, () => {}); console.error = log;
  assert.strictEqual(r.code, 500); assert.deepStrictEqual(r.body, { error: 'Internal server error' });
  r = mkRes(); apiNotFound({}, r); assert.strictEqual(r.code, 404);

  // WebSocket origin
  assert.ok(isAllowedOrigin(undefined, 'a.com', []));                       // not a browser
  assert.ok(isAllowedOrigin('https://a.com', 'a.com', []));                 // same host that serves the page
  assert.ok(isAllowedOrigin('http://localhost:5173', 'localhost:3000', [])); // development
  assert.ok(isAllowedOrigin('https://ui.example.com', 'a.com', ['https://ui.example.com']));
  assert.ok(!isAllowedOrigin('https://evil.example', 'a.com', []));
  assert.ok(!isAllowedOrigin('not a url', 'a.com', []));

  // retention index
  state.indexes = [{ name: 'timestamp_1', key: { timestamp: 1 } }];
  await ensureSensorDataRetention(30);   // plain -> TTL 30 days
  assert.deepStrictEqual(calls, ['drop:timestamp_1', 'create:{"expireAfterSeconds":2592000}']);
  calls.length = 0; await ensureSensorDataRetention(30); assert.deepStrictEqual(calls, [], 'unchanged setting touches nothing');
  await ensureSensorDataRetention(90); assert.deepStrictEqual(calls, ['collMod:7776000']);
  calls.length = 0; await ensureSensorDataRetention(0);   // TTL -> plain (keep forever)
  assert.deepStrictEqual(calls, ['drop:timestamp_1', 'create:{}']);
  calls.length = 0; state.indexes = []; await ensureSensorDataRetention(0); assert.deepStrictEqual(calls, ['create:{}'], 'no index yet');
  console.log('security + retention: all checks passed');
})().catch((e) => { console.error(e); process.exit(1); });
