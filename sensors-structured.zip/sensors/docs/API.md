# API reference

Base path `/api`. Every route except `/api/auth/*` needs the login session cookie (`401 Not logged in` without it). All bodies and replies are JSON. Errors are always `{ "error": "message" }` with a matching status
(400 bad input, 404 unknown id, 409 duplicate, 502 ChirpStack not reachable / refused).

## IDs

Everything is referenced by an ID, never by a name. Names are only for display and are looked up from the ID.

| What | ID | Format | Where it comes from |
|---|---|---|---|
| Device (node) | `_id` | 24 hex (MongoDB) | this dashboard |
| Device on the LoRaWAN side | `devEui` | 16 hex, lower case | the device; it is also the ID in ChirpStack |
| Gateway | `_id` | 24 hex (MongoDB) | this dashboard (`gatewayEui` is its ID in ChirpStack) |
| Downlink | `_id` | 24 hex (MongoDB) | this dashboard |
| Application | `id` | UUID | ChirpStack |
| Device profile | `id` | UUID | ChirpStack |

A malformed ID in the URL (`/api/nodes/xyz`) is a `400 Invalid id`, never a server error.

How things point to each other:

```
Device ── applicationId ──▶ Application (ChirpStack)
       ── deviceProfileId ─▶ Device profile (ChirpStack)
       ── gatewayId ───────▶ Gateway (this dashboard, optional)
Downlink / Feed data / Uplink data ── devEui ──▶ Device
```

* Creating or editing a device checks every ID it points to: `gatewayId` must be an existing gateway; with ChirpStack
  sync on, `applicationId` and `deviceProfileId` must exist in ChirpStack. Nothing is created for a bad reference.
* Replies that contain a device also contain `gatewayName` (looked up from `gatewayId`), so renaming a gateway never
  leaves a stale name on a device. Downlink and feed-data replies show the device's **current** name.
* Deleting a gateway clears `gatewayId` on its devices (reply: `nodesUnlinked`).
  Deleting an application deletes its devices in ChirpStack and in the dashboard (reply: `devicesRemoved`).
* Devices saved by an older version (gateway stored by name) are converted to `gatewayId` when the server starts.

## Devices  `/api/nodes`

| Method | Path | Body / query | Reply |
|---|---|---|---|
| GET | `/nodes` | | list of devices |
| GET | `/nodes/:id` | | one device |
| POST | `/nodes` | `deviceName`, `devEui`, `applicationId`, optional `mode` (OTAA/ABP), `gatewayId`, `deviceProfileId`, `appKey` | 201 `{ node, chirpstack }` |
| PUT | `/nodes/:id` | same as POST (no `deviceProfileId` = keep the current one) | `{ node, chirpstack }` |
| DELETE | `/nodes/:id` | | `{ chirpstack }` |

Device: `{ _id, deviceName, devEui, applicationId, deviceProfileId, gatewayId, gatewayName, mode, mqttTopic, createdAt }`
(`gatewayId` is `""` when there is no gateway; `mqttTopic` is generated from `applicationId` and `devEui`).

## Gateways  `/api/gateways`

| Method | Path | Body | Reply |
|---|---|---|---|
| GET | `/gateways` | | list |
| GET | `/gateways/:id` | | one gateway |
| POST | `/gateways` | `gatewayName`, `gatewayEui`, `destinationIp`, `port`, `mode` (local/cloud), optional `regionId` | 201 `{ gateway, chirpstack }` |
| PUT | `/gateways/:id` | same as POST | `{ gateway, chirpstack }` |
| DELETE | `/gateways/:id` | | `{ nodesUnlinked, chirpstack }` |

## Applications  `/api/applications`  (ChirpStack, needs sync on)

| Method | Path | Body | Reply |
|---|---|---|---|
| GET | `/applications` | | `[ { id, name, description, createdAt, updatedAt } ]` |
| GET | `/applications/:id` | | `{ id, name, description }` |
| POST | `/applications` | `name`, optional `description` | 201 `{ id, name }` |
| PUT | `/applications/:id` | `name`, optional `description` | `{ id, name }` |
| DELETE | `/applications/:id` | | `{ devicesRemoved }` |

## Device profiles  `/api/device-profiles`  (ChirpStack, needs sync on)

| Method | Path | Body | Reply |
|---|---|---|---|
| GET | `/device-profiles` | | list |
| GET | `/device-profiles/:id` | | one profile (form fields) |
| POST | `/device-profiles` | `name`, `region`, `macVersion`, `regParamsRevision`, `uplinkInterval`, ... | 201 `{ id, name }` |
| PUT | `/device-profiles/:id` | same as POST | `{ id, name }` |
| DELETE | `/device-profiles/:id` | | `{ message }` |

## Downlinks, feed data, other

| Method | Path | Notes |
|---|---|---|
| GET | `/downlinks?devEui=&status=` | the device is given by `devEui` |
| POST | `/downlinks` | body has `devEui` (the application is taken from the device) |
| DELETE | `/downlinks/:id` | removes the entry from the list only |
| GET / POST / DELETE | `/feed-data?devEui=` | rows per device (`devEui` is required) |
| GET | `/latest` | last saved uplink of every device |
| GET | `/dashboard` | gateway status and chart data |
| GET | `/chirpstack/status` | `{ enabled, defaultDeviceProfileId, deviceProfiles }` |

Live data: WebSocket `/socket` sends every uplink as `{ deviceName, devEui, topic, ... }`; the screens filter by `devEui`.

## Login  `/api/auth`

| Method | Path | Body | Reply |
|---|---|---|---|
| POST | `/auth/login` | `username`, `password` | `{ user: { username } }` and a session cookie; 401 for a wrong login, 429 after 10 attempts in 15 minutes |
| GET | `/auth/me` | | `{ user }`, or 401 when not logged in |
| POST | `/auth/logout` | | clears the cookie |

The WebSocket `/socket` also needs the session cookie. Requests that change data are refused (403) when their `Origin` is another website.
