import { useState, useEffect, useRef } from 'react';
import Sidebar from './components/layout/Sidebar';
import Navbar from './components/layout/Navbar';
import { applyPayloadEntry, packetTypeOf } from './utils/payload';
import DashboardPage from './pages/DashboardPage';
import GatewayPage from './pages/GatewayPage';
import DownlinkPage from './pages/DownlinkPage';
import TaskPage from './pages/TaskPage';
import NodeCreationPage from './pages/NodeCreationPage';
import DeviceProfilePage from './pages/DeviceProfilePage';
import ApplicationPage from './pages/ApplicationPage';
import TabularViewPage from './pages/TabularViewPage';
import PayloadViewPage from './pages/PayloadViewPage';
import GraphViewPage from './pages/GraphViewPage';
import ToastContainer from './components/common/ToastContainer';
import ConfirmDialogHost from './components/common/ConfirmDialogHost';
import { toast } from './utils/toast';
import useIsMobile from './hooks/useIsMobile';

export default function App({ user = null, onLogout }) {
    const [isConnected, setIsConnected] = useState(false);
    const [sensorData, setSensorData] = useState(null);
    const [rssiHistory, setRssiHistory] = useState([]);
    const [snrHistory, setSnrHistory] = useState([]);
    const [payloadHistory, setPayloadHistory] = useState([]);
    const [error, setError] = useState(null);
    const [messageCount, setMessageCount] = useState(0);
    const [logs, setLogs] = useState([]);
    const [currentPage, setCurrentPage] = useState('dashboard'); // opens on the dashboard after every reload. Pages: 'dashboard', 'graph', 'tabular', 'node-creation', 'device-profile', 'application', 'gateway', 'downlink', 'task', 'payload-view'
    const [isCollapsed, setIsCollapsed] = useState(false);
    // set by the Application List ("+" or a device) to open Device Creation with an application chosen: { applicationId } or { device }
    const [deviceCreationPreset, setDeviceCreationPreset] = useState(null);
    const isMobile = useIsMobile();                     // phone layout: sidebar becomes a slide-in menu
    const [menuOpen, setMenuOpen] = useState(false);

    // leaving the phone layout (rotate / resize) closes the menu
    useEffect(() => { if (!isMobile) setMenuOpen(false); }, [isMobile]);
    const [topics, setTopics] = useState([]);              // saved device topics for the dropdown
    const [selectedTopic, setSelectedTopic] = useState('all');
    const selectedTopicRef = useRef('all');
    // One row per device for the tabular view - values are overwritten, never appended
    const [deviceRows, setDeviceRows] = useState({});
    // Payload history kept separately for every device (used by the Tabular View icons)
    const [payloadByDevice, setPayloadByDevice] = useState({});
    const [payloadView, setPayloadView] = useState(null);   // { device, mode: 'history' | 'latest' }

    // Seed the table with the last saved values so it isn't empty after a refresh
    useEffect(() => {
        fetch('/api/latest')
            .then(r => r.json())
            .then(list => {
                const seeded = {};
                list.forEach(d => {
                    const key = (d.devEui || '').toLowerCase();
                    seeded[key] = {
                        type: packetTypeOf(d.decodedPayload),
                        snr: d.snr,
                        rssi: d.rssi,
                        spreadingFactor: d.spreadingFactor,
                        realtime: d.decodedPayload?.avg ?? null,
                        lastUpdate: Date.parse(d.timestamp),   // ms, for the relative time
                        lastTs: Date.parse(d.timestamp),
                        interval: null
                    };
                });
                setDeviceRows(prev => ({ ...seeded, ...prev }));
            })
            .catch(err => console.error('Error loading latest values:', err));
    }, []);

    // Load saved devices (and their auto-generated MQTT topics) for the dropdown
    const loadTopics = async () => {
        try {
            const res = await fetch('/api/nodes');
            const nodes = await res.json();
            setTopics(nodes.map(n => ({ id: n._id, topic: n.mqttTopic, deviceName: n.deviceName, devEui: n.devEui })));
        } catch (err) {
            console.error('Error loading topics:', err);
        }
    };
    useEffect(() => { loadTopics(); }, [currentPage]);

    // Selecting a device (by its DevEUI) shows only that device's data; start with fresh charts
    const handleSelectTopic = (devEui) => {
        if (devEui === selectedTopicRef.current) return;   // already showing this device
        selectedTopicRef.current = devEui;
        setSelectedTopic(devEui);
        setSensorData(null);
        setRssiHistory([]);
        setSnrHistory([]);
        setPayloadHistory([]);
        setMessageCount(0);
    };

    // Export payload history to CSV (Excel-compatible)
    const exportToExcel = () => {
        if (!payloadHistory || payloadHistory.length === 0) {
            toast.warning('No payload data to export');
            return;
        }

        let csvContent = 'Timestamp,Entry Type,Average,Min,Max,Battery,Sample Index,Sample Value\n';

        payloadHistory.forEach((payload, payloadIndex) => {
            const entryType = payload.isChunk ? 'Chunk' : 'Complete';
            const samples = payload.samples || [];
            
            samples.forEach((sample, sampleIndex) => {
                csvContent += `${payload.time},${entryType},${payload.avg || ''},${payload.min},${payload.max},${payload.battery || ''},${sampleIndex},${sample}\n`;
            });
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `payload_history_${new Date().toISOString().replace(/[:.]/g, '-')}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    useEffect(() => {
        console.log('Initializing WebSocket connection...');
        console.log('Host:', window.location.host);
        let ws = null;
        let stopped = false;
        let retryTimer = null;

        const connect = () => {
        const wsBase = (typeof __WS_BASE__ === 'string' && __WS_BASE__)
            || `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}`;
        console.log('WebSocket URL:', `${wsBase}/socket`);
        ws = new WebSocket(`${wsBase}/socket`);

        ws.onopen = () => {
            console.log('WebSocket connected');
            setIsConnected(true);
            setError(null);
            // after a (re)connect, open pages reload once so nothing missed while offline is lost
            window.dispatchEvent(new CustomEvent('downlink-update', { detail: { type: 'downlink', event: 'resync' } }));
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                
                // Handle log messages
                if (data.type === 'log') {
                    setLogs(prev => {
                        const newLogs = [...prev, { message: data.message, timestamp: new Date().toLocaleTimeString() }];
                        return newLogs.slice(-200); // Keep last 200 logs
                    });
                    return;
                }
                
                // Downlink status changed (queued / transmitted / acknowledged): tell the Task and Dashboard pages
                if (data.type === 'downlink') {
                    window.dispatchEvent(new CustomEvent('downlink-update', { detail: data }));
                    return;
                }

                // Update that device's single table row in place (all devices, regardless of dropdown)
                const rowKey = (data.devEui || '').toLowerCase();
                setDeviceRows(prev => {
                    const old = prev[rowKey] || {};
                    // seconds between this uplink and the previous one from the same device
                    const ts = Date.parse(data.timestamp) || Date.now();
                    const gap = old.lastTs ? (ts - old.lastTs) / 1000 : null;

                    // Chunked dataset timing: how long it takes to receive all chunks (1 .. total)
                    const dp = data.decodedPayload;
                    let chunkInfo = old.chunkInfo;
                    if (dp && (dp.kind === 'chunk' || dp.kind === 'dataset') && dp.totalChunks) {
                        const oldInfo = old.chunkInfo;
                        // a new dataset starts after a finished one, or when the previous one was cut short
                        const startTs = (!oldInfo || oldInfo.done || dp.previousIncomplete) ? ts : oldInfo.startTs;
                        const elapsed = Math.max(0, (ts - startTs) / 1000);
                        const received = dp.receivedChunks;
                        const avg = received > 1 ? elapsed / (received - 1) : null;   // seconds between chunks
                        chunkInfo = {
                            startTs,
                            received,
                            total: dp.totalChunks,
                            elapsed,
                            avg,
                            remaining: dp.kind === 'dataset' ? 0 : (avg !== null ? avg * (dp.totalChunks - received) : null),
                            done: dp.kind === 'dataset'
                        };
                    }
                    return {
                        ...prev,
                        [rowKey]: {
                            // packet type: chunk devices send it in the header, others in decodedPayload.type
                            type: packetTypeOf(data.decodedPayload) ?? old.type,
                            snr: data.snr ?? old.snr,
                            rssi: data.rssi ?? old.rssi,
                            spreadingFactor: data.spreadingFactor ?? old.spreadingFactor,
                            // chunks carry no average - keep the last complete value until a new one arrives
                            realtime: data.decodedPayload?.avg ?? old.realtime ?? null,
                            lastUpdate: Date.now(),
                            lastTs: ts,
                            chunkInfo,
                            interval: gap !== null && gap >= 0 ? Math.round(gap * 10) / 10 : (old.interval ?? null)
                        }
                    };
                });

                // Keep this device's own payload history (independent of the dropdown)
                if (data.decodedPayload) {
                    const payloadTime = new Date(data.timestamp).toLocaleTimeString();
                    setPayloadByDevice(prev => ({
                        ...prev,
                        [rowKey]: applyPayloadEntry(prev[rowKey] || [], data.decodedPayload, payloadTime)
                    }));
                }

                // Only use data from the selected device ('all' = every saved device)
                if (selectedTopicRef.current !== 'all' && String(data.devEui || '').toLowerCase() !== selectedTopicRef.current) return;

                console.log('Received data:', data);
                setSensorData(data);
                setMessageCount(prev => prev + 1);

                // Update history for charts (keep last 50 points)
                const timestamp = new Date(data.timestamp).toLocaleTimeString();
                
                setRssiHistory(prev => {
                    const newHistory = [...prev, { time: timestamp, rssi: data.rssi }];
                    console.log('RSSI history:', newHistory);
                    return newHistory.slice(-100);
                });

                setSnrHistory(prev => {
                    const newHistory = [...prev, { time: timestamp, snr: data.snr }];
                    console.log('SNR history:', newHistory);
                    return newHistory.slice(-100);
                });

                // Update payload history if decoded payload exists
                if (data.decodedPayload) {
                    // Handle chunked-dataset format - add chunks as they arrive
                    if (data.decodedPayload.kind === 'chunk' && data.decodedPayload.chunkSamples) {
                        setPayloadHistory(prev => {
                            const newHistory = [...prev, {
                                time: timestamp,
                                samples: data.decodedPayload.chunkSamples,
                                avg: null, // No avg for partial chunk
                                min: Math.min(...data.decodedPayload.chunkSamples),
                                max: Math.max(...data.decodedPayload.chunkSamples),
                                battery: data.decodedPayload.battery || 'N/A',
                                isChunk: true,
                                progress: `${data.decodedPayload.receivedChunks}/${data.decodedPayload.totalChunks} chunks`
                            }];
                            console.log('Payload history (chunk):', newHistory);
                            return newHistory.slice(-100);
                        });
                    }
                    // Handle complete dataset (replace last chunk or add as new)
                    else if (data.decodedPayload.kind === 'dataset' && data.decodedPayload.samples) {
                        setPayloadHistory(prev => {
                            // Remove the chunks that belong to this dataset and add the complete one
                            const newHistory = [...prev];
                            // Keep only non-chunk entries or chunks from other datasets
                            const filtered = newHistory.filter(p => !p.isChunk);
                            const completeEntry = {
                                time: timestamp,
                                samples: data.decodedPayload.samples,
                                avg: data.decodedPayload.avg,
                                min: data.decodedPayload.min,
                                max: data.decodedPayload.max,
                                battery: data.decodedPayload.battery || 'N/A',
                                isChunk: false
                            };
                            filtered.push(completeEntry);
                            console.log('Payload history (dataset complete):', filtered);
                            return filtered.slice(-100);
                        });
                    }
                    // Handle RAK5146 format
                    else if (data.decodedPayload.samples) {
                        setPayloadHistory(prev => {
                            const newHistory = [...prev, {
                                time: timestamp,
                                samples: data.decodedPayload.samples,
                                avg: data.decodedPayload.avg,
                                min: data.decodedPayload.min,
                                max: data.decodedPayload.max,
                                battery: data.decodedPayload.batteryV,
                                isChunk: false
                            }];
                            console.log('Payload history (RAK5146):', newHistory);
                            return newHistory.slice(-100);
                        });
                    }
                }
            } catch (err) {
                console.error('Error parsing message:', err);
                setError('Failed to parse data');
            }
        };

        ws.onclose = () => {
            console.log('WebSocket disconnected');
            setIsConnected(false);
            // reconnect automatically so live updates keep working
            if (!stopped) retryTimer = setTimeout(connect, 2000);
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            setError('WebSocket connection error');
            setIsConnected(false);
        };

        };   // end of connect()

        connect();

        return () => {
            stopped = true;
            clearTimeout(retryTimer);
            if (ws) ws.close();
        };
    }, []);

    return (
        <>
            <ToastContainer />
            <ConfirmDialogHost />
            <Sidebar
                currentPage={currentPage}
                setCurrentPage={(page) => { setCurrentPage(page); setMenuOpen(false); }}
                isCollapsed={isCollapsed}
                setIsCollapsed={setIsCollapsed}
                isMobile={isMobile}
                menuOpen={menuOpen}
                onClose={() => setMenuOpen(false)}
            />
            <Navbar isConnected={isConnected} isCollapsed={isCollapsed} isMobile={isMobile} onMenuClick={() => setMenuOpen(true)} user={user} onLogout={onLogout} />
            <main className="page-area">
            {currentPage === 'dashboard' && <DashboardPage isCollapsed={isCollapsed} />}
            {currentPage === 'gateway' && <GatewayPage isCollapsed={isCollapsed} />}
            {currentPage === 'downlink' && <DownlinkPage devices={topics} isCollapsed={isCollapsed} onOpenTask={() => setCurrentPage('task')} />}
            {currentPage === 'task' && <TaskPage devices={topics} isCollapsed={isCollapsed} />}
            {currentPage === 'node-creation' && <NodeCreationPage isCollapsed={isCollapsed} preset={deviceCreationPreset} onPresetUsed={() => setDeviceCreationPreset(null)} />}
            {currentPage === 'device-profile' && <DeviceProfilePage isCollapsed={isCollapsed} />}
            {currentPage === 'application' && <ApplicationPage isCollapsed={isCollapsed} onOpenDeviceCreation={(preset) => { setDeviceCreationPreset(preset); setCurrentPage('node-creation'); }} />}
            {currentPage === 'tabular' && <TabularViewPage devices={topics} deviceRows={deviceRows} isCollapsed={isCollapsed} onOpenPayload={(device, mode) => { setPayloadView({ device, mode }); setCurrentPage('payload-view'); }} />}
            {currentPage === 'payload-view' && payloadView && (
                <PayloadViewPage
                    device={payloadView.device}
                    mode={payloadView.mode}
                    history={payloadByDevice[(payloadView.device.devEui || '').toLowerCase()] || []}
                    onExit={() => setCurrentPage('tabular')}
                    isCollapsed={isCollapsed}
                />
            )}
            {currentPage === 'graph' && <GraphViewPage isConnected={isConnected} sensorData={sensorData} rssiHistory={rssiHistory} snrHistory={snrHistory} payloadHistory={payloadHistory} error={error} messageCount={messageCount} logs={logs} exportToExcel={exportToExcel} isCollapsed={isCollapsed} topics={topics} selectedTopic={selectedTopic} onSelectTopic={handleSelectTopic} />}
            </main>
        </>
    );
}
