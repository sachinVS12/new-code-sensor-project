import { useCallback, useEffect, useState } from 'react';
import App from '../../App';
import LoginPage from './LoginPage';
import ToastContainer from '../common/ToastContainer';
import { toast } from '../../utils/toast';

// Shows the login page until the server confirms a session (cookie), then the dashboard.
export default function AuthGate() {
    const [status, setStatus] = useState('loading');   // loading | in | out | unreachable
    const [user, setUser] = useState(null);

    const checkSession = useCallback(async () => {
        setStatus('loading');
        try {
            const res = await fetch('/api/auth/me');
            if (res.ok) {
                setUser((await res.json()).user);
                setStatus('in');
            } else {
                setStatus('out');
            }
        } catch {
            setStatus('unreachable');
        }
    }, []);

    useEffect(() => { checkSession(); }, [checkSession]);

    // a data request was answered with 401: the session ended
    useEffect(() => {
        const onExpired = () => {
            setUser(null);
            setStatus(s => {
                if (s === 'in') toast.warning('Your session has ended. Please sign in again.');
                return 'out';
            });
        };
        window.addEventListener('auth-expired', onExpired);
        return () => window.removeEventListener('auth-expired', onExpired);
    }, []);

    const handleLogin = (u) => {
        setUser(u);
        setStatus('in');
    };

    const handleLogout = async () => {
        try {
            await fetch('/api/auth/logout', { method: 'POST' });
        } catch { /* the cookie is cleared by the server; if it was unreachable the session simply times out */ }
        setUser(null);
        setStatus('out');
    };

    if (status === 'in') return <App user={user} onLogout={handleLogout} />;
    if (status === 'out') return <LoginPage onLogin={handleLogin} />;

    return (
        <div className="login-status">
            <ToastContainer />
            {status === 'loading' ? (
                <p>Loading...</p>
            ) : (
                <div style={{ textAlign: 'center' }}>
                    <p>Could not reach the server.</p>
                    <button className="login-submit" style={{ width: 'auto', padding: '10px 28px' }} onClick={checkSession}>Try again</button>
                </div>
            )}
        </div>
    );
}
