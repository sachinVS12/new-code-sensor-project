import { useState } from 'react';
import SensorsIllustration from './SensorsIllustration';
import ToastContainer from '../common/ToastContainer';
import { toast } from '../../utils/toast';

// Login page: LoRaWAN illustration on the left, sign-in form on the right (the illustration is hidden on narrow screens).
export default function LoginPage({ onLogin }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [busy, setBusy] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (busy) return;
        if (!username.trim() || !password) {
            toast.error('Enter your username and password');
            return;
        }
        setBusy(true);
        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: username.trim(), password })
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || (res.status === 429 ? 'Too many attempts. Please wait a few minutes.' : 'Login failed'));
            onLogin(data.user);
        } catch (err) {
            setPassword('');
            toast.error(err.message === 'Failed to fetch' ? 'Could not reach the server' : err.message);
        } finally {
            setBusy(false);
        }
    };

    const icon = (children) => (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>
    );

    return (
        <div className="login-shell">
            <ToastContainer />

            <aside className="login-art" aria-hidden="false">
                <div className="login-art-inner">
                    <div className="login-art-text">
                        <h1>LoRaWAN Sensor Monitoring</h1>
                        <p>Live data from your sensors, gateways and devices in one place.</p>
                    </div>
                    <div className="login-art-image"><SensorsIllustration /></div>
                </div>
            </aside>

            <main className="login-panel">
                <form className="login-card" onSubmit={handleSubmit} noValidate>
                    <div className="login-logo" aria-hidden="true">
                        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M5 12.5a10 10 0 0 1 14 0" />
                            <path d="M8.5 16a5 5 0 0 1 7 0" />
                            <circle cx="12" cy="19.5" r="1.2" fill="currentColor" />
                            <path d="M2 9a14 14 0 0 1 20 0" />
                        </svg>
                    </div>
                    <h2>Welcome back</h2>
                    <p className="login-sub">Sign in to the sensor dashboard</p>

                    <label className="login-label" htmlFor="login-username">Username</label>
                    <div className="login-field">
                        <span className="login-field-icon">{icon(<><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>)}</span>
                        <input
                            id="login-username"
                            type="text"
                            autoComplete="username"
                            autoFocus
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Enter your username"
                        />
                    </div>

                    <label className="login-label" htmlFor="login-password">Password</label>
                    <div className="login-field">
                        <span className="login-field-icon">{icon(<><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>)}</span>
                        <input
                            id="login-password"
                            type={showPassword ? 'text' : 'password'}
                            autoComplete="current-password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter your password"
                        />
                        <button
                            type="button"
                            className="login-eye"
                            onClick={() => setShowPassword(s => !s)}
                            aria-label={showPassword ? 'Hide password' : 'Show password'}
                            title={showPassword ? 'Hide password' : 'Show password'}
                        >
                            {showPassword
                                ? icon(<><path d="M17.9 17.9A10.5 10.5 0 0 1 12 20C5 20 1 12 1 12a18 18 0 0 1 5.1-5.9" /><path d="M9.9 4.2A9.8 9.8 0 0 1 12 4c7 0 11 8 11 8a18 18 0 0 1-2.2 3.2" /><line x1="1" y1="1" x2="23" y2="23" /></>)
                                : icon(<><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z" /><circle cx="12" cy="12" r="3" /></>)}
                        </button>
                    </div>

                    <button type="submit" className="login-submit" disabled={busy}>
                        {busy ? <span className="login-spinner" aria-hidden="true" /> : null}
                        {busy ? 'Signing in...' : 'Sign in'}
                    </button>

                    <p className="login-foot">Authorized users only.</p>
                </form>
            </main>
        </div>
    );
}
