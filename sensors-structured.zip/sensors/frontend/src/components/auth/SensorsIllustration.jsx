// Illustration for the login page: LoRaWAN sensor nodes sending to a gateway, which forwards to the cloud.
// Drawn as SVG (no image file needed, works offline). To use a photo instead, put it in frontend/public/ and
// replace <SensorsIllustration /> in LoginPage.jsx with an <img src="/your-photo.jpg" />.

function SensorNode({ x, label, children }) {
    return (
        <g transform={`translate(${x} 0)`}>
            {/* antenna */}
            <line x1="0" y1="352" x2="0" y2="332" stroke="#93c5fd" strokeWidth="3" strokeLinecap="round" />
            <circle cx="0" cy="328" r="5" fill="#38bdf8" />
            {/* body */}
            <rect x="-38" y="352" width="76" height="86" rx="14" fill="#ffffff" fillOpacity="0.1" stroke="#93c5fd" strokeOpacity="0.55" strokeWidth="1.5" />
            <rect x="-30" y="360" width="60" height="52" rx="9" fill="#0f2a5c" fillOpacity="0.85" />
            {children}
            <circle cx="-22" cy="426" r="3" fill="#4ade80" />
            <circle cx="-12" cy="426" r="3" fill="#38bdf8" />
            <text x="0" y="466" textAnchor="middle" fontSize="13" fill="#cbd5e1" fontFamily="inherit">{label}</text>
        </g>
    );
}

export default function SensorsIllustration() {
    return (
        <svg viewBox="0 0 640 500" role="img" aria-label="LoRaWAN sensors sending data to a gateway and the cloud" style={{ width: '100%', height: 'auto', maxHeight: '100%' }}>
            <defs>
                <linearGradient id="la-cloud" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="#bae6fd" />
                    <stop offset="1" stopColor="#38bdf8" />
                </linearGradient>
                <linearGradient id="la-gateway" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="#ffffff" />
                    <stop offset="1" stopColor="#bfdbfe" />
                </linearGradient>
            </defs>

            {/* links from every sensor to the gateway */}
            <g fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" strokeDasharray="3 9" className="la-flow">
                <path d="M80 328 C 80 250, 250 250, 300 196" />
                <path d="M200 328 C 200 270, 290 260, 308 196" />
                <path d="M320 328 L 320 198" />
                <path d="M440 328 C 440 270, 350 260, 332 196" />
                <path d="M560 328 C 560 250, 390 250, 340 196" />
            </g>

            {/* gateway to the cloud */}
            <path d="M356 118 C 420 90, 450 90, 488 84" fill="none" stroke="#7dd3fc" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 9" className="la-flow" />

            {/* radio waves around the gateway */}
            <g fill="none" stroke="#7dd3fc" strokeLinecap="round" strokeWidth="3">
                <path d="M286 104 A 40 40 0 0 1 354 104" className="la-wave la-wave-1" />
                <path d="M270 90 A 62 62 0 0 1 370 90" className="la-wave la-wave-2" />
                <path d="M254 76 A 84 84 0 0 1 386 76" className="la-wave la-wave-3" />
            </g>

            {/* gateway */}
            <g>
                <line x1="320" y1="150" x2="320" y2="112" stroke="#e0f2fe" strokeWidth="5" strokeLinecap="round" />
                <circle cx="320" cy="108" r="7" fill="#38bdf8" />
                <rect x="276" y="150" width="88" height="46" rx="12" fill="url(#la-gateway)" />
                <circle cx="298" cy="173" r="4.5" fill="#22c55e" />
                <circle cx="313" cy="173" r="4.5" fill="#0ea5e9" />
                <rect x="328" y="168" width="26" height="10" rx="5" fill="#1e3a8a" fillOpacity="0.35" />
                <text x="262" y="177" textAnchor="end" fontSize="13" fontWeight="700" fill="#e0f2fe" fontFamily="inherit" letterSpacing="2">LORAWAN</text>
                <text x="262" y="194" textAnchor="end" fontSize="13" fontWeight="700" fill="#e0f2fe" fontFamily="inherit" letterSpacing="2">GATEWAY</text>
            </g>

            {/* cloud */}
            <g>
                <path d="M470 108 a22 22 0 0 1 4-43 a30 30 0 0 1 56-6 a24 24 0 0 1 36 18 a20 20 0 0 1-4 31 z" fill="url(#la-cloud)" />
                <rect x="498" y="76" width="44" height="8" rx="4" fill="#0f2a5c" fillOpacity="0.5" />
                <rect x="498" y="90" width="44" height="8" rx="4" fill="#0f2a5c" fillOpacity="0.5" />
                <circle cx="531" cy="80" r="1.8" fill="#4ade80" />
                <circle cx="531" cy="94" r="1.8" fill="#4ade80" />
                <text x="520" y="138" textAnchor="middle" fontSize="13" fill="#cbd5e1" fontFamily="inherit">Network server</text>
            </g>

            {/* sensor nodes */}
            <SensorNode x={80} label="Temperature">
                <rect x="-4" y="368" width="8" height="26" rx="4" fill="#e2e8f0" />
                <circle cx="0" cy="398" r="8" fill="#f87171" />
                <rect x="-2" y="380" width="4" height="16" rx="2" fill="#f87171" />
            </SensorNode>
            <SensorNode x={200} label="Humidity">
                <path d="M0 367 C 12 382, 16 390, 16 396 a16 16 0 0 1 -32 0 c0 -6 4 -14 16 -29 z" fill="#38bdf8" />
                <path d="M-7 397 a8 8 0 0 0 7 8" fill="none" stroke="#e0f2fe" strokeWidth="2.2" strokeLinecap="round" />
            </SensorNode>
            <SensorNode x={320} label="Water level">
                <rect x="-16" y="368" width="32" height="38" rx="5" fill="none" stroke="#e2e8f0" strokeWidth="2" />
                <path d="M-16 388 q8 -6 16 0 t16 0 v14 a5 5 0 0 1 -5 4 h-22 a5 5 0 0 1 -5 -4 z" fill="#38bdf8" />
            </SensorNode>
            <SensorNode x={440} label="Soil moisture">
                <path d="M0 404 V 384" stroke="#4ade80" strokeWidth="3" strokeLinecap="round" />
                <path d="M0 392 C -16 392, -18 378, -18 374 C -6 374, 0 380, 0 392 z" fill="#4ade80" />
                <path d="M0 386 C 14 386, 16 374, 16 370 C 4 370, 0 376, 0 386 z" fill="#86efac" />
                <path d="M-18 406 h36" stroke="#a16207" strokeWidth="4" strokeLinecap="round" />
            </SensorNode>
            <SensorNode x={560} label="Air quality">
                <g fill="none" stroke="#e2e8f0" strokeWidth="2.4" strokeLinecap="round">
                    <path d="M-18 380 h22 a6 6 0 1 0 -6 -6" />
                    <path d="M-18 390 h30 a7 7 0 1 1 -7 7" />
                    <path d="M-18 400 h14" />
                </g>
            </SensorNode>
        </svg>
    );
}
