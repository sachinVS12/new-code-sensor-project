export default function SimpleLineChart({ data: rawData, dataKey, color, title }) {
    // keep only entries with a real numeric value (undefined/null/NaN would break the SVG)
    const data = (rawData || []).filter(d => d && Number.isFinite(Number(d[dataKey])));

    if (data.length === 0) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                No data yet. Waiting for sensor messages...
            </div>
        );
    }

    const width = 800;
    const height = 300;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    const values = data.map(d => Number(d[dataKey]));
    const minVal = Math.min(...values) - 5;
    const maxVal = Math.max(...values) + 5;
    const range = maxVal - minVal || 1;

    // with a single point there is no "i / 0" - centre it on the chart
    const xAt = (i) => padding + (data.length > 1 ? i / (data.length - 1) : 0.5) * chartWidth;
    const yAt = (v) => padding + chartHeight - ((v - minVal) / range) * chartHeight;

    const points = data.map((d, i) => `${xAt(i)},${yAt(Number(d[dataKey]))}`).join(' ');

    return (
        <div>
            <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} style={{ overflow: 'visible' }}>
                {/* Grid lines */}
                {[0, 0.25, 0.5, 0.75, 1].map(p => (
                    <line
                        key={p}
                        x1={padding}
                        y1={padding + p * chartHeight}
                        x2={width - padding}
                        y2={padding + p * chartHeight}
                        stroke="#e0e0e0"
                        strokeWidth="1"
                    />
                ))}
                {/* Y-axis labels */}
                {[0, 0.25, 0.5, 0.75, 1].map(p => {
                    const val = maxVal - p * range;
                    return (
                        <text
                            key={p}
                            x={padding - 10}
                            y={padding + p * chartHeight + 5}
                            textAnchor="end"
                            fontSize="12"
                            fill="#666"
                        >
                            {val.toFixed(1)}
                        </text>
                    );
                })}
                {/* X-axis time labels (first / last point) */}
                {data[0].time && (
                    <text x={padding} y={height - 8} fontSize="11" fill="#666" textAnchor="start">{data[0].time}</text>
                )}
                {data.length > 1 && data[data.length - 1].time && (
                    <text x={width - padding} y={height - 8} fontSize="11" fill="#666" textAnchor="end">{data[data.length - 1].time}</text>
                )}
                {/* Line */}
                <polyline
                    points={points}
                    fill="none"
                    stroke={color}
                    strokeWidth="2"
                />
                {/* Data points */}
                {data.map((d, i) => {
                    return (
                        <circle
                            key={i}
                            cx={xAt(i)}
                            cy={yAt(Number(d[dataKey]))}
                            r="3"
                            fill={color}
                        />
                    );
                })}
            </svg>
        </div>
    );
}
