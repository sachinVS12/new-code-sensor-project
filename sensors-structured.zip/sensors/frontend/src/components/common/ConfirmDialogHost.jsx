import { useEffect, useRef, useState } from 'react';

// Shows the pop-ups asked for with confirmDialog() (utils/confirm.js), one at a time.
const ICON_COLORS = {
    danger: { bg: '#fdecea', fg: '#e74c3c' },
    primary: { bg: '#e8f1fb', fg: '#1e3a8a' }
};

export default function ConfirmDialogHost() {
    const [queue, setQueue] = useState([]);
    const cancelRef = useRef(null);
    const current = queue[0] || null;

    useEffect(() => {
        const onConfirm = (e) => setQueue(q => [...q, e.detail]);
        window.addEventListener('app-confirm', onConfirm);
        return () => window.removeEventListener('app-confirm', onConfirm);
    }, []);

    const close = (answer) => {
        if (!current) return;
        current.resolve(answer);
        setQueue(q => q.slice(1));
    };

    // Esc = cancel. Focus starts on Cancel so an accidental Enter cannot delete anything.
    useEffect(() => {
        if (!current) return;
        const onKey = (e) => { if (e.key === 'Escape') close(false); };
        window.addEventListener('keydown', onKey);
        if (cancelRef.current) cancelRef.current.focus();
        return () => window.removeEventListener('keydown', onKey);
    }, [current]);

    if (!current) return null;

    const variant = current.variant === 'primary' ? 'primary' : 'danger';
    const colors = ICON_COLORS[variant];

    return (
        <div className="modal-backdrop" onClick={() => close(false)}>
            <div
                className="modal-card"
                role="alertdialog"
                aria-modal="true"
                aria-label={current.title || 'Please confirm'}
                onClick={(e) => e.stopPropagation()}
                style={{ width: '100%', maxWidth: '420px', padding: '28px 28px 24px', textAlign: 'center' }}
            >
                <div style={{
                    width: '60px', height: '60px', borderRadius: '50%', margin: '0 auto 16px', backgroundColor: colors.bg, color: colors.fg,
                    display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                    {variant === 'danger' ? (
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                            <path d="M3 6h18" />
                            <path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2" />
                            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                            <path d="M10 11v6" />
                            <path d="M14 11v6" />
                        </svg>
                    ) : (
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                            <circle cx="12" cy="12" r="10" />
                            <path d="M12 16v-4" />
                            <path d="M12 8h.01" />
                        </svg>
                    )}
                </div>
                <h3 style={{ margin: '0 0 8px', fontSize: '20px', color: '#0f172a' }}>{current.title || 'Are you sure?'}</h3>
                {current.message && (
                    <p style={{ margin: 0, fontSize: '14px', lineHeight: 1.55, color: '#64748b', whiteSpace: 'pre-line' }}>{current.message}</p>
                )}
                <div style={{ display: 'flex', justifyContent: 'center', gap: '12px', marginTop: '24px' }}>
                    <button ref={cancelRef} className="modal-btn modal-btn-cancel" onClick={() => close(false)}>
                        {current.cancelText || 'Cancel'}
                    </button>
                    <button className={`modal-btn modal-btn-${variant}`} onClick={() => close(true)}>
                        {current.confirmText || (variant === 'danger' ? 'Delete' : 'OK')}
                    </button>
                </div>
            </div>
        </div>
    );
}
