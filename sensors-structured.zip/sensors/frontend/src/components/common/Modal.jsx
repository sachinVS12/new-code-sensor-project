import { useEffect } from 'react';

// Pop-up window: blurred backdrop, rounded card, title bar with a round close button.
// Esc or a click on the backdrop closes it. Used for the Task page "Downlink data" popup.
export default function Modal({ title, subtitle, onClose, children, maxWidth = '640px' }) {
    useEffect(() => {
        const onKey = (e) => { if (e.key === 'Escape') onClose(); };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [onClose]);

    return (
        <div className="modal-backdrop" onClick={onClose}>
            <div
                className="modal-card"
                role="dialog"
                aria-modal="true"
                aria-label={title}
                onClick={(e) => e.stopPropagation()}
                style={{ width: '100%', maxWidth, maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}
            >
                <div style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px',
                    padding: '18px 22px', borderBottom: '1px solid #eef1f6', background: 'linear-gradient(180deg, #f8fafc 0%, #ffffff 100%)'
                }}>
                    <div>
                        <h3 style={{ margin: 0, fontSize: '18px', color: '#0f172a' }}>{title}</h3>
                        {subtitle && <div style={{ marginTop: '3px', fontSize: '13px', color: '#64748b' }}>{subtitle}</div>}
                    </div>
                    <button className="modal-close" onClick={onClose} title="Close" aria-label="Close">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" aria-hidden="true">
                            <line x1="5" y1="5" x2="19" y2="19" />
                            <line x1="19" y1="5" x2="5" y2="19" />
                        </svg>
                    </button>
                </div>
                <div style={{ padding: '20px 22px 22px', overflowY: 'auto' }}>{children}</div>
            </div>
        </div>
    );
}
