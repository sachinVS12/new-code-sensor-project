// Shown for any address other than "/" (for example /admin/dashboard): the app has a single page, at "/".
export default function NotFoundPage() {
    return (
        <div style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '10px',
            padding: '24px',
            textAlign: 'center',
            fontFamily: "'Segoe UI', system-ui, -apple-system, sans-serif",
            background: '#f4f6fb',
            color: '#0f172a'
        }}>
            <div style={{ fontSize: '64px', fontWeight: 800, color: '#1e3a8a', lineHeight: 1 }}>404</div>
            <h1 style={{ margin: 0, fontSize: '22px' }}>Page not found</h1>
            <p style={{ margin: 0, color: '#64748b', maxWidth: '360px' }}>
                This address does not exist. The dashboard is at the main address of this site.
            </p>
            <a
                href="/"
                style={{
                    marginTop: '14px',
                    padding: '10px 28px',
                    borderRadius: '999px',
                    background: '#1e3a8a',
                    color: '#ffffff',
                    fontWeight: 700,
                    textDecoration: 'none'
                }}
            >
                Go to the main page
            </a>
        </div>
    );
}
