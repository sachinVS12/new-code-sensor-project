import { useEffect, useRef, useState } from 'react';

// Shows the toast notifications sent with toast.success / error / warning / info (utils/toast.js).
// Top-right, below the navbar. Each one closes by itself, or when clicked on the x.

const COLORS = {
    success: { bar: '#2e7d32', bg: '#e8f5e9', text: '#1b5e20', icon: '✓' },
    error: { bar: '#c62828', bg: '#fdecea', text: '#b71c1c', icon: '!' },
    warning: { bar: '#ef6c00', bg: '#fff4e5', text: '#8a4b00', icon: '!' },
    info: { bar: '#1565c0', bg: '#e8f1fb', text: '#0d47a1', icon: 'i' }
};

const MAX_VISIBLE = 5;

export default function ToastContainer() {
    const [items, setItems] = useState([]);
    const timers = useRef({});

    const remove = (id) => {
        clearTimeout(timers.current[id]);
        delete timers.current[id];
        setItems(list => list.filter(t => t.id !== id));
    };

    useEffect(() => {
        const onToast = (e) => {
            const t = e.detail;
            setItems(list => [...list, t].slice(-MAX_VISIBLE));
            const ms = t.duration ?? (t.type === 'error' ? 7000 : 4500);
            timers.current[t.id] = setTimeout(() => remove(t.id), ms);
        };
        window.addEventListener('app-toast', onToast);
        return () => {
            window.removeEventListener('app-toast', onToast);
            Object.values(timers.current).forEach(clearTimeout);
        };
    }, []);

    if (items.length === 0) return null;

    return (
        <div style={{ position: 'fixed', top: '72px', right: '20px', zIndex: 2000, display: 'flex', flexDirection: 'column', gap: '10px', width: '360px', maxWidth: 'calc(100vw - 40px)' }}>
            {items.map(t => {
                const c = COLORS[t.type] || COLORS.info;
                return (
                    <div key={t.id} role={t.type === 'error' ? 'alert' : 'status'} className="toast-item" style={{
                        display: 'flex', alignItems: 'flex-start', gap: '10px', padding: '12px 14px',
                        backgroundColor: c.bg, color: c.text, borderLeft: `5px solid ${c.bar}`, borderRadius: '6px',
                        boxShadow: '0 6px 18px rgba(15, 23, 42, 0.18)', fontSize: '14px', lineHeight: 1.4
                    }}>
                        <span style={{
                            flexShrink: 0, width: '20px', height: '20px', borderRadius: '50%', backgroundColor: c.bar, color: 'white',
                            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 700, marginTop: '1px'
                        }}>{c.icon}</span>
                        <div style={{ flex: 1, whiteSpace: 'pre-line', wordBreak: 'break-word' }}>
                            {t.message}
                            {t.action && (
                                <button
                                    onClick={() => { t.action.onClick && t.action.onClick(); remove(t.id); }}
                                    style={{ display: 'block', marginTop: '6px', padding: 0, background: 'none', border: 'none', color: c.bar, cursor: 'pointer', textDecoration: 'underline', fontSize: '13px', fontWeight: 600 }}
                                >{t.action.label}</button>
                            )}
                        </div>
                        <button
                            onClick={() => remove(t.id)}
                            aria-label="Close"
                            style={{ flexShrink: 0, background: 'none', border: 'none', color: c.text, cursor: 'pointer', fontSize: '18px', lineHeight: 1, padding: 0, opacity: 0.7 }}
                        >×</button>
                    </div>
                );
            })}
        </div>
    );
}
