import { useEffect, useRef, useState } from 'react';

// Shows the toast notifications sent with toast.success / error / warning / info (utils/toast.js).
// White card, coloured icon on the left, grey x on the right and a coloured bar at the bottom
// that runs out when the toast closes. Top-right, below the navbar.

const COLORS = {
    success: '#2db742',
    error: '#e74c3c',
    warning: '#f5b400',
    info: '#2196f3'
};

const MAX_VISIBLE = 5;

function ToastIcon({ type }) {
    const color = COLORS[type] || COLORS.info;
    if (type === 'warning') {
        return (
            <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 2.6c.5 0 1 .3 1.3.8l9 15.6c.6 1-.1 2.3-1.3 2.3H3c-1.2 0-1.9-1.3-1.3-2.3l9-15.6c.3-.5.8-.8 1.3-.8z" fill={color} />
                <rect x="11" y="8.5" width="2" height="6.5" rx="1" fill="#fff" />
                <circle cx="12" cy="17.8" r="1.2" fill="#fff" />
            </svg>
        );
    }
    return (
        <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="12" cy="12" r="11" fill={color} />
            {type === 'success' && <path d="M7 12.5l3.3 3.3L17 9" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />}
            {type === 'error' && (
                <>
                    <rect x="11" y="6" width="2" height="7" rx="1" fill="#fff" />
                    <circle cx="12" cy="16.6" r="1.3" fill="#fff" />
                </>
            )}
            {type !== 'success' && type !== 'error' && (
                <>
                    <circle cx="12" cy="7.4" r="1.3" fill="#fff" />
                    <rect x="11" y="10" width="2" height="7.5" rx="1" fill="#fff" />
                </>
            )}
        </svg>
    );
}

export default function ToastContainer() {
    const [items, setItems] = useState([]);
    const timers = useRef({});

    const remove = (id) => {
        clearTimeout(timers.current[id]);
        delete timers.current[id];
        setItems(list => list.filter(t => t.id !== id));
    };

    useEffect(() => {
        const onToast = (e) => {
            const ms = e.detail.duration ?? (e.detail.type === 'error' ? 7000 : 4500);
            const t = { ...e.detail, ms };
            setItems(list => [...list, t].slice(-MAX_VISIBLE));
            timers.current[t.id] = setTimeout(() => remove(t.id), ms);
        };
        window.addEventListener('app-toast', onToast);
        return () => {
            window.removeEventListener('app-toast', onToast);
            Object.values(timers.current).forEach(clearTimeout);
        };
    }, []);

    if (items.length === 0) return null;

    return (
        <div style={{ position: 'fixed', top: '72px', right: '20px', zIndex: 2100, display: 'flex', flexDirection: 'column', gap: '12px', width: '360px', maxWidth: 'calc(100vw - 40px)' }}>
            {items.map(t => {
                const color = COLORS[t.type] || COLORS.info;
                return (
                    <div key={t.id} role={t.type === 'error' ? 'alert' : 'status'} className="toast-item" style={{
                        position: 'relative', display: 'flex', alignItems: 'center', gap: '14px',
                        padding: '18px 40px 20px 16px', backgroundColor: '#ffffff', color: '#333', borderRadius: '6px',
                        boxShadow: '0 4px 14px rgba(15, 23, 42, 0.22)', fontSize: '15px', lineHeight: 1.4, overflow: 'hidden'
                    }}>
                        <span style={{ flexShrink: 0, display: 'flex' }}><ToastIcon type={t.type} /></span>
                        <div style={{ flex: 1, whiteSpace: 'pre-line', wordBreak: 'break-word' }}>
                            {t.message}
                            {t.action && (
                                <button
                                    onClick={() => { t.action.onClick && t.action.onClick(); remove(t.id); }}
                                    style={{ display: 'block', marginTop: '6px', padding: 0, background: 'none', border: 'none', color, cursor: 'pointer', textDecoration: 'underline', fontSize: '13px', fontWeight: 600 }}
                                >{t.action.label}</button>
                            )}
                        </div>
                        <button
                            onClick={() => remove(t.id)}
                            aria-label="Close"
                            style={{ position: 'absolute', top: '6px', right: '10px', background: 'none', border: 'none', color: '#9aa0a6', cursor: 'pointer', fontSize: '20px', lineHeight: 1, padding: '2px 4px' }}
                        >×</button>
                        <div className="toast-progress" style={{ backgroundColor: color, animationDuration: `${t.ms}ms` }} />
                    </div>
                );
            })}
        </div>
    );
}
