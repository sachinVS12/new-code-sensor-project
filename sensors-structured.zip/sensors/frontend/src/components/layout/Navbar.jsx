// Navbar Component
// On phones the sidebar is a slide-in menu, opened with the round menu button on the left.
export default function Navbar({ isConnected, isCollapsed, isMobile = false, onMenuClick }) {
    const navbarStyle = {
        height: '60px',
        backgroundColor: '#34495e',
        color: 'white',
        left: isMobile ? '0' : (isCollapsed ? '60px' : '250px'),
        right: '0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '10px',
        padding: isMobile ? '0 12px' : '0 30px',
        position: 'fixed',
        top: 0,
        zIndex: 1000,
        transition: 'left 0.3s ease'
    };

    return (
        <div style={navbarStyle}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', minWidth: 0 }}>
                {isMobile && (
                    <button
                        type="button"
                        onClick={onMenuClick}
                        aria-label="Open menu"
                        title="Menu"
                        style={{ flexShrink: 0, width: '40px', height: '40px', borderRadius: '10px', border: 'none', backgroundColor: 'rgba(255,255,255,0.12)', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}
                    >
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
                            <line x1="4" y1="7" x2="20" y2="7" />
                            <line x1="4" y1="12" x2="20" y2="12" />
                            <line x1="4" y1="17" x2="20" y2="17" />
                        </svg>
                    </button>
                )}
                <div style={{ fontSize: isMobile ? '15px' : '18px', fontWeight: 'bold', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {isMobile ? 'Sensor Monitoring' : 'Sensor Monitoring System'}
                </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
                {!isMobile && <span style={{ fontSize: '14px' }}>Status:</span>}
                <span style={{
                    padding: isMobile ? '4px 10px' : '5px 15px',
                    borderRadius: '20px',
                    backgroundColor: isConnected ? '#27ae60' : '#e74c3c',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    whiteSpace: 'nowrap'
                }}>
                    {isConnected ? '● Connected' : '○ Disconnected'}
                </span>
            </div>
        </div>
    );
}
