import { useState } from 'react';

// Sidebar Component - light sidebar with logo header, MENU label, line icons,
// a dark-blue pill for the active page and a round collapse button on the edge.

const SIDEBAR_ICONS = {
    // radio tower style mark used in the logo
    radio: (
        <>
            <circle cx="12" cy="12" r="2" />
            <path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14" />
        </>
    ),
    home: (
        <>
            <path d="M3 10.5 12 3l9 7.5" />
            <path d="M5 9v12h14V9" />
            <path d="M10 21v-6h4v6" />
        </>
    ),
    gateway: (
        <>
            <rect x="16" y="16" width="6" height="6" rx="1" />
            <rect x="2" y="16" width="6" height="6" rx="1" />
            <rect x="9" y="2" width="6" height="6" rx="1" />
            <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
            <path d="M12 12V8" />
        </>
    ),
    device: (
        <>
            <rect x="3" y="3" width="18" height="18" rx="3" />
            <path d="M12 8v8" />
            <path d="M8 12h8" />
        </>
    ),
    profile: (
        <>
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <path d="M14 2v6h6" />
            <path d="M8 13h8" />
            <path d="M8 17h5" />
        </>
    ),
    app: (
        <>
            <rect x="3" y="3" width="7" height="7" rx="1.5" />
            <rect x="14" y="3" width="7" height="7" rx="1.5" />
            <rect x="3" y="14" width="7" height="7" rx="1.5" />
            <rect x="14" y="14" width="7" height="7" rx="1.5" />
        </>
    ),
    table: (
        <>
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <path d="M3 9h18" />
            <path d="M3 15h18" />
            <path d="M12 3v18" />
        </>
    ),
    chart: (
        <>
            <path d="M3 3v18h18" />
            <path d="m19 9-5 5-4-4-3 3" />
        </>
    ),
    downlink: (
        <>
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v8" />
            <path d="m8 12 4 4 4-4" />
        </>
    ),
    task: (
        <>
            <rect x="8" y="2" width="8" height="4" rx="1" />
            <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
            <path d="M12 11h4" />
            <path d="M12 16h4" />
            <path d="M8 11h.01" />
            <path d="M8 16h.01" />
        </>
    ),
    left: <path d="m15 18-6-6 6-6" />,
    right: <path d="m9 18 6-6-6-6" />
};

function SidebarIcon({ name, size = 20 }) {
    return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
            strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flexShrink: 0 }}>
            {SIDEBAR_ICONS[name]}
        </svg>
    );
}

export default function Sidebar({ currentPage, setCurrentPage, isCollapsed, setIsCollapsed, isMobile = false, menuOpen = false, onClose }) {
    // on phones the sidebar is always full width and slides in over the page
    const collapsed = isMobile ? false : isCollapsed;
    const [hovered, setHovered] = useState(null);

    const menu = [
        { key: 'dashboard', label: 'Dashboard', icon: 'home' },
        { key: 'gateway', label: 'Gateway', icon: 'gateway' },
        { key: 'node-creation', label: 'Device Creation', icon: 'device' },
        { key: 'device-profile', label: 'Device Profile', icon: 'profile' },
        { key: 'application', label: 'Application', icon: 'app' },
        { key: 'tabular', label: 'Tabular View', icon: 'table' },
        { key: 'graph', label: 'Graph View', icon: 'chart' },
        { key: 'downlink', label: 'Downlink', icon: 'downlink' },
        { key: 'task', label: 'Task', icon: 'task' }
    ];

    const sidebarStyle = {
        width: collapsed ? '60px' : '250px',
        height: '100vh',
        backgroundColor: '#ffffff',
        borderRight: '1px solid #e8ecf3',
        boxShadow: '2px 0 12px rgba(15, 23, 42, 0.04)',
        position: 'fixed',
        left: 0,
        top: 0,
        zIndex: 1100,
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.3s ease'
    };

    const headerStyle = {
        display: 'flex',
        alignItems: 'center',
        justifyContent: collapsed ? 'center' : 'flex-start',
        gap: '12px',
        padding: collapsed ? '20px 0 18px' : '20px 18px 18px',
        borderBottom: '1px solid #eef1f6'
    };

    const logoStyle = {
        width: '42px',
        height: '42px',
        borderRadius: '12px',
        backgroundColor: '#1e3a8a',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        boxShadow: '0 6px 14px rgba(30, 58, 138, 0.28)'
    };

    const collapseButtonStyle = {
        position: 'absolute',
        right: '-14px',
        top: '64px',
        width: '28px',
        height: '28px',
        borderRadius: '50%',
        backgroundColor: 'white',
        border: '1px solid #e2e8f0',
        boxShadow: '0 2px 6px rgba(15, 23, 42, 0.12)',
        color: '#1e293b',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 0
    };

    const menuLabelStyle = {
        padding: '22px 24px 10px',
        fontSize: '12px',
        fontWeight: 700,
        letterSpacing: '1.5px',
        color: '#64748b'
    };

    const itemStyle = (key) => {
        const active = currentPage === key;
        return {
            display: 'flex',
            alignItems: 'center',
            justifyContent: collapsed ? 'center' : 'flex-start',
            gap: '14px',
            width: collapsed ? '42px' : '100%',
            height: '46px',
            margin: collapsed ? '0 auto' : 0,
            padding: collapsed ? 0 : '0 18px',
            border: 'none',
            borderRadius: '999px',
            cursor: 'pointer',
            fontFamily: 'inherit',
            fontSize: '15px',
            fontWeight: active ? 700 : 500,
            textAlign: 'left',
            whiteSpace: 'nowrap',
            color: active ? '#ffffff' : '#475569',
            backgroundColor: active ? '#1e3a8a' : (hovered === key ? '#f1f5f9' : 'transparent'),
            boxShadow: active ? '0 6px 14px rgba(30, 58, 138, 0.25)' : 'none',
            transition: 'background-color 0.2s, color 0.2s'
        };
    };

    const mobileSidebarStyle = {
        ...sidebarStyle,
        width: '250px',
        transform: menuOpen ? 'translateX(0)' : 'translateX(-100%)',
        boxShadow: menuOpen ? '6px 0 28px rgba(15, 23, 42, 0.3)' : 'none',
        transition: 'transform 0.25s ease'
    };

    return (
        <>
        {isMobile && menuOpen && (
            <div onClick={onClose} style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(15, 23, 42, 0.45)', zIndex: 1090 }} />
        )}
        <div style={isMobile ? mobileSidebarStyle : sidebarStyle}>
            <div style={headerStyle}>
                <div style={logoStyle}>
                    <SidebarIcon name="radio" size={22} />
                </div>
                {!collapsed && (
                    <div style={{ lineHeight: 1.2, whiteSpace: 'nowrap' }}>
                        <div style={{ fontSize: '19px', fontWeight: 800, color: '#0f172a' }}>LoRaWAN</div>
                        <div style={{ fontSize: '11px', fontWeight: 500, letterSpacing: '1.8px', color: '#64748b', marginTop: '3px' }}>DASHBOARD</div>
                    </div>
                )}
            </div>

            {!isMobile && (
                <button
                    type="button"
                    style={collapseButtonStyle}
                    onClick={() => setIsCollapsed(!collapsed)}
                    title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                    aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                >
                    <SidebarIcon name={collapsed ? 'right' : 'left'} size={16} />
                </button>
            )}

            {collapsed
                ? <div style={{ height: '18px' }} />
                : <div style={menuLabelStyle}>MENU</div>}

            <nav style={{ display: 'flex', flexDirection: 'column', gap: '6px', padding: collapsed ? '0' : '0 14px', overflowY: 'auto' }}>
                {menu.map(item => (
                    <button
                        key={item.key}
                        type="button"
                        style={itemStyle(item.key)}
                        onClick={() => setCurrentPage(item.key)}
                        onMouseEnter={() => setHovered(item.key)}
                        onMouseLeave={() => setHovered(null)}
                        title={item.label}
                    >
                        <SidebarIcon name={item.icon} />
                        {!collapsed && <span>{item.label}</span>}
                    </button>
                ))}
            </nav>
        </div>
        </>
    );
}
