import Modal from '../common/Modal';
import { exportPayloadEntryXlsx } from '../../utils/exportPayloadHistory';
import { toast } from '../../utils/toast';

export const PREVIEW_ROWS = 20; // how many samples the popup lists; the Excel file has all of them

// small line preview of the samples (at most ~300 points are drawn)
function MiniChart({ samples }) {
    const W = 600, H = 120, PAD = 8;
    const step = Math.max(1, Math.ceil(samples.length / 300));
    const pts = samples.filter((_, i) => i % step === 0);
    let lo = Math.min(...pts), hi = Math.max(...pts);
    if (lo === hi) { lo -= 1; hi += 1; } // flat line: avoid dividing by zero
    const x = (i) => (pts.length === 1 ? W / 2 : PAD + (i * (W - 2 * PAD)) / (pts.length - 1));
    const y = (v) => H - PAD - ((v - lo) / (hi - lo)) * (H - 2 * PAD);
    return (
        <svg data-testid="mini-chart" viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: '120px', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px' }} role="img" aria-label="Sample preview chart">
            {pts.length === 1
                ? <circle cx={x(0)} cy={y(pts[0])} r="3.5" fill="#1e3a8a" />
                : <polyline fill="none" stroke="#1e3a8a" strokeWidth="1.6" strokeLinejoin="round" points={pts.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ')} />}
        </svg>
    );
}

const stat = (label, value) => (
    <div style={{ padding: '8px 12px', backgroundColor: '#f1f5f9', borderRadius: '8px', minWidth: '84px' }}>
        <div style={{ fontSize: '11px', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{label}</div>
        <div style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>{value === null || value === undefined || value === '' ? '-' : value}</div>
    </div>
);

// Popup opened by the eye icon of the Payload History table: a preview of one entry + a button that downloads it as Excel.
// `row` is a snapshot taken when the icon was clicked, so the popup does not change while new uplinks arrive.
export default function PayloadEntryPreviewModal({ row, device, onClose }) {
    const handleDownload = () => {
        try {
            const fileName = exportPayloadEntryXlsx(row, device);
            if (fileName) toast.success(`Downloaded ${fileName}`);
        } catch (err) {
            console.error('Excel export failed:', err);
            toast.error('Could not create the Excel file');
        }
    };

    const shown = row.samples.slice(0, PREVIEW_ROWS);
    const when = row.when ? row.when.toLocaleString() : row.time;

    return (
        <Modal title={`Sample preview - entry #${row.no}`} subtitle={`${device?.deviceName || ''} | ${when}`} onClose={onClose} maxWidth="640px">
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '16px' }}>
                {stat('Type', row.type)}
                {row.chunks && stat('Chunks', row.chunks)}
                {stat('Samples', row.sampleCount)}
                {stat('Min', row.min)}
                {stat('Max', row.max)}
                {stat('Average', row.avg)}
                {stat('Battery', row.battery)}
            </div>

            {row.samples.length === 0 ? (
                <p style={{ color: '#999', textAlign: 'center', padding: '24px 0', margin: 0 }}>No samples in this entry.</p>
            ) : (
                <>
                    <MiniChart samples={row.samples} />

                    {row.chunkList.length > 0 && (
                        <>
                            <div style={{ margin: '16px 0 8px', fontSize: '13px', color: '#64748b' }}>
                                {row.type === 'Complete'
                                    ? `This entry was built from ${row.chunkList.length} chunk${row.chunkList.length === 1 ? '' : 's'}.`
                                    : 'The chunk of this entry (its dataset is not complete yet).'}
                            </div>
                            <div style={{ maxHeight: '200px', overflow: 'auto', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                                <table data-testid="chunk-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
                                    <thead>
                                        <tr>
                                            {['Chunk #', 'Received at', 'Samples', 'Min', 'Max'].map((h) => (
                                                <th key={h} style={{ backgroundColor: '#34495e', color: 'white', padding: '8px 12px', textAlign: 'left', position: 'sticky', top: 0 }}>{h}</th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {row.chunkList.map((c, i) => (
                                            <tr key={c.index} style={{ backgroundColor: i % 2 ? '#f8f9fa' : 'white' }}>
                                                <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1' }}>{c.index + 1}</td>
                                                <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1', whiteSpace: 'nowrap' }}>{c.receivedAt ? new Date(c.receivedAt).toLocaleTimeString() : '-'}</td>
                                                <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1' }}>{c.sampleCount}</td>
                                                <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1' }}>{c.samples.length ? Math.min(...c.samples) : '-'}</td>
                                                <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1' }}>{c.samples.length ? Math.max(...c.samples) : '-'}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot>
                                        <tr data-testid="chunk-total" style={{ backgroundColor: '#e8f0fe', fontWeight: 700 }}>
                                            <td style={{ padding: '8px 12px', position: 'sticky', bottom: 0, backgroundColor: '#e8f0fe' }}>Total: {row.chunkList.length}</td>
                                            <td style={{ padding: '8px 12px', position: 'sticky', bottom: 0, backgroundColor: '#e8f0fe' }}></td>
                                            <td style={{ padding: '8px 12px', position: 'sticky', bottom: 0, backgroundColor: '#e8f0fe' }}>{row.chunkList.reduce((n, c) => n + c.sampleCount, 0)}</td>
                                            <td style={{ padding: '8px 12px', position: 'sticky', bottom: 0, backgroundColor: '#e8f0fe' }}></td>
                                            <td style={{ padding: '8px 12px', position: 'sticky', bottom: 0, backgroundColor: '#e8f0fe' }}></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </>
                    )}
                    <div style={{ margin: '16px 0 8px', fontSize: '13px', color: '#64748b' }}>
                        Showing the first {shown.length} of {row.sampleCount} samples{row.sampleCount > shown.length
                            ? `. The Excel file has ${row.chunkList.length > 1 ? `all ${row.chunkList.length} chunks with all their values` : 'all of them'}.`
                            : '.'}
                    </div>
                    <div style={{ maxHeight: '220px', overflow: 'auto', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                        <table data-testid="preview-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    {['Sample #', 'Value'].map((h) => (
                                        <th key={h} style={{ backgroundColor: '#34495e', color: 'white', padding: '8px 12px', textAlign: 'left', position: 'sticky', top: 0 }}>{h}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {shown.map((v, i) => (
                                    <tr key={i} style={{ backgroundColor: i % 2 ? '#f8f9fa' : 'white' }}>
                                        <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1', color: '#64748b' }}>{i + 1}</td>
                                        <td style={{ padding: '6px 12px', borderBottom: '1px solid #ecf0f1', fontFamily: 'monospace' }}>{v}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '18px' }}>
                <button onClick={onClose} style={{ padding: '8px 18px', backgroundColor: 'white', color: '#334155', border: '1px solid #cbd5e1', borderRadius: '6px', cursor: 'pointer', fontSize: '14px', fontWeight: 'bold' }}>
                    Close
                </button>
                <button
                    onClick={handleDownload}
                    aria-label="Download Excel file"
                    style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 18px', backgroundColor: '#188038', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '14px', fontWeight: 'bold' }}
                >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                        <polyline points="7 10 12 15 17 10" />
                        <line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                    Download
                </button>
            </div>
        </Modal>
    );
}
