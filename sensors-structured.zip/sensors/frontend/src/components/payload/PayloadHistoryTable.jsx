import { useState } from 'react';
import { payloadHistoryRows } from '../../utils/payload';

const thStyle = { backgroundColor: '#34495e', color: 'white', padding: '12px', textAlign: 'left', fontWeight: 'bold', borderBottom: '2px solid #2c3e50', whiteSpace: 'nowrap', position: 'sticky', top: 0 };
const tdStyle = { padding: '10px 12px', borderBottom: '1px solid #ecf0f1', color: '#333', whiteSpace: 'nowrap' };
const badge = (bg, color) => ({ display: 'inline-block', padding: '2px 10px', borderRadius: '999px', fontSize: '12px', fontWeight: 700, backgroundColor: bg, color });

const fmt = (v) => (v === null || v === undefined || v === '' ? '-' : v);
const fmtWhen = (r) => (r.when ? r.when.toLocaleString() : r.time || '-');

// Table of every entry in a device's Payload History (newest first). Click a row to see its sample values.
export default function PayloadHistoryTable({ history = [] }) {
    const [openNo, setOpenNo] = useState(null);
    const rows = payloadHistoryRows(history).reverse();
    const complete = rows.filter((r) => r.type === 'Complete').length;
    const totalSamples = rows.reduce((sum, r) => sum + r.sampleCount, 0);

    return (
        <div>
            <div style={{ fontSize: '13px', color: '#666', marginBottom: '10px' }}>
                {rows.length} entries ({complete} complete, {rows.length - complete} chunks) | Total samples: {totalSamples} | Newest first. Click a row to see its samples.
            </div>
            <div style={{ overflow: 'auto', maxHeight: '60vh', border: '1px solid #ecf0f1', borderRadius: '6px' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr>
                            {['#', 'Date & time', 'Type', 'Chunks', 'Samples', 'Min', 'Max', 'Average', 'Battery'].map((h) => <th key={h} style={thStyle}>{h}</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((r, i) => {
                            const isOpen = openNo === r.no;
                            return [
                                <tr
                                    key={r.no}
                                    onClick={() => setOpenNo(isOpen ? null : r.no)}
                                    style={{ cursor: 'pointer', backgroundColor: isOpen ? '#e8f0fe' : i % 2 ? '#f8f9fa' : 'white' }}
                                    title="Show / hide the samples of this entry"
                                >
                                    <td style={tdStyle}>{r.no}</td>
                                    <td style={tdStyle}>{fmtWhen(r)}</td>
                                    <td style={tdStyle}>
                                        <span style={r.type === 'Complete' ? badge('#e6f4ea', '#188038') : badge('#fff4e5', '#b06000')}>{r.type}</span>
                                    </td>
                                    <td style={tdStyle}>{fmt(r.chunks)}</td>
                                    <td style={tdStyle}>{r.sampleCount}</td>
                                    <td style={tdStyle}>{fmt(r.min)}</td>
                                    <td style={tdStyle}>{fmt(r.max)}</td>
                                    <td style={tdStyle}>{fmt(r.avg)}</td>
                                    <td style={tdStyle}>{fmt(r.battery)}</td>
                                </tr>,
                                isOpen && (
                                    <tr key={`${r.no}-samples`}>
                                        <td colSpan={9} style={{ padding: '12px', backgroundColor: '#f4f7fb', borderBottom: '1px solid #ecf0f1' }}>
                                            <div data-testid="samples-box" style={{ maxHeight: '180px', overflow: 'auto', display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                                                {r.samples.length === 0 ? <span style={{ color: '#999' }}>No samples in this entry.</span> : r.samples.map((v, k) => (
                                                    <span key={k} style={{ padding: '2px 8px', backgroundColor: 'white', border: '1px solid #dbe3ee', borderRadius: '4px', fontSize: '12px', fontFamily: 'monospace' }}>
                                                        <span style={{ color: '#999' }}>{k + 1}:</span> {v}
                                                    </span>
                                                ))}
                                            </div>
                                        </td>
                                    </tr>
                                )
                            ];
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
