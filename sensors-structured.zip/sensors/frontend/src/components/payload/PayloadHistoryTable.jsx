import { useState } from 'react';
import { payloadHistoryRows } from '../../utils/payload';
import PayloadEntryPreviewModal from './PayloadEntryPreviewModal';

const thStyle = { backgroundColor: '#34495e', color: 'white', padding: '12px', textAlign: 'left', fontWeight: 'bold', borderBottom: '2px solid #2c3e50', whiteSpace: 'nowrap', position: 'sticky', top: 0 };
const tdStyle = { padding: '10px 12px', borderBottom: '1px solid #ecf0f1', color: '#333', whiteSpace: 'nowrap' };
const badge = (bg, color) => ({ display: 'inline-block', padding: '2px 10px', borderRadius: '999px', fontSize: '12px', fontWeight: 700, backgroundColor: bg, color });

const fmt = (v) => (v === null || v === undefined || v === '' ? '-' : v);
const fmtWhen = (r) => (r.when ? r.when.toLocaleString() : r.time || '-');

// Table of every entry in a device's Payload History (newest first).
// The eye icon of a row opens a popup with a preview of that entry's samples and a Download (Excel) button.
export default function PayloadHistoryTable({ history = [], device }) {
    const [preview, setPreview] = useState(null); // snapshot of the row being previewed
    const rows = payloadHistoryRows(history).reverse();
    const complete = rows.filter((r) => r.type === 'Complete').length;
    const totalSamples = rows.reduce((sum, r) => sum + r.sampleCount, 0);

    return (
        <div>
            <div style={{ fontSize: '13px', color: '#666', marginBottom: '10px' }}>
                {rows.length} entries ({complete} complete, {rows.length - complete} chunks) | Total samples: {totalSamples} | Newest first. Click the eye icon to preview an entry.
            </div>
            <div style={{ overflow: 'auto', maxHeight: '60vh', border: '1px solid #ecf0f1', borderRadius: '6px' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr>
                            {['#', 'Date & time', 'Type', 'Chunks', 'Samples', 'Min', 'Max', 'Average', 'Battery', 'Preview'].map((h) => <th key={h} style={{ ...thStyle, textAlign: h === 'Preview' ? 'center' : 'left' }}>{h}</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((r, i) => (
                            <tr key={r.no} style={{ backgroundColor: i % 2 ? '#f8f9fa' : 'white' }}>
                                <td style={tdStyle}>{r.no}</td>
                                <td style={tdStyle}>{fmtWhen(r)}</td>
                                <td style={tdStyle}>
                                    <span style={r.type === 'Complete' ? badge('#e6f4ea', '#188038') : badge('#fff4e5', '#b06000')}>{r.type}</span>
                                </td>
                                <td style={tdStyle}>{fmt(r.chunks)}</td>
                                <td style={tdStyle}>{r.sampleCount}</td>
                                <td style={tdStyle}>{fmt(r.min)}</td>
                                <td style={tdStyle}>{fmt(r.max)}</td>
                                <td style={tdStyle}>{fmt(r.avg)}</td>
                                <td style={tdStyle}>{fmt(r.battery)}</td>
                                <td style={{ ...tdStyle, textAlign: 'center' }}>
                                    <button
                                        onClick={() => setPreview(r)}
                                        title={`Preview the samples of entry ${r.no}`}
                                        aria-label={`Preview entry ${r.no}`}
                                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', borderRadius: '4px', lineHeight: 0 }}
                                        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#e8f0fe')}
                                        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                                    >
                                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1a73e8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                            <circle cx="12" cy="12" r="3" />
                                        </svg>
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {preview && <PayloadEntryPreviewModal row={preview} device={device} onClose={() => setPreview(null)} />}
        </div>
    );
}
