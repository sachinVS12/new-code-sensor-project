import { useEffect, useState } from 'react';

// Is ChirpStack sync on in the backend? Also gives the device profiles that can be chosen.
export default function useChirpstackStatus() {
    const [status, setStatus] = useState({ enabled: false, defaultDeviceProfileId: '', deviceProfiles: [], regions: [] });

    useEffect(() => {
        fetch('/api/chirpstack/status')
            .then((r) => r.json())
            .then((s) => setStatus({ deviceProfiles: [], regions: [], defaultDeviceProfileId: '', ...s }))
            .catch(() => {});
    }, []);

    return status;
}
