import { useEffect, useState } from 'react';

// true on phones and small tablets (screen 768 px wide or less). Follows window resizes / rotation.
const QUERY = '(max-width: 768px)';

export default function useIsMobile() {
    const [isMobile, setIsMobile] = useState(() => window.matchMedia(QUERY).matches);

    useEffect(() => {
        const mq = window.matchMedia(QUERY);
        const onChange = () => setIsMobile(mq.matches);
        onChange();
        mq.addEventListener('change', onChange);
        return () => mq.removeEventListener('change', onChange);
    }, []);

    return isMobile;
}
