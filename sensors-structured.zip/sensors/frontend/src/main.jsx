import ReactDOM from 'react-dom/client';
import AuthGate from './components/auth/AuthGate';
import { installAuthFetch } from './utils/authFetch';
import './styles/global.css';

installAuthFetch();

ReactDOM.createRoot(document.getElementById('root')).render(<AuthGate />);
