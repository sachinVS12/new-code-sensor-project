import ReactDOM from 'react-dom/client';
import AuthGate from './components/auth/AuthGate';
import NotFoundPage from './components/common/NotFoundPage';
import { installAuthFetch } from './utils/authFetch';
import './styles/global.css';

// The site is a single page at "/". Any other address (e.g. /admin/dashboard) is "not found",
// so it never shows the dashboard or the login page.
const isHome = window.location.pathname === '/' || window.location.pathname === '/index.html';

if (isHome) installAuthFetch();

ReactDOM.createRoot(document.getElementById('root')).render(isHome ? <AuthGate /> : <NotFoundPage />);
