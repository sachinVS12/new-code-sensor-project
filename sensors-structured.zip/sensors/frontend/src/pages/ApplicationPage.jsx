import { useEffect, useState } from 'react';
import { toast } from '../utils/toast';
import Modal from '../components/common/Modal';
import { confirmDialog } from '../utils/confirm';

// Application page - two tabs: "Application Creation" (form) and "Application List".
// Applications live in ChirpStack (a device belongs to one application), so both tabs talk to
// ChirpStack through the backend (/api/applications). The Application ID shown in the list is the
// one to enter as "Application ID" in Device Creation.

const emptyForm = { name: '', description: '' };

const formatTime = (iso) => {
    if (!iso) return '-';
    const d = new Date(iso);
    return isNaN(d) ? '-' : d.toLocaleString();
};

export default function ApplicationPage({ isCollapsed, onOpenDeviceCreation }) {
    const [tab, setTab] = useState('create');

    // ---- Creation tab ----
    const [form, setForm] = useState(emptyForm);
    const [saving, setSaving] = useState(false);
    const [editingId, setEditingId] = useState(null);   // null = creating a new application

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.name.trim()) {
            toast.error('Name is required');
            return;
        }
        setSaving(true);
        try {
            const res = await fetch(editingId ? `/api/applications/${editingId}` : '/api/applications', {
                method: editingId ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: form.name.trim(), description: form.description.trim() })
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || `Failed to ${editingId ? 'update' : 'create'} application`);
            if (editingId) {
                toast.success(`Application "${data.name}" updated in ChirpStack.`);
                setEditingId(null);
                setForm(emptyForm);
                setTab('list');   // back to the list, which shows the change
            } else {
                toast.success(`Application "${data.name}" created in ChirpStack.`);
                setForm(emptyForm);
            }
        } catch (err) {
            toast.error(err.message);
        } finally {
            setSaving(false);
        }
    };

    // ---- List tab ----
    const [applications, setApplications] = useState([]);
    const [devicesModalApp, setDevicesModalApp] = useState(null);   // application whose devices are shown in the pop-up
    const [devices, setDevices] = useState([]);   // devices of the dashboard, grouped by application in the Device column
    const [loading, setLoading] = useState(false);
    const [search, setSearch] = useState('');

    const loadApplications = async () => {
        setLoading(true);
        try {
            const [res, devRes] = await Promise.all([
                fetch('/api/applications'),
                fetch('/api/nodes').catch(() => null)
            ]);
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to load applications');
            setApplications(Array.isArray(data) ? data : []);
            const devData = devRes && devRes.ok ? await devRes.json().catch(() => []) : [];
            setDevices(Array.isArray(devData) ? devData : []);
        } catch (err) {
            setApplications([]);
            setDevices([]);
            toast.error(err.message);
        } finally {
            setLoading(false);
        }
    };

    // reload every time the list tab is opened, so an application just created shows up
    useEffect(() => { if (tab === 'list') loadApplications(); }, [tab]);

    const copyId = async (id) => {
        try {
            await navigator.clipboard.writeText(id);
            toast.success('Application ID copied');
        } catch {
            toast.error('Could not copy. Select the ID and copy it by hand.');
        }
    };

    const cancelEdit = () => {
        setEditingId(null);
        setForm(emptyForm);
        setTab('list');
    };

    // switching to the plain "creation" tab while editing starts a fresh form
    const openCreateTab = () => {
        if (editingId) { setEditingId(null); setForm(emptyForm); }
        setTab('create');
    };

    const [busyId, setBusyId] = useState(null);   // application being loaded for edit / deleted

    // Edit: load the application from ChirpStack and open it in the form
    const handleEdit = async (a) => {
        setBusyId(a.id);
        try {
            const res = await fetch(`/api/applications/${a.id}`);
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to load application');
            setForm({ name: data.name, description: data.description });
            setEditingId(a.id);
            setTab('create');
        } catch (err) {
            toast.error(err.message);
        } finally {
            setBusyId(null);
        }
    };

    // Delete: asks first (ChirpStack removes the devices of the application too)
    const handleDelete = async (a) => {
        const deviceCount = devicesOf(a.id).length;
        const ok = await confirmDialog({
            title: 'Delete application?',
            message: `"${a.name}" will be deleted from ChirpStack together with all its devices${deviceCount > 0 ? `, including the ${deviceCount} device${deviceCount === 1 ? '' : 's'} saved in the dashboard` : ''}. This cannot be undone.`,
            confirmText: 'Delete'
        });
        if (!ok) return;
        setBusyId(a.id);
        try {
            const res = await fetch(`/api/applications/${a.id}`, { method: 'DELETE' });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to delete application');
            setApplications(list => list.filter(x => x.id !== a.id));
            setDevices(list => list.filter(d => (d.applicationId || '').toLowerCase() !== a.id.toLowerCase()));
            toast.success('Deleted successfully');
        } catch (err) {
            toast.error(err.message);
        } finally {
            setBusyId(null);
        }
    };

    const devicesOf = (appId) => devices.filter(d => (d.applicationId || '').toLowerCase() === (appId || '').toLowerCase());

    const shown = applications.filter(a => {
        const q = search.trim().toLowerCase();
        return !q || (a.name || '').toLowerCase().includes(q) || (a.id || '').toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q);
    });

    // ---- styles ----
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold', color: '#333', fontSize: '14px' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const hintStyle = { fontSize: '12px', color: '#888', margin: '6px 0 0' };
    const rowStyle = { marginBottom: '18px' };
    const thStyle = { padding: '10px 12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '10px 12px', borderBottom: '1px solid #eee', fontSize: '14px' };
    // same Edit / Delete buttons as the Gateway list
    const iconButton = (bg, busy) => ({
        width: '32px', height: '30px', padding: 0, backgroundColor: bg, color: 'white', border: 'none',
        borderRadius: '4px', cursor: busy ? 'default' : 'pointer', opacity: busy ? 0.6 : 1,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center'
    });
    const tabBtn = (active) => ({
        padding: '10px 24px', cursor: 'pointer', border: 'none', fontSize: '15px',
        borderBottom: active ? '3px solid #3498db' : '3px solid transparent',
        backgroundColor: 'transparent', color: active ? '#3498db' : '#555', fontWeight: active ? 'bold' : 'normal'
    });

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Application</h2>

            <div style={{ borderBottom: '1px solid #ddd', marginBottom: '20px' }}>
                <button style={tabBtn(tab === 'create')} onClick={openCreateTab}>{editingId ? 'Edit Application' : 'Application Creation'}</button>
                <button style={tabBtn(tab === 'list')} onClick={() => setTab('list')}>Application List</button>
            </div>

            {tab === 'create' && (
                <form onSubmit={handleSubmit} style={{ ...cardStyle, maxWidth: '600px' }}>
                    {editingId && <h3 style={{ margin: '0 0 18px' }}>Edit application</h3>}
                    <div style={rowStyle}>
                        <label style={labelStyle}>Name *</label>
                        <input
                            style={inputStyle}
                            value={form.name}
                            maxLength={100}
                            onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
                            placeholder="e.g. Temperature sensors"
                        />
                    </div>

                    <div style={rowStyle}>
                        <label style={labelStyle}>Description</label>
                        <textarea
                            style={{ ...inputStyle, minHeight: '90px', resize: 'vertical', fontFamily: 'inherit' }}
                            value={form.description}
                            maxLength={500}
                            onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))}
                            placeholder="Optional"
                        />
                        <p style={hintStyle}>The application is created in ChirpStack. Its ID is shown in the Application List tab; use it as the Application ID when you create a device.</p>
                    </div>

                    <div style={{ display: 'flex', gap: '12px' }}>
                        <button
                            type="submit"
                            disabled={saving}
                            style={{ padding: '11px 28px', backgroundColor: saving ? '#95a5a6' : '#3498db', color: 'white', border: 'none', borderRadius: '6px', fontSize: '15px', cursor: saving ? 'default' : 'pointer' }}
                        >{saving ? (editingId ? 'Saving...' : 'Creating...') : (editingId ? 'Save Changes' : 'Create Application')}</button>
                        {editingId && (
                            <button
                                type="button"
                                onClick={cancelEdit}
                                disabled={saving}
                                style={{ padding: '11px 28px', backgroundColor: 'white', color: '#555', border: '1px solid #ccc', borderRadius: '6px', fontSize: '15px', cursor: 'pointer' }}
                            >Cancel</button>
                        )}
                    </div>
                </form>
            )}

            {tab === 'list' && (
                <div style={cardStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', marginBottom: '14px', flexWrap: 'wrap' }}>
                        <input
                            style={{ ...inputStyle, width: '280px' }}
                            placeholder="Search by name, ID or description"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                        <button
                            onClick={loadApplications}
                            disabled={loading}
                            style={{ padding: '8px 18px', backgroundColor: 'white', color: '#3498db', border: '1px solid #3498db', borderRadius: '6px', cursor: loading ? 'default' : 'pointer', fontSize: '14px' }}
                        >{loading ? 'Loading...' : 'Refresh'}</button>
                    </div>

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Name</th>
                                    <th style={thStyle}>Application ID</th>
                                    <th style={thStyle}>Description</th>
                                    <th style={thStyle}>Device</th>
                                    <th style={thStyle}>Created</th>
                                    <th style={thStyle}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {shown.length === 0 ? (
                                    <tr>
                                        <td colSpan="6" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                            {loading ? 'Loading...' : (applications.length === 0 ? 'No applications yet' : 'No application matches your search')}
                                        </td>
                                    </tr>
                                ) : shown.map((a, i) => (
                                    <tr key={a.id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                        <td style={{ ...tdStyle, fontWeight: 600 }}>{a.name}</td>
                                        <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                            <code style={{ fontSize: '13px', color: '#334155' }}>{a.id}</code>
                                            <button
                                                onClick={() => copyId(a.id)}
                                                title="Copy Application ID"
                                                style={{ marginLeft: '8px', padding: '3px 10px', backgroundColor: 'white', color: '#3498db', border: '1px solid #3498db', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}
                                            >Copy</button>
                                        </td>
                                        <td style={tdStyle}>{a.description || '-'}</td>
                                        <td style={tdStyle}>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '6px' }}>
                                                {(() => {
                                                    const count = devicesOf(a.id).length;
                                                    return (
                                                        <button
                                                            onClick={() => setDevicesModalApp(a)}
                                                            disabled={count === 0}
                                                            title={count === 0 ? 'No devices in this application' : `View devices (${count})`}
                                                            aria-label={`View devices of ${a.name}`}
                                                            style={{ position: 'relative', width: '30px', height: '30px', padding: 0, backgroundColor: 'white', color: count === 0 ? '#b0b8c4' : '#1e3a8a', border: `1px solid ${count === 0 ? '#e2e8f0' : '#c7dbf5'}`, borderRadius: '50%', cursor: count === 0 ? 'default' : 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
                                                        >
                                                            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" />
                                                                <circle cx="12" cy="12" r="3" />
                                                            </svg>
                                                            {count > 0 && (
                                                                <span style={{ position: 'absolute', top: '-6px', right: '-6px', minWidth: '16px', height: '16px', padding: '0 4px', borderRadius: '999px', backgroundColor: '#1e3a8a', color: 'white', fontSize: '10px', fontWeight: 700, lineHeight: '16px', textAlign: 'center', boxSizing: 'border-box' }}>{count}</span>
                                                            )}
                                                        </button>
                                                    );
                                                })()}
                                                <button
                                                    onClick={() => onOpenDeviceCreation && onOpenDeviceCreation({ applicationId: a.id })}
                                                    title="Add a device to this application"
                                                    aria-label={`Add a device to ${a.name}`}
                                                    style={{ width: '26px', height: '26px', padding: 0, backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '50%', cursor: 'pointer', fontSize: '18px', lineHeight: '24px' }}
                                                >+</button>
                                            </div>
                                        </td>
                                        <td style={tdStyle}>{formatTime(a.createdAt)}</td>
                                        <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                            <button
                                                onClick={() => handleEdit(a)}
                                                disabled={busyId === a.id}
                                                title="Edit"
                                                aria-label={`Edit ${a.name}`}
                                                style={{ ...iconButton('#f39c12', busyId === a.id), marginRight: '6px' }}
                                            >
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                                    <path d="M12 20h9" />
                                                    <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" />
                                                </svg>
                                            </button>
                                            <button
                                                onClick={() => handleDelete(a)}
                                                disabled={busyId === a.id}
                                                title="Delete"
                                                aria-label={`Delete ${a.name}`}
                                                style={iconButton('#e74c3c', busyId === a.id)}
                                            >
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                                    <path d="M3 6h18" />
                                                    <path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2" />
                                                    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                                                    <path d="M10 11v6" />
                                                    <path d="M14 11v6" />
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <p style={hintStyle}>{applications.length} application{applications.length === 1 ? '' : 's'} in ChirpStack</p>
                </div>
            )}

            {devicesModalApp && (
                <Modal
                    title="Devices"
                    subtitle={devicesModalApp.name}
                    onClose={() => setDevicesModalApp(null)}
                    maxWidth="560px"
                >
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                            <tr>
                                <th style={thStyle}>Device name</th>
                                <th style={thStyle}>Device EUI</th>
                                <th style={thStyle}></th>
                            </tr>
                        </thead>
                        <tbody>
                            {devicesOf(devicesModalApp.id).map((d, i) => (
                                <tr key={d._id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                    <td style={{ ...tdStyle, fontWeight: 600 }}>{d.deviceName}</td>
                                    <td style={tdStyle}><code style={{ fontSize: '13px', color: '#334155' }}>{d.devEui}</code></td>
                                    <td style={{ ...tdStyle, textAlign: 'right' }}>
                                        <button
                                            onClick={() => { setDevicesModalApp(null); if (onOpenDeviceCreation) onOpenDeviceCreation({ device: d }); }}
                                            title="Open this device in Device Creation"
                                            style={{ padding: '4px 12px', backgroundColor: '#f39c12', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}
                                        >Edit</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </Modal>
            )}
        </div>
    );
}
