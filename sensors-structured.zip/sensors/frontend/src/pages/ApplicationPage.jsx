import { useEffect, useState } from 'react';
import { toast } from '../utils/toast';

// Application page - two tabs: "Application Creation" (form) and "Application List".
// Applications live in ChirpStack (a device belongs to one application), so both tabs talk to
// ChirpStack through the backend (/api/applications). The Application ID shown in the list is the
// one to enter as "Application ID" in Device Creation.

const emptyForm = { name: '', description: '' };

const formatTime = (iso) => {
    if (!iso) return '-';
    const d = new Date(iso);
    return isNaN(d) ? '-' : d.toLocaleString();
};

export default function ApplicationPage({ isCollapsed, onOpenDeviceCreation }) {
    const [tab, setTab] = useState('create');

    // ---- Creation tab ----
    const [form, setForm] = useState(emptyForm);
    const [saving, setSaving] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.name.trim()) {
            toast.error('Name is required');
            return;
        }
        setSaving(true);
        try {
            const res = await fetch('/api/applications', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: form.name.trim(), description: form.description.trim() })
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to create application');
            toast.success(`Application "${data.name}" created in ChirpStack.`);
            setForm(emptyForm);
        } catch (err) {
            toast.error(err.message);
        } finally {
            setSaving(false);
        }
    };

    // ---- List tab ----
    const [applications, setApplications] = useState([]);
    const [devices, setDevices] = useState([]);   // devices of the dashboard, grouped by application in the Device column
    const [loading, setLoading] = useState(false);
    const [search, setSearch] = useState('');

    const loadApplications = async () => {
        setLoading(true);
        try {
            const [res, devRes] = await Promise.all([
                fetch('/api/applications'),
                fetch('/api/nodes').catch(() => null)
            ]);
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to load applications');
            setApplications(Array.isArray(data) ? data : []);
            const devData = devRes && devRes.ok ? await devRes.json().catch(() => []) : [];
            setDevices(Array.isArray(devData) ? devData : []);
        } catch (err) {
            setApplications([]);
            setDevices([]);
            toast.error(err.message);
        } finally {
            setLoading(false);
        }
    };

    // reload every time the list tab is opened, so an application just created shows up
    useEffect(() => { if (tab === 'list') loadApplications(); }, [tab]);

    const copyId = async (id) => {
        try {
            await navigator.clipboard.writeText(id);
            toast.success('Application ID copied');
        } catch {
            toast.error('Could not copy. Select the ID and copy it by hand.');
        }
    };

    const devicesOf = (appId) => devices.filter(d => (d.applicationId || '').toLowerCase() === (appId || '').toLowerCase());

    const shown = applications.filter(a => {
        const q = search.trim().toLowerCase();
        return !q || (a.name || '').toLowerCase().includes(q) || (a.id || '').toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q);
    });

    // ---- styles ----
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold', color: '#333', fontSize: '14px' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const hintStyle = { fontSize: '12px', color: '#888', margin: '6px 0 0' };
    const rowStyle = { marginBottom: '18px' };
    const thStyle = { padding: '10px 12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '10px 12px', borderBottom: '1px solid #eee', fontSize: '14px' };
    const tabBtn = (active) => ({
        padding: '10px 24px', cursor: 'pointer', border: 'none', fontSize: '15px',
        borderBottom: active ? '3px solid #3498db' : '3px solid transparent',
        backgroundColor: 'transparent', color: active ? '#3498db' : '#555', fontWeight: active ? 'bold' : 'normal'
    });

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Application</h2>

            <div style={{ borderBottom: '1px solid #ddd', marginBottom: '20px' }}>
                <button style={tabBtn(tab === 'create')} onClick={() => setTab('create')}>Application Creation</button>
                <button style={tabBtn(tab === 'list')} onClick={() => setTab('list')}>Application List</button>
            </div>

            {tab === 'create' && (
                <form onSubmit={handleSubmit} style={{ ...cardStyle, maxWidth: '600px' }}>
                    <div style={rowStyle}>
                        <label style={labelStyle}>Name *</label>
                        <input
                            style={inputStyle}
                            value={form.name}
                            maxLength={100}
                            onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
                            placeholder="e.g. Temperature sensors"
                        />
                    </div>

                    <div style={rowStyle}>
                        <label style={labelStyle}>Description</label>
                        <textarea
                            style={{ ...inputStyle, minHeight: '90px', resize: 'vertical', fontFamily: 'inherit' }}
                            value={form.description}
                            maxLength={500}
                            onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))}
                            placeholder="Optional"
                        />
                        <p style={hintStyle}>The application is created in ChirpStack. Its ID is shown in the Application List tab; use it as the Application ID when you create a device.</p>
                    </div>

                    <button
                        type="submit"
                        disabled={saving}
                        style={{ padding: '11px 28px', backgroundColor: saving ? '#95a5a6' : '#3498db', color: 'white', border: 'none', borderRadius: '6px', fontSize: '15px', cursor: saving ? 'default' : 'pointer' }}
                    >{saving ? 'Creating...' : 'Create Application'}</button>
                </form>
            )}

            {tab === 'list' && (
                <div style={cardStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', marginBottom: '14px', flexWrap: 'wrap' }}>
                        <input
                            style={{ ...inputStyle, width: '280px' }}
                            placeholder="Search by name, ID or description"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                        <button
                            onClick={loadApplications}
                            disabled={loading}
                            style={{ padding: '8px 18px', backgroundColor: 'white', color: '#3498db', border: '1px solid #3498db', borderRadius: '6px', cursor: loading ? 'default' : 'pointer', fontSize: '14px' }}
                        >{loading ? 'Loading...' : 'Refresh'}</button>
                    </div>

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Name</th>
                                    <th style={thStyle}>Application ID</th>
                                    <th style={thStyle}>Description</th>
                                    <th style={thStyle}>Device</th>
                                    <th style={thStyle}>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                {shown.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                            {loading ? 'Loading...' : (applications.length === 0 ? 'No applications yet' : 'No application matches your search')}
                                        </td>
                                    </tr>
                                ) : shown.map((a, i) => (
                                    <tr key={a.id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                        <td style={{ ...tdStyle, fontWeight: 600 }}>{a.name}</td>
                                        <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                            <code style={{ fontSize: '13px', color: '#334155' }}>{a.id}</code>
                                            <button
                                                onClick={() => copyId(a.id)}
                                                title="Copy Application ID"
                                                style={{ marginLeft: '8px', padding: '3px 10px', backgroundColor: 'white', color: '#3498db', border: '1px solid #3498db', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}
                                            >Copy</button>
                                        </td>
                                        <td style={tdStyle}>{a.description || '-'}</td>
                                        <td style={tdStyle}>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '6px' }}>
                                                {devicesOf(a.id).map(d => (
                                                    <button
                                                        key={d._id}
                                                        onClick={() => onOpenDeviceCreation && onOpenDeviceCreation({ device: d })}
                                                        title={`Open ${d.deviceName} in Device Creation`}
                                                        style={{ padding: '3px 10px', backgroundColor: '#e8f1fb', color: '#1e3a8a', border: '1px solid #c7dbf5', borderRadius: '999px', cursor: 'pointer', fontSize: '12px', fontWeight: 600 }}
                                                    >{d.deviceName}</button>
                                                ))}
                                                <button
                                                    onClick={() => onOpenDeviceCreation && onOpenDeviceCreation({ applicationId: a.id })}
                                                    title="Add a device to this application"
                                                    aria-label={`Add a device to ${a.name}`}
                                                    style={{ width: '26px', height: '26px', padding: 0, backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '50%', cursor: 'pointer', fontSize: '18px', lineHeight: '24px' }}
                                                >+</button>
                                            </div>
                                        </td>
                                        <td style={tdStyle}>{formatTime(a.createdAt)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <p style={hintStyle}>{applications.length} application{applications.length === 1 ? '' : 's'} in ChirpStack</p>
                </div>
            )}
        </div>
    );
}
