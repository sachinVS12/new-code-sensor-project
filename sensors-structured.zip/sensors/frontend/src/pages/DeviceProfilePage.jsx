import { useEffect, useState } from 'react';

// Device Profile page - two tabs: "Device Profile Creation" (form) and "Device Profile List".
// Profiles live in ChirpStack, so both tabs talk to ChirpStack through the backend (/api/device-profiles).

const REGIONS = ['EU868', 'US915', 'CN779', 'EU433', 'AU915', 'CN470', 'AS923', 'AS923_2', 'AS923_3', 'AS923_4', 'KR920', 'IN865', 'RU864', 'ISM2400'];
const MAC_VERSIONS = [
    { value: 'LORAWAN_1_0_0', label: 'LoRaWAN 1.0.0' },
    { value: 'LORAWAN_1_0_1', label: 'LoRaWAN 1.0.1' },
    { value: 'LORAWAN_1_0_2', label: 'LoRaWAN 1.0.2' },
    { value: 'LORAWAN_1_0_3', label: 'LoRaWAN 1.0.3' },
    { value: 'LORAWAN_1_0_4', label: 'LoRaWAN 1.0.4' },
    { value: 'LORAWAN_1_1_0', label: 'LoRaWAN 1.1.0' }
];
const REG_PARAMS = [
    { value: 'A', label: 'A' },
    { value: 'B', label: 'B' },
    { value: 'RP002_1_0_0', label: 'RP002-1.0.0' },
    { value: 'RP002_1_0_1', label: 'RP002-1.0.1' },
    { value: 'RP002_1_0_2', label: 'RP002-1.0.2' },
    { value: 'RP002_1_0_3', label: 'RP002-1.0.3' },
    { value: 'RP002_1_0_4', label: 'RP002-1.0.4' }
];
const CODECS = [
    { value: 'NONE', label: 'None' },
    { value: 'CAYENNE_LPP', label: 'Cayenne LPP' },
    { value: 'JS', label: 'JavaScript functions' }
];

const emptyForm = {
    name: '',
    description: '',
    region: 'IN865',
    macVersion: 'LORAWAN_1_0_3',
    regParamsRevision: 'A',
    uplinkInterval: '3600',
    deviceStatusReqInterval: '1',
    supportsOtaa: true,
    supportsClassB: false,
    supportsClassC: false,
    classCTimeout: '5',
    flushQueueOnActivate: true,
    payloadCodecRuntime: 'NONE',
    payloadCodecScript: ''
};

const labelOf = (list, value) => (list.find(o => o.value === value) || {}).label || value || '-';

const classesOf = (p) => ['A', p.supportsClassB && 'B', p.supportsClassC && 'C'].filter(Boolean).join(', ');

const formatTime = (iso) => {
    if (!iso) return '-';
    const d = new Date(iso);
    return isNaN(d) ? '-' : d.toLocaleString();
};

export default function DeviceProfilePage({ isCollapsed }) {
    const [tab, setTab] = useState('create');

    // ---- Creation tab ----
    const [form, setForm] = useState(emptyForm);
    const [saving, setSaving] = useState(false);
    const [feedback, setFeedback] = useState(null);   // { type: 'success' | 'error', text }

    const setField = (key, value) => setForm(f => ({ ...f, [key]: value }));

    const handleSubmit = async (e) => {
        e.preventDefault();
        setFeedback(null);
        if (!form.name.trim()) {
            setFeedback({ type: 'error', text: 'Name is required' });
            return;
        }
        setSaving(true);
        try {
            const res = await fetch('/api/device-profiles', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...form,
                    name: form.name.trim(),
                    description: form.description.trim(),
                    uplinkInterval: Number(form.uplinkInterval),
                    deviceStatusReqInterval: Number(form.deviceStatusReqInterval),
                    classCTimeout: Number(form.classCTimeout)
                })
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to create device profile');
            setFeedback({ type: 'success', text: `Device profile "${data.name}" created in ChirpStack.` });
            setForm(emptyForm);
        } catch (err) {
            setFeedback({ type: 'error', text: err.message });
        } finally {
            setSaving(false);
        }
    };

    // ---- List tab ----
    const [profiles, setProfiles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [listError, setListError] = useState('');
    const [search, setSearch] = useState('');

    const loadProfiles = async () => {
        setLoading(true);
        setListError('');
        try {
            const res = await fetch('/api/device-profiles');
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || 'Failed to load device profiles');
            setProfiles(Array.isArray(data) ? data : []);
        } catch (err) {
            setProfiles([]);
            setListError(err.message);
        } finally {
            setLoading(false);
        }
    };

    // reload every time the list tab is opened, so a profile just created shows up
    useEffect(() => { if (tab === 'list') loadProfiles(); }, [tab]);

    const shown = profiles.filter(p => {
        const q = search.trim().toLowerCase();
        return !q || (p.name || '').toLowerCase().includes(q) || (p.region || '').toLowerCase().includes(q);
    });

    // ---- styles ----
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold', color: '#333', fontSize: '14px' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const hintStyle = { fontSize: '12px', color: '#888', margin: '6px 0 0' };
    const rowStyle = { marginBottom: '18px' };
    const twoCols = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '18px' };
    const checkStyle = { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px', color: '#333', cursor: 'pointer' };
    const thStyle = { padding: '10px 12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '10px 12px', borderBottom: '1px solid #eee', fontSize: '14px' };
    const tabBtn = (active) => ({
        padding: '10px 24px', cursor: 'pointer', border: 'none', fontSize: '15px',
        borderBottom: active ? '3px solid #3498db' : '3px solid transparent',
        backgroundColor: 'transparent', color: active ? '#3498db' : '#555', fontWeight: active ? 'bold' : 'normal'
    });
    const msgStyle = (type) => ({
        padding: '10px 14px', borderRadius: '6px', marginBottom: '18px', fontSize: '14px',
        backgroundColor: type === 'success' ? '#e8f5e9' : '#ffebee',
        color: type === 'success' ? '#2e7d32' : '#c62828'
    });
    const badge = (on) => ({
        display: 'inline-block', padding: '2px 10px', borderRadius: '999px', fontSize: '12px', fontWeight: 600,
        backgroundColor: on ? '#e8f5e9' : '#f1f5f9', color: on ? '#2e7d32' : '#64748b'
    });

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Device Profile</h2>

            <div style={{ borderBottom: '1px solid #ddd', marginBottom: '20px' }}>
                <button style={tabBtn(tab === 'create')} onClick={() => setTab('create')}>Device Profile Creation</button>
                <button style={tabBtn(tab === 'list')} onClick={() => setTab('list')}>Device Profile List</button>
            </div>

            {tab === 'create' && (
                <form onSubmit={handleSubmit} style={{ ...cardStyle, maxWidth: '760px' }}>
                    {feedback && <div style={msgStyle(feedback.type)}>{feedback.text}</div>}

                    <div style={rowStyle}>
                        <label style={labelStyle}>Name *</label>
                        <input style={inputStyle} value={form.name} onChange={(e) => setField('name', e.target.value)} placeholder="e.g. Sensor node IN865" />
                    </div>

                    <div style={rowStyle}>
                        <label style={labelStyle}>Description</label>
                        <input style={inputStyle} value={form.description} onChange={(e) => setField('description', e.target.value)} placeholder="Optional" />
                    </div>

                    <div style={{ ...twoCols, ...rowStyle }}>
                        <div>
                            <label style={labelStyle}>Region *</label>
                            <select style={inputStyle} value={form.region} onChange={(e) => setField('region', e.target.value)}>
                                {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
                            </select>
                        </div>
                        <div>
                            <label style={labelStyle}>MAC version *</label>
                            <select style={inputStyle} value={form.macVersion} onChange={(e) => setField('macVersion', e.target.value)}>
                                {MAC_VERSIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                    </div>

                    <div style={{ ...twoCols, ...rowStyle }}>
                        <div>
                            <label style={labelStyle}>Regional parameters revision *</label>
                            <select style={inputStyle} value={form.regParamsRevision} onChange={(e) => setField('regParamsRevision', e.target.value)}>
                                {REG_PARAMS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                        <div>
                            <label style={labelStyle}>Expected uplink interval (seconds) *</label>
                            <input style={inputStyle} type="number" min="1" value={form.uplinkInterval} onChange={(e) => setField('uplinkInterval', e.target.value)} />
                        </div>
                    </div>

                    <div style={rowStyle}>
                        <label style={labelStyle}>Device-status request frequency (per day)</label>
                        <input style={inputStyle} type="number" min="0" value={form.deviceStatusReqInterval} onChange={(e) => setField('deviceStatusReqInterval', e.target.value)} />
                        <p style={hintStyle}>How often ChirpStack asks the device for its battery and margin. 0 = never.</p>
                    </div>

                    <div style={{ ...rowStyle, display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        <label style={checkStyle}>
                            <input type="checkbox" checked={form.supportsOtaa} onChange={(e) => setField('supportsOtaa', e.target.checked)} />
                            Device supports OTAA
                        </label>
                        <label style={checkStyle}>
                            <input type="checkbox" checked={form.supportsClassB} onChange={(e) => setField('supportsClassB', e.target.checked)} />
                            Device supports Class-B
                        </label>
                        <label style={checkStyle}>
                            <input type="checkbox" checked={form.supportsClassC} onChange={(e) => setField('supportsClassC', e.target.checked)} />
                            Device supports Class-C
                        </label>
                        <label style={checkStyle}>
                            <input type="checkbox" checked={form.flushQueueOnActivate} onChange={(e) => setField('flushQueueOnActivate', e.target.checked)} />
                            Flush queue on device activation
                        </label>
                    </div>

                    {form.supportsClassC && (
                        <div style={rowStyle}>
                            <label style={labelStyle}>Class-C confirmed downlink timeout (seconds) *</label>
                            <input style={inputStyle} type="number" min="1" value={form.classCTimeout} onChange={(e) => setField('classCTimeout', e.target.value)} />
                        </div>
                    )}

                    <div style={rowStyle}>
                        <label style={labelStyle}>Payload codec</label>
                        <select style={inputStyle} value={form.payloadCodecRuntime} onChange={(e) => setField('payloadCodecRuntime', e.target.value)}>
                            {CODECS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                    </div>

                    {form.payloadCodecRuntime === 'JS' && (
                        <div style={rowStyle}>
                            <label style={labelStyle}>Codec script</label>
                            <textarea
                                style={{ ...inputStyle, minHeight: '160px', fontFamily: 'monospace' }}
                                value={form.payloadCodecScript}
                                onChange={(e) => setField('payloadCodecScript', e.target.value)}
                                placeholder="function decodeUplink(input) { ... }"
                                spellCheck={false}
                            />
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={saving}
                        style={{ padding: '11px 28px', backgroundColor: saving ? '#95a5a6' : '#3498db', color: 'white', border: 'none', borderRadius: '6px', fontSize: '15px', cursor: saving ? 'default' : 'pointer' }}
                    >{saving ? 'Creating...' : 'Create Device Profile'}</button>
                </form>
            )}

            {tab === 'list' && (
                <div style={cardStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', marginBottom: '14px', flexWrap: 'wrap' }}>
                        <input
                            style={{ ...inputStyle, width: '280px' }}
                            placeholder="Search by name or region"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                        <button
                            onClick={loadProfiles}
                            disabled={loading}
                            style={{ padding: '8px 18px', backgroundColor: 'white', color: '#3498db', border: '1px solid #3498db', borderRadius: '6px', cursor: loading ? 'default' : 'pointer', fontSize: '14px' }}
                        >{loading ? 'Loading...' : 'Refresh'}</button>
                    </div>

                    {listError && <div style={msgStyle('error')}>{listError}</div>}

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Name</th>
                                    <th style={thStyle}>Region</th>
                                    <th style={thStyle}>MAC version</th>
                                    <th style={thStyle}>Reg. params</th>
                                    <th style={thStyle}>OTAA</th>
                                    <th style={thStyle}>Classes</th>
                                    <th style={thStyle}>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                {shown.length === 0 ? (
                                    <tr>
                                        <td colSpan="7" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                            {loading ? 'Loading...' : (profiles.length === 0 ? 'No device profiles yet' : 'No device profile matches your search')}
                                        </td>
                                    </tr>
                                ) : shown.map((p, i) => (
                                    <tr key={p.id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                        <td style={{ ...tdStyle, fontWeight: 600 }}>{p.name}</td>
                                        <td style={tdStyle}>{p.region || '-'}</td>
                                        <td style={tdStyle}>{labelOf(MAC_VERSIONS, p.macVersion)}</td>
                                        <td style={tdStyle}>{labelOf(REG_PARAMS, p.regParamsRevision)}</td>
                                        <td style={tdStyle}><span style={badge(p.supportsOtaa)}>{p.supportsOtaa ? 'Yes' : 'No'}</span></td>
                                        <td style={tdStyle}>{classesOf(p)}</td>
                                        <td style={tdStyle}>{formatTime(p.createdAt)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <p style={hintStyle}>{profiles.length} device profile{profiles.length === 1 ? '' : 's'} in ChirpStack</p>
                </div>
            )}
        </div>
    );
}
