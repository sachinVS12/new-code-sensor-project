import { useEffect, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { toast } from '../utils/toast';

// Downlink page - two tabs: "Feed Data" (upload Excel/CSV per device) and "Queue" (the send form).
// What was sent and its status is on the Task page.
export default function DownlinkPage({ devices = [], isCollapsed, onOpenTask }) {
    const [tab, setTab] = useState('feed');

    // ---- Feed Data: per-device Excel / CSV upload ----
    const [feedDevice, setFeedDevice] = useState('');
    const [fileKey, setFileKey] = useState(0);          // resets the file input
    const [preview, setPreview] = useState(null);       // { fileName, rows, skipped }
    const [saved, setSaved] = useState([]);
    const [uploading, setUploading] = useState(false);

    const feedDeviceObj = devices.find(d => (d.devEui || '').toLowerCase() === feedDevice);

    const loadSaved = async (eui) => {
        if (!eui) { setSaved([]); return; }
        try {
            const res = await fetch(`/api/feed-data?devEui=${eui}`);
            setSaved(res.ok ? await res.json() : []);
        } catch (err) {
            setSaved([]);
        }
    };

    useEffect(() => {
        setPreview(null);
        setFileKey(k => k + 1);
        loadSaved(feedDevice);
    }, [feedDevice]);

    // Read the chosen Excel / CSV file in the browser and show a preview
    const handleFile = async (e) => {
        const file = e.target.files && e.target.files[0];
        setPreview(null);
        if (!file) return;
        try {
            const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
            // first sheet that has data
            let grid = [];
            for (const name of wb.SheetNames) {
                const g = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: '', raw: true })
                    .filter(r => r.some(c => String(c).trim() !== ''));
                if (g.length) { grid = g; break; }
            }
            if (!grid.length) throw new Error('The file has no data');

            // header row: find the "Frame Port" and "Purpose" columns, otherwise use columns 1 and 2
            const head = grid[0].map(c => String(c).trim().toLowerCase());
            let portCol = head.findIndex(h => /(frame\s*port|fport|^port$)/.test(h));
            let purposeCol = head.findIndex(h => /(purpose|description|name)/.test(h));
            let start = 0;
            if (portCol !== -1 && purposeCol !== -1) {
                start = 1;
            } else {
                portCol = 0; purposeCol = 1;
                if (isNaN(Number(grid[0][0]))) start = 1;      // first row is a header with other titles
            }

            const rows = [];
            const skipped = [];
            grid.slice(start).forEach((r, i) => {
                const lineNo = i + start + 1;
                const port = Number(r[portCol]);
                const purpose = String(r[purposeCol] ?? '').trim();
                if (!Number.isInteger(port) || port < 1 || port > 223) {
                    skipped.push(`Row ${lineNo}: invalid Frame Port "${r[portCol]}"`);
                } else if (!purpose) {
                    skipped.push(`Row ${lineNo}: Purpose is empty`);
                } else {
                    rows.push({ framePort: port, purpose });
                }
            });
            if (!rows.length) throw new Error('No valid rows found. Expected columns: Frame Port, Purpose');
            setPreview({ fileName: file.name, rows, skipped });
        } catch (err) {
            toast.error(err.message || 'Could not read the file');
            setFileKey(k => k + 1);
        }
    };

    const handleUploadSave = async () => {
        if (!feedDevice || !preview) return;
        setUploading(true);
        try {
            const res = await fetch('/api/feed-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ devEui: feedDevice, fileName: preview.fileName, rows: preview.rows })
            });
            const body = await res.json();
            if (!res.ok) throw new Error(body.error || 'Failed to save');
            toast.success(`Saved ${body.saved} row(s) for ${feedDeviceObj ? feedDeviceObj.deviceName : 'device'}${body.replaced ? ` (replaced ${body.replaced} earlier row(s))` : ''}.`);
            setPreview(null);
            setFileKey(k => k + 1);
            loadSaved(feedDevice);
        } catch (err) {
            toast.error(err.message);
        } finally {
            setUploading(false);
        }
    };

    const handleClearSaved = async () => {
        if (!confirm(`Delete all saved data for ${feedDeviceObj ? feedDeviceObj.deviceName : 'this device'}?`)) return;
        try {
            const res = await fetch(`/api/feed-data?devEui=${feedDevice}`, { method: 'DELETE' });
            if (!res.ok) throw new Error('Failed to delete the saved data');
            toast.success('Saved data deleted.');
        } catch (err) {
            toast.error(err.message);
        }
        loadSaved(feedDevice);
    };

    // ---- Queue tab: send form ----
    const [devEui, setDevEui] = useState('');
    const [fPort, setFPort] = useState('');
    const [ports, setPorts] = useState([]);          // saved Feed Data rows for the selected device
    const [format, setFormat] = useState('hex');
    const [data, setData] = useState('');
    const [confirmed, setConfirmed] = useState(false);
    const [sending, setSending] = useState(false);

    // Fixed chunk size: every downlink carries at most 240 bytes
    const CHUNK_BYTES = 240;

    // Number of bytes the entered data will become (null if the data is not valid yet)
    const byteCount = useMemo(() => {
        const raw = data;
        if (!raw.trim()) return 0;
        try {
            if (format === 'hex') {
                const hex = raw.replace(/0x/gi, '').replace(/[\s:,-]/g, '');
                if (!/^[0-9a-fA-F]*$/.test(hex) || hex.length % 2 !== 0) return null;
                return hex.length / 2;
            }
            if (format === 'base64') {
                const b64 = raw.replace(/\s/g, '');
                if (!/^[A-Za-z0-9+/]+={0,2}$/.test(b64) || b64.length % 4 !== 0) return null;
                return atob(b64).length;
            }
            return new TextEncoder().encode(raw).length;
        } catch (err) {
            return null;
        }
    }, [data, format]);

    const chunkSizes = useMemo(() => {
        if (!byteCount) return [];
        const sizes = [];
        for (let left = byteCount; left > 0; left -= CHUNK_BYTES) sizes.push(Math.min(left, CHUNK_BYTES));
        return sizes;
    }, [byteCount]);

    // Load the Frame Ports saved (from the uploaded Excel) for the device chosen in the Queue tab
    useEffect(() => {
        setFPort('');
        setPorts([]);
        if (!devEui) return;
        let cancelled = false;
        fetch(`/api/feed-data?devEui=${devEui}`)
            .then(res => (res.ok ? res.json() : []))
            .then(rows => { if (!cancelled) setPorts(Array.isArray(rows) ? rows : []); })
            .catch(() => { if (!cancelled) setPorts([]); });
        return () => { cancelled = true; };
    }, [devEui, tab]);

    const handleSend = async () => {
        if (!devEui) return toast.error('Select a device');
        if (!fPort) return toast.error('Select an FPort');
        if (!data.trim()) return toast.error('Enter the data to send');

        setSending(true);
        try {
            const res = await fetch('/api/downlinks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ devEui, fPort: Number(fPort), confirmed, format, data })
            });
            const body = await res.json();
            if (!res.ok) {
                const e = new Error(body.error || 'Failed to send downlink');
                e.saved = Array.isArray(body.downlinks) && body.downlinks.length > 0;   // saved as Failed on the Task page
                throw e;
            }
            setData('');
            const viewTask = onOpenTask ? { action: { label: 'View in Task', onClick: onOpenTask } } : {};
            toast.success(
                body.chunks > 1
                    ? `${body.totalBytes} bytes added to the queue as ${body.chunks} chunks (${body.downlinks.map(d => (d.data ? atob(d.data).length : 0)).join(' + ')} bytes). ChirpStack sends one chunk after each uplink of the device.`
                    : 'Downlink added to the queue. ChirpStack sends it after the device\'s next uplink.',
                viewTask
            );
        } catch (err) {
            toast.error(err.message, err.saved && onOpenTask ? { action: { label: 'View in Task', onClick: onOpenTask } } : {});
        } finally {
            setSending(false);
        }
    };

    // ---- styles ----
    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const thStyle = { padding: '10px 12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '10px 12px', borderBottom: '1px solid #eee', fontSize: '14px' };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold', color: '#333', fontSize: '14px' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const tabBtn = (active) => ({
        padding: '10px 24px', cursor: 'pointer', border: 'none', fontSize: '15px',
        borderBottom: active ? '3px solid #3498db' : '3px solid transparent',
        backgroundColor: 'transparent', color: active ? '#3498db' : '#555', fontWeight: active ? 'bold' : 'normal'
    });

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Downlink</h2>

            <div style={{ borderBottom: '1px solid #ddd', marginBottom: '20px' }}>
                <button style={tabBtn(tab === 'feed')} onClick={() => setTab('feed')}>Feed Data</button>
                <button style={tabBtn(tab === 'queue')} onClick={() => setTab('queue')}>Queue</button>
            </div>

            {tab === 'feed' && (
                <div style={{ maxWidth: '760px' }}>
                    <div style={{ ...cardStyle, marginBottom: '20px' }}>
                        <div style={{ marginBottom: '18px' }}>
                            <label style={labelStyle}>Device</label>
                            <select style={inputStyle} value={feedDevice} onChange={(e) => setFeedDevice(e.target.value)}>
                                <option value="">Select device</option>
                                {devices.map(d => (
                                    <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName}</option>
                                ))}
                            </select>
                            {devices.length === 0 && (
                                <p style={{ fontSize: '12px', color: '#888', margin: '6px 0 0' }}>No devices yet - create one in Device Creation first.</p>
                            )}
                        </div>

                        <div style={{ marginBottom: '14px' }}>
                            <label style={labelStyle}>Upload file (Excel .xlsx / .xls or .csv)</label>
                            <input
                                key={fileKey}
                                type="file"
                                accept=".xlsx,.xls,.csv"
                                disabled={!feedDevice}
                                onChange={handleFile}
                                style={{ fontSize: '14px' }}
                            />
                            <p style={{ fontSize: '12px', color: '#888', margin: '6px 0 0' }}>
                                {feedDevice ? 'Two columns: "Frame Port" and "Purpose" (one row per port).' : 'Select a device first.'}
                            </p>
                        </div>

                        {preview && (
                            <div>
                                <p style={{ margin: '0 0 8px', fontSize: '14px' }}>
                                    <strong>{preview.fileName}</strong> - {preview.rows.length} row(s) ready to save for <strong>{feedDeviceObj ? feedDeviceObj.deviceName : ''}</strong>
                                    {feedDevice && saved.length > 0 && <span style={{ color: '#e65100' }}> (this replaces the {saved.length} row(s) already saved)</span>}
                                </p>
                                <div style={{ maxHeight: '220px', overflowY: 'auto', marginBottom: '10px' }}>
                                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                        <thead><tr><th style={thStyle}>Frame Port</th><th style={thStyle}>Purpose</th></tr></thead>
                                        <tbody>
                                            {preview.rows.map((r, i) => (
                                                <tr key={i} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                                    <td style={tdStyle}>{r.framePort}</td>
                                                    <td style={tdStyle}>{r.purpose}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                {preview.skipped.length > 0 && (
                                    <div style={{ fontSize: '12px', color: '#e65100', marginBottom: '10px' }}>
                                        Skipped {preview.skipped.length} row(s): {preview.skipped.slice(0, 5).join('; ')}{preview.skipped.length > 5 ? '...' : ''}
                                    </div>
                                )}
                                <button
                                    onClick={handleUploadSave}
                                    disabled={uploading}
                                    style={{ padding: '10px 24px', backgroundColor: uploading ? '#95a5a6' : '#27ae60', color: 'white', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: uploading ? 'default' : 'pointer', marginRight: '10px' }}
                                >{uploading ? 'Saving...' : 'Save to database'}</button>
                                <button
                                    onClick={() => { setPreview(null); setFileKey(k => k + 1); }}
                                    style={{ padding: '10px 18px', backgroundColor: 'white', color: '#555', border: '1px solid #ccc', borderRadius: '6px', cursor: 'pointer' }}
                                >Cancel</button>
                            </div>
                        )}
                    </div>

                    {feedDevice && (
                        <div style={cardStyle}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                                <h3 style={{ margin: 0 }}>Saved data - {feedDeviceObj ? feedDeviceObj.deviceName : ''}</h3>
                                {saved.length > 0 && (
                                    <button onClick={handleClearSaved} style={{ padding: '6px 14px', backgroundColor: 'white', color: '#c62828', border: '1px solid #c62828', borderRadius: '6px', cursor: 'pointer', fontSize: '13px' }}>
                                        Clear all
                                    </button>
                                )}
                            </div>
                            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                <thead><tr><th style={thStyle}>Frame Port</th><th style={thStyle}>Purpose</th></tr></thead>
                                <tbody>
                                    {saved.length === 0 ? (
                                        <tr><td colSpan="2" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>Nothing saved for this device yet</td></tr>
                                    ) : saved.map((r, i) => (
                                        <tr key={r._id} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                            <td style={tdStyle}>{r.framePort}</td>
                                            <td style={tdStyle}>{r.purpose}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {saved.length > 0 && saved[0].sourceFile && (
                                <p style={{ fontSize: '12px', color: '#888', margin: '10px 0 0' }}>From file: {saved[0].sourceFile}</p>
                            )}
                        </div>
                    )}
                </div>
            )}

            {tab === 'queue' && (
                <div style={{ ...cardStyle, maxWidth: '640px' }}>
                    <div style={{ marginBottom: '18px' }}>
                        <label style={labelStyle}>Device</label>
                        <select style={inputStyle} value={devEui} onChange={(e) => setDevEui(e.target.value)}>
                            <option value="">Select device</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName} ({d.devEui})</option>
                            ))}
                        </select>
                        {devices.length === 0 && (
                            <p style={{ fontSize: '12px', color: '#888', margin: '6px 0 0' }}>No devices yet - create one in Device Creation first.</p>
                        )}
                    </div>

                    <div style={{ display: 'flex', gap: '15px', marginBottom: '18px' }}>
                        <div style={{ flex: 1 }}>
                            <label style={labelStyle}>FPort</label>
                            <select
                                style={inputStyle}
                                value={fPort}
                                onChange={(e) => setFPort(e.target.value)}
                                disabled={!devEui || ports.length === 0}
                            >
                                <option value="">
                                    {!devEui ? 'Select device first' : ports.length === 0 ? 'No ports saved' : 'Select FPort'}
                                </option>
                                {ports.map(r => (
                                    <option key={r._id} value={String(r.framePort)}>{r.framePort} - {r.purpose}</option>
                                ))}
                            </select>
                            {devEui && ports.length === 0 && (
                                <p style={{ fontSize: '12px', color: '#e65100', margin: '6px 0 0' }}>
                                    Nothing saved for this device. Upload its Excel in the Feed Data tab first.
                                </p>
                            )}
                        </div>
                        <div style={{ flex: 1 }}>
                            <label style={labelStyle}>Data format</label>
                            <select style={inputStyle} value={format} onChange={(e) => setFormat(e.target.value)}>
                                <option value="hex">Hex</option>
                                <option value="text">Text</option>
                                <option value="base64">Base64</option>
                            </select>
                        </div>
                    </div>

                    <div style={{ marginBottom: '18px' }}>
                        <label style={labelStyle}>Data</label>
                        <textarea
                            style={{ ...inputStyle, minHeight: '90px', fontFamily: 'monospace' }}
                            value={data}
                            onChange={(e) => setData(e.target.value)}
                            placeholder={format === 'hex' ? 'e.g. 01 02 FF' : format === 'text' ? 'e.g. hello' : 'e.g. AQL/'}
                        />
                        <p style={{ fontSize: '12px', margin: '6px 0 0', color: byteCount === null ? '#c62828' : '#888' }}>
                            {byteCount === null
                                ? `Not valid ${format} data yet`
                                : byteCount === 0
                                    ? `Each chunk holds ${CHUNK_BYTES} bytes. Longer data is split automatically.`
                                    : chunkSizes.length === 1
                                        ? `${byteCount} bytes - 1 chunk`
                                        : `${byteCount} bytes - ${chunkSizes.length} chunks (${chunkSizes.join(' + ')} bytes)`}
                        </p>
                    </div>

                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '20px', fontSize: '14px', cursor: 'pointer' }}>
                        <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
                        Confirmed downlink (device must acknowledge)
                    </label>

                    <button
                        onClick={handleSend}
                        disabled={sending}
                        style={{ padding: '11px 28px', backgroundColor: sending ? '#95a5a6' : '#3498db', color: 'white', border: 'none', borderRadius: '6px', fontSize: '15px', fontWeight: 'bold', cursor: sending ? 'default' : 'pointer' }}
                    >
                        {sending ? 'Sending...' : (chunkSizes.length > 1 ? `Send Downlink (${chunkSizes.length} chunks)` : 'Send Downlink')}
                    </button>
                </div>
            )}

        </div>
    );
}
