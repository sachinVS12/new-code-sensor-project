import { useEffect, useState } from 'react';
import useChirpstackStatus from '../hooks/useChirpstackStatus';
import { chirpstackNote } from '../utils/chirpstack';
import { toast } from '../utils/toast';
import { confirmDialog } from '../utils/confirm';

const EMPTY_FORM = {
    deviceName: '',
    devEui: '',
    applicationId: '',
    mqttTopic: '',
    mode: 'OTAA',
    gateway: '',
    deviceProfileId: '',   // ChirpStack only
    appKey: ''             // ChirpStack only (OTAA)
};

// Node Creation Page Component
export default function NodeCreationPage({ isCollapsed }) {
    const [activeTab, setActiveTab] = useState('creation');
    const [formData, setFormData] = useState({ ...EMPTY_FORM });
    const chirpstack = useChirpstackStatus();
    const defaultProfileId = chirpstack.defaultDeviceProfileId || (chirpstack.deviceProfiles[0] && chirpstack.deviceProfiles[0].id) || '';
    const [devices, setDevices] = useState([]);
    const [gateways, setGateways] = useState([]);
    const [editingIndex, setEditingIndex] = useState(null);

    // Load gateways from API on component mount
    useEffect(() => {
        fetchGateways();
    }, []);

    // Load devices from API on component mount
    useEffect(() => {
        fetchDevices();
    }, []);

    const fetchGateways = async () => {
        try {
            const response = await fetch('/api/gateways');
            const data = await response.json();
            setGateways(data);
        } catch (error) {
            console.error('Error fetching gateways:', error);
        }
    };

    const fetchDevices = async () => {
        try {
            const response = await fetch('/api/nodes');
            const data = await response.json();
            setDevices(data);
        } catch (error) {
            console.error('Error fetching devices:', error);
        }
    };

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };

    const tabContainerStyle = {
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
        overflow: 'hidden'
    };

    const tabHeaderStyle = {
        display: 'flex',
        borderBottom: '2px solid #ecf0f1'
    };

    const tabStyle = {
        padding: '15px 30px',
        cursor: 'pointer',
        backgroundColor: '#f8f9fa',
        border: 'none',
        fontSize: '16px',
        fontWeight: 'bold',
        color: '#666',
        transition: 'all 0.3s'
    };

    const activeTabStyle = {
        ...tabStyle,
        backgroundColor: 'white',
        color: '#3498db',
        borderBottom: '2px solid #3498db'
    };

    const tabContentStyle = {
        padding: '30px'
    };

    // Form sits on the left, fields all the same width and height
    const formStyle = {
        maxWidth: '600px',
        margin: 0,
        textAlign: 'left'
    };

    const inputStyle = {
        display: 'block',
        width: '100%',
        height: '44px',
        padding: '0 12px',
        margin: 0,
        boxSizing: 'border-box',
        border: '1px solid #ddd',
        borderRadius: '4px',
        fontSize: '14px',
        fontFamily: 'inherit',
        backgroundColor: 'white'
    };

    const selectStyle = {
        display: 'block',
        width: '100%',
        height: '44px',
        padding: '0 12px',
        margin: 0,
        boxSizing: 'border-box',
        border: '1px solid #ddd',
        borderRadius: '4px',
        fontSize: '14px',
        fontFamily: 'inherit',
        backgroundColor: 'white'
    };

    const labelStyle = {
        display: 'block',
        marginBottom: '6px',
        textAlign: 'left',
        fontWeight: 'bold',
        color: '#333'
    };

    const buttonStyle = {
        width: '100%',
        padding: '12px',
        backgroundColor: '#3498db',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        fontSize: '16px',
        fontWeight: 'bold',
        cursor: 'pointer'
    };

    const tableStyle = {
        width: '100%',
        borderCollapse: 'collapse'
    };

    const thStyle = {
        backgroundColor: '#34495e',
        color: 'white',
        padding: '12px',
        textAlign: 'left',
        fontWeight: 'bold',
        borderBottom: '2px solid #2c3e50'
    };

    const tdStyle = {
        padding: '12px',
        borderBottom: '1px solid #ecf0f1',
        color: '#333'
    };

    const editButtonStyle = {
        padding: '6px 12px',
        backgroundColor: '#f39c12',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        marginRight: '5px',
        fontSize: '12px'
    };

    const deleteButtonStyle = {
        padding: '6px 12px',
        backgroundColor: '#e74c3c',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '12px'
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        try {
            const isEditing = editingIndex !== null;
            const response = await fetch(isEditing ? `/api/nodes/${editingIndex}` : '/api/nodes', {
                method: isEditing ? 'PUT' : 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ ...formData, deviceProfileId: isEditing ? formData.deviceProfileId : (formData.deviceProfileId || defaultProfileId) })
            });

            const result = await response.json();

            if (response.ok) {
                toast.success((isEditing ? 'Device updated successfully!' : 'Device created successfully!') + chirpstackNote(result.chirpstack));
                setEditingIndex(null);
                fetchDevices();
                setFormData({ ...EMPTY_FORM });
            } else {
                toast.error(result.error || 'Failed to create device');
            }
        } catch (error) {
            console.error('Error creating device:', error);
            toast.error('Failed to connect to server');
        }
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleEdit = (device) => {
        setFormData({
            deviceName: device.deviceName,
            devEui: device.devEui,
            applicationId: device.applicationId,
            mqttTopic: device.mqttTopic,
            mode: device.mode,
            gateway: device.gateway,
            deviceProfileId: '',
            appKey: ''
        });
        setEditingIndex(device._id);
        setActiveTab('creation');
    };

    const handleDelete = async (id) => {
        const ok = await confirmDialog({
            title: 'Delete device?',
            message: 'This device will be removed from the dashboard. If ChirpStack sync is on, it is removed from ChirpStack too.',
            confirmText: 'Delete'
        });
        if (!ok) return;
        
        try {
            const response = await fetch(`/api/nodes/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                const result = await response.json().catch(() => ({}));
                toast.success('Device deleted successfully!' + chirpstackNote(result.chirpstack));
                fetchDevices();
            } else {
                toast.error('Failed to delete device');
            }
        } catch (error) {
            console.error('Error deleting device:', error);
            toast.error('Failed to connect to server');
        }
    };

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '30px' }}>Device Management</h2>
            
            <div style={tabContainerStyle}>
                <div style={tabHeaderStyle}>
                    <button
                        style={activeTab === 'creation' ? activeTabStyle : tabStyle}
                        onClick={() => setActiveTab('creation')}
                    >
                        Device Creation
                    </button>
                    <button
                        style={activeTab === 'list' ? activeTabStyle : tabStyle}
                        onClick={() => setActiveTab('list')}
                    >
                        Device List
                    </button>
                </div>

                <div style={tabContentStyle}>
                    {activeTab === 'creation' && (
                        <div style={formStyle}>
                            <h3 style={{ marginBottom: '20px', color: '#666' }}>
                                {editingIndex !== null ? 'Edit Device' : 'Create New Device'}
                            </h3>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Device Name</label>
                                <input
                                    type="text"
                                    name="deviceName"
                                    value={formData.deviceName}
                                    onChange={handleChange}
                                    style={inputStyle}
                                    placeholder="Enter device name (e.g., mohan, lucky)"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Device EUI</label>
                                <input
                                    type="text"
                                    name="devEui"
                                    value={formData.devEui}
                                    onChange={handleChange}
                                    style={inputStyle}
                                    placeholder="Enter device EUI (e.g., 50c6c10d19c40cce)"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Application ID</label>
                                <input
                                    type="text"
                                    name="applicationId"
                                    value={formData.applicationId}
                                    onChange={handleChange}
                                    style={inputStyle}
                                    placeholder="Enter application ID"
                                    required
                                />
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Mode</label>
                                <select
                                    name="mode"
                                    value={formData.mode}
                                    onChange={handleChange}
                                    style={selectStyle}
                                >
                                    <option value="OTAA">OTAA</option>
                                    <option value="ABP">ABP</option>
                                </select>
                            </div>
                            <div style={{ marginBottom: '20px' }}>
                                <label style={labelStyle}>Gateway (optional)</label>
                                <select
                                    name="gateway"
                                    value={formData.gateway}
                                    onChange={handleChange}
                                    style={selectStyle}
                                >
                                    <option value="">No gateway</option>
                                    {gateways.map((gateway, index) => (
                                        <option key={index} value={gateway.gatewayName}>
                                            {gateway.gatewayName}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            {chirpstack.enabled && (
                                <>
                                    <div style={{ marginBottom: '20px' }}>
                                        <label style={labelStyle}>ChirpStack Device Profile</label>
                                        {chirpstack.deviceProfiles.length > 0 ? (
                                            <select
                                                name="deviceProfileId"
                                                value={editingIndex !== null ? formData.deviceProfileId : (formData.deviceProfileId || defaultProfileId)}
                                                onChange={handleChange}
                                                style={selectStyle}
                                            >
                                                {editingIndex !== null && <option value="">Keep current profile</option>}
                                                {chirpstack.deviceProfiles.map((p) => (
                                                    <option key={p.id} value={p.id}>{p.name}</option>
                                                ))}
                                            </select>
                                        ) : (
                                            <input
                                                type="text"
                                                name="deviceProfileId"
                                                value={editingIndex !== null ? formData.deviceProfileId : (formData.deviceProfileId || defaultProfileId)}
                                                onChange={handleChange}
                                                style={inputStyle}
                                                placeholder={editingIndex !== null ? 'Leave empty to keep the current profile' : 'Device profile ID from ChirpStack'}
                                            />
                                        )}
                                    </div>
                                    {formData.mode === 'OTAA' && (
                                        <div style={{ marginBottom: '20px' }}>
                                            <label style={labelStyle}>Application Key (AppKey)</label>
                                            <input
                                                type="text"
                                                name="appKey"
                                                value={formData.appKey}
                                                onChange={handleChange}
                                                style={inputStyle}
                                                maxLength={32}
                                                placeholder={editingIndex !== null ? 'Leave empty to keep the current key' : '32 hex characters, saved as the device key in ChirpStack'}
                                            />
                                        </div>
                                    )}
                                </>
                            )}
                            <p style={{ fontSize: '12px', color: chirpstack.enabled ? '#2e7d32' : '#888', margin: '0 0 12px 0' }}>
                                {chirpstack.enabled
                                    ? 'ChirpStack sync is ON: creating, editing and deleting this device also does it in ChirpStack (the Application ID must already exist there).'
                                    : 'ChirpStack sync is OFF. Set CHIRPSTACK_API_URL and CHIRPSTACK_API_TOKEN in backend/.env to create devices in ChirpStack too.'}
                                {chirpstack.error ? ` (${chirpstack.error})` : ''}
                            </p>
                            <p style={{ fontSize: '12px', color: '#888', margin: '0 0 20px 0' }}>
                                The MQTT topic is generated automatically from the Application ID and Device EUI,
                                saved with the device, and subscribed to as soon as the device is created.
                            </p>
                            <button style={buttonStyle} onClick={handleSubmit}>
                                {editingIndex !== null ? 'Update Device' : 'Create Device'}
                            </button>
                            {editingIndex !== null && (
                                <button
                                    style={{ ...buttonStyle, backgroundColor: '#95a5a6', marginTop: '10px' }}
                                    onClick={() => {
                                        setEditingIndex(null);
                                        setFormData({ ...EMPTY_FORM });
                                    }}
                                >
                                    Cancel
                                </button>
                            )}
                        </div>
                    )}

                    {activeTab === 'list' && (
                        <div>
                            <h3 style={{ marginBottom: '20px', color: '#666' }}>Device List</h3>
                            <table style={tableStyle}>
                                <thead>
                                    <tr>
                                        <th style={thStyle}>Device Name</th>
                                        <th style={thStyle}>Device EUI</th>
                                        <th style={thStyle}>Application ID</th>
                                        <th style={thStyle}>Mode</th>
                                        <th style={thStyle}>Gateway</th>
                                        <th style={thStyle}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {devices.length === 0 ? (
                                        <tr>
                                            <td colSpan="6" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                                No devices available
                                            </td>
                                        </tr>
                                    ) : (
                                        devices.map((device) => (
                                            <tr key={device._id}>
                                                <td style={tdStyle}>{device.deviceName}</td>
                                                <td style={tdStyle}>{device.devEui}</td>
                                                <td style={tdStyle}>{device.applicationId}</td>
                                                <td style={tdStyle}>{device.mode}</td>
                                                <td style={tdStyle}>{device.gateway}</td>
                                                <td style={tdStyle}>
                                                    <button
                                                        style={editButtonStyle}
                                                        onClick={() => handleEdit(device)}
                                                    >
                                                        Edit
                                                    </button>
                                                    <button
                                                        style={deleteButtonStyle}
                                                        onClick={() => handleDelete(device._id)}
                                                    >
                                                        Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
