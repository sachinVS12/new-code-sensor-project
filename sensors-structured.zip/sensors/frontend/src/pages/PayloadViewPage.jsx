import PayloadSamplesChart from '../components/charts/PayloadSamplesChart';
import PayloadSamplesHistoryChart from '../components/charts/PayloadSamplesHistoryChart';

// Payload view for one device - opened from the Tabular View icons.
// mode: 'history' = Payload History graph, 'latest' = Payload Latest graph
export default function PayloadViewPage({ device, mode, history = [], onExit, isCollapsed }) {
    const isHistory = mode === 'history';

    // Latest: prefer the newest complete payload, otherwise the newest entry (chunk still arriving)
    const complete = history.filter(p => !p.isChunk);
    const latestOnly = complete.length ? [complete[complete.length - 1]] : history.slice(-1);

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };

    const cardStyle = {
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
    };

    return (
        <div style={pageStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h2 style={{ margin: 0 }}>
                    {isHistory ? 'Payload History' : 'Payload Latest'} - {device ? device.deviceName : ''}
                </h2>
                <button
                    onClick={onExit}
                    title="Exit to Tabular View"
                    aria-label="Exit to Tabular View"
                    style={{
                        display: 'flex', alignItems: 'center', gap: '8px',
                        padding: '8px 16px', backgroundColor: 'white', color: '#d93025',
                        border: '1px solid #d93025', borderRadius: '6px', cursor: 'pointer',
                        fontSize: '14px', fontWeight: 'bold'
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#fce8e6')}
                    onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'white')}
                >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                        <polyline points="16 17 21 12 16 7" />
                        <line x1="21" y1="12" x2="9" y2="12" />
                    </svg>
                    Exit
                </button>
            </div>

            <div style={cardStyle}>
                {history.length === 0 ? (
                    <p style={{ color: '#999', textAlign: 'center', padding: '40px 0' }}>
                        No payload received from this device yet. The graph appears when its next uplink arrives.
                    </p>
                ) : isHistory ? (
                    <PayloadSamplesHistoryChart payloadHistory={history} />
                ) : (
                    <PayloadSamplesChart payloadHistory={latestOnly} />
                )}
            </div>
        </div>
    );
}
