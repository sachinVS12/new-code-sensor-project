import { useState } from 'react';
import PayloadSamplesChart from '../components/charts/PayloadSamplesChart';
import PayloadSamplesHistoryChart from '../components/charts/PayloadSamplesHistoryChart';
import PayloadHistoryTable from '../components/payload/PayloadHistoryTable';
import { exportPayloadHistoryXlsx } from '../utils/exportPayloadHistory';
import { toast } from '../utils/toast';

// Payload view for one device - opened from the Tabular View icons.
// mode: 'history' = Payload History graph, 'latest' = Payload Latest graph
export default function PayloadViewPage({ device, mode, history = [], onExit, isCollapsed }) {
    const isHistory = mode === 'history';
    const [view, setView] = useState('graph'); // Payload History: 'graph' or 'table'

    const handleExport = () => {
        try {
            const fileName = exportPayloadHistoryXlsx(history, device);
            if (fileName) toast.success(`Exported ${history.length} entries to ${fileName}`);
            else toast.warning('No payload history to export yet');
        } catch (err) {
            console.error('Excel export failed:', err);
            toast.error('Could not create the Excel file');
        }
    };

    const tabStyle = (active) => ({
        padding: '8px 16px', border: 'none', cursor: 'pointer', fontSize: '14px', fontWeight: 'bold',
        backgroundColor: active ? '#1e3a8a' : 'white', color: active ? 'white' : '#1e3a8a'
    });

    // Latest: prefer the newest complete payload, otherwise the newest entry (chunk still arriving)
    const complete = history.filter(p => !p.isChunk);
    const latestOnly = complete.length ? [complete[complete.length - 1]] : history.slice(-1);

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };

    const cardStyle = {
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
    };

    return (
        <div style={pageStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h2 style={{ margin: 0 }}>
                    {isHistory ? 'Payload History' : 'Payload Latest'} - {device ? device.deviceName : ''}
                </h2>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                {isHistory && (
                    <>
                        <div role="tablist" aria-label="Payload History view" style={{ display: 'inline-flex', border: '1px solid #1e3a8a', borderRadius: '6px', overflow: 'hidden' }}>
                            <button role="tab" aria-selected={view === 'graph'} onClick={() => setView('graph')} style={tabStyle(view === 'graph')}>Graph</button>
                            <button role="tab" aria-selected={view === 'table'} onClick={() => setView('table')} style={tabStyle(view === 'table')}>Table</button>
                        </div>
                        <button
                            onClick={handleExport}
                            disabled={history.length === 0}
                            title="Download this payload history as an Excel file"
                            aria-label="Export to Excel"
                            style={{
                                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px',
                                backgroundColor: history.length === 0 ? '#e2e8f0' : '#188038', color: history.length === 0 ? '#94a3b8' : 'white',
                                border: 'none', borderRadius: '6px', cursor: history.length === 0 ? 'not-allowed' : 'pointer',
                                fontSize: '14px', fontWeight: 'bold'
                            }}
                        >
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                <polyline points="7 10 12 15 17 10" />
                                <line x1="12" y1="15" x2="12" y2="3" />
                            </svg>
                            Export to Excel
                        </button>
                    </>
                )}
                <button
                    onClick={onExit}
                    title="Exit to Tabular View"
                    aria-label="Exit to Tabular View"
                    style={{
                        display: 'flex', alignItems: 'center', gap: '8px',
                        padding: '8px 16px', backgroundColor: 'white', color: '#d93025',
                        border: '1px solid #d93025', borderRadius: '6px', cursor: 'pointer',
                        fontSize: '14px', fontWeight: 'bold'
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#fce8e6')}
                    onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'white')}
                >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                        <polyline points="16 17 21 12 16 7" />
                        <line x1="21" y1="12" x2="9" y2="12" />
                    </svg>
                    Exit
                </button>
                </div>
            </div>

            <div style={cardStyle}>
                {history.length === 0 ? (
                    <p style={{ color: '#999', textAlign: 'center', padding: '40px 0' }}>
                        No payload received from this device yet. The graph appears when its next uplink arrives.
                    </p>
                ) : isHistory && view === 'table' ? (
                    <PayloadHistoryTable history={history} />
                ) : isHistory ? (
                    <PayloadSamplesHistoryChart payloadHistory={history} />
                ) : (
                    <PayloadSamplesChart payloadHistory={latestOnly} />
                )}
            </div>
        </div>
    );
}
