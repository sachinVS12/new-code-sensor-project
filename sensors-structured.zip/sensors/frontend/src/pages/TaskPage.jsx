import { useEffect, useMemo, useRef, useState } from 'react';
import Modal from '../components/common/Modal';
import { confirmDialog } from '../utils/confirm';

// Task page - the downlink queue: everything sent from the Downlink page and its status
export default function TaskPage({ devices = [], isCollapsed }) {
    const [queue, setQueue] = useState([]);
    const [queueDevice, setQueueDevice] = useState('all');
    const [queueError, setQueueError] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');   // all | queued | transmitted | acknowledged | failed
    const lastEventAt = useRef(0);   // when the last live (WebSocket) update arrived
    const [popupKey, setPopupKey] = useState(null);   // key of the row (message) whose data popup is open

    // One row per sent message: chunks that share a messageId are merged (older entries without one stay single rows)
    const groups = useMemo(() => {
        const map = new Map();
        queue.forEach(q => {
            const key = q.messageId || q._id;
            if (!map.has(key)) map.set(key, { key, chunks: [] });
            map.get(key).chunks.push(q);
        });
        return [...map.values()].map(g => {
            g.chunks.sort((a, b) => (a.chunkIndex || 1) - (b.chunkIndex || 1));
            return { ...g, first: g.chunks[0] };
        });
    }, [queue]);

    const popupGroup = groups.find(g => g.key === popupKey) || null;

    const loadQueue = async () => {
        try {
            const startedAt = Date.now();
            const url = queueDevice === 'all' ? '/api/downlinks' : `/api/downlinks?devEui=${queueDevice}`;
            const res = await fetch(url);
            if (!res.ok) throw new Error('Failed to load queue');
            const rows = await res.json();
            if (startedAt < lastEventAt.current) return;   // a newer live update already arrived; the next refresh will catch up
            setQueue(rows);
            setQueueError('');
        } catch (err) {
            setQueueError(err.message);
        }
    };

    // fallback refresh every 3 s while this page is open (live updates arrive instantly through the event above)
    useEffect(() => {
        loadQueue();
        const t = setInterval(loadQueue, 3000);
        return () => clearInterval(t);
    }, [queueDevice]);

    // Live updates over the WebSocket: the server pushes the changed record (queued / transmitted / acknowledged /
    // failed / removed) and it is applied here directly, with no reload, so times appear the moment they happen
    useEffect(() => {
        const newestFirst = (a, b) =>
            (new Date(b.createdAt) - new Date(a.createdAt)) || ((a.chunkIndex || 1) - (b.chunkIndex || 1));

        const onUpdate = (e) => {
            const detail = e.detail || {};
            const d = detail.downlink;
            if (!d) { loadQueue(); return; }   // reconnected: reload once to catch up
            if (queueDevice !== 'all' && String(d.devEui).toLowerCase() !== String(queueDevice).toLowerCase()) return;

            lastEventAt.current = Date.now();
            setQueue(prev => {
                if (detail.event === 'deleted') return prev.filter(q => q._id !== d._id);
                const i = prev.findIndex(q => q._id === d._id);
                if (i >= 0) {
                    const next = prev.slice();
                    next[i] = d;
                    return next;
                }
                return [d, ...prev].sort(newestFirst);
            });
        };

        window.addEventListener('downlink-update', onUpdate);
        return () => window.removeEventListener('downlink-update', onUpdate);
    }, [queueDevice]);

    const handleRemove = async (group) => {
        const many = group.chunks.length > 1;
        const ok = await confirmDialog({
            title: 'Remove this entry?',
            message: `It will be removed from the list${many ? ` (all ${group.chunks.length} chunks)` : ''}.\nThis does not clear ChirpStack's own device queue.`,
            confirmText: 'Remove'
        });
        if (!ok) return;
        try {
            await Promise.all(group.chunks.map(c => fetch(`/api/downlinks/${c._id}`, { method: 'DELETE' })));
            loadQueue();
        } catch (err) {
            setQueueError('Failed to remove entry');
        }
    };

    const pageStyle = {
        marginLeft: isCollapsed ? '60px' : '250px',
        marginTop: '60px',
        padding: '30px',
        transition: 'margin-left 0.3s ease'
    };
    const cardStyle = { backgroundColor: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 10px rgba(0,0,0,0.1)' };
    const inputStyle = { width: '100%', padding: '10px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' };
    const thStyle = { padding: '12px', textAlign: 'left', backgroundColor: '#2c3e50', color: 'white', fontSize: '14px' };
    const tdStyle = { padding: '12px', borderBottom: '1px solid #eee', fontSize: '14px' };

    const EyeIcon = () => (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
        </svg>
    );

    const dataText = (q) => q.dataHex || q.data || '';
    const byteLen = (q) => (q.dataHex ? q.dataHex.length / 2 : (q.data ? atob(q.data).length : 0));

    // Status of a whole message = its least advanced chunk (any failed chunk makes it failed)
    const STATUS_RANK = { queued: 0, transmitted: 1, acknowledged: 2 };
    const groupStatus = (group) => {
        if (group.chunks.some(c => c.status === 'failed')) return 'failed';
        return group.chunks.reduce((min, c) => ((STATUS_RANK[c.status] ?? 0) < (STATUS_RANK[min] ?? 0) ? c.status : min), group.chunks[0].status);
    };
    const groupBytes = (group) => group.chunks.reduce((sum, c) => sum + byteLen(c), 0);

    // Time of a whole message for one step (transmittedAt / acknowledgedAt) = when its last chunk reached that step;
    // empty until every chunk has reached it
    const groupTime = (group, field) => {
        if (!group.chunks.every(c => c[field])) return null;
        return Math.max(...group.chunks.map(c => new Date(c[field]).getTime()));
    };
    // shown with milliseconds, because Transmitted and Acknowledged can be less than a second apart
    const fmtTime = (v) => new Date(v).toLocaleString(undefined, {
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: 'numeric', minute: '2-digit', second: '2-digit', fractionalSecondDigits: 3
    });
    // what to show when a step has no time yet: "-" if it will never happen, otherwise "Pending"
    const noTimeText = (failed, field, confirmed) =>
        (failed || (field === 'acknowledgedAt' && !confirmed)) ? '-' : 'Pending';
    const timeCell = (group, field) => {
        const t = groupTime(group, field);
        return t ? fmtTime(t) : <span style={{ color: '#999' }}>{noTimeText(group.chunks.some(c => c.status === 'failed'), field, group.first.confirmed)}</span>;
    };
    const chunkTimeText = (c, field) => (c[field] ? fmtTime(c[field]) : noTimeText(c.status === 'failed', field, c.confirmed));

    // rows shown in the table (filtered by the Status dropdown)
    const visibleGroups = statusFilter === 'all' ? groups : groups.filter(g => groupStatus(g) === statusFilter);

    const statusBadge = (status) => {
        const map = {
            queued: { bg: '#fff3e0', fg: '#e65100', label: 'Queued' },
            transmitted: { bg: '#e3f2fd', fg: '#1565c0', label: 'Transmitted' },
            acknowledged: { bg: '#e8f5e9', fg: '#2e7d32', label: 'Acknowledged' },
            failed: { bg: '#fce8e6', fg: '#c62828', label: 'Failed' }
        };
        const m = map[status] || { bg: '#eee', fg: '#333', label: status };
        return <span style={{ backgroundColor: m.bg, color: m.fg, padding: '3px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>{m.label}</span>;
    };

    return (
        <div style={pageStyle}>
            <h2 style={{ marginBottom: '20px' }}>Task</h2>
                <div style={cardStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
                        <label style={{ fontWeight: 'bold', color: '#333' }}>Device</label>
                        <select style={{ ...inputStyle, width: 'auto', minWidth: '240px' }} value={queueDevice} onChange={(e) => setQueueDevice(e.target.value)}>
                            <option value="all">All devices</option>
                            {devices.map(d => (
                                <option key={d.devEui} value={(d.devEui || '').toLowerCase()}>{d.deviceName}</option>
                            ))}
                        </select>
                        <button onClick={loadQueue} style={{ padding: '8px 16px', border: '1px solid #3498db', color: '#3498db', backgroundColor: 'white', borderRadius: '6px', cursor: 'pointer' }}>
                            Refresh
                        </button>
                        <span style={{ fontSize: '12px', color: '#888' }}>Updates every 3 seconds</span>

                        <label style={{ fontWeight: 'bold', color: '#333', marginLeft: '12px' }}>Status</label>
                        <select style={{ ...inputStyle, width: 'auto', minWidth: '170px' }} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                            <option value="all">All statuses</option>
                            <option value="queued">Queued</option>
                            <option value="transmitted">Transmitted</option>
                            <option value="acknowledged">Acknowledged</option>
                            <option value="failed">Failed</option>
                        </select>
                    </div>

                    {queueError && <p style={{ color: '#c62828' }}>{queueError}</p>}

                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Queued Time</th>
                                    <th style={thStyle}>Transmitted Time</th>
                                    <th style={thStyle}>Acknowledged Time</th>
                                    <th style={thStyle}>Device</th>
                                    <th style={thStyle}>FPort</th>
                                    <th style={thStyle}>Confirmed</th>
                                    <th style={thStyle}>Data (hex)</th>
                                    <th style={thStyle}>Status</th>
                                    <th style={{ ...thStyle, textAlign: 'center' }}>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                {visibleGroups.length === 0 ? (
                                    <tr><td colSpan="9" style={{ ...tdStyle, textAlign: 'center', color: '#999' }}>
                                        {groups.length === 0 ? 'Queue is empty' : 'No entries with this status'}
                                    </td></tr>
                                ) : visibleGroups.map((g, i) => {
                                    const q = g.first;
                                    const sent = g.chunks.filter(c => (STATUS_RANK[c.status] ?? 0) >= 1).length;
                                    const mixed = g.chunks.length > 1 && new Set(g.chunks.map(c => c.status)).size > 1;
                                    return (
                                        <tr key={g.key} style={{ backgroundColor: i % 2 === 0 ? 'white' : '#f8f9fa' }}>
                                            <td style={tdStyle}>{fmtTime(q.createdAt)}</td>
                                            <td style={tdStyle}>{timeCell(g, 'transmittedAt')}</td>
                                            <td style={tdStyle}>{timeCell(g, 'acknowledgedAt')}</td>
                                            <td style={tdStyle}>{q.deviceName || q.devEui}</td>
                                            <td style={tdStyle}>{q.fPort}</td>
                                            <td style={tdStyle}>{q.confirmed ? 'Yes' : 'No'}</td>
                                            <td style={tdStyle}>
                                                <button
                                                    onClick={() => setPopupKey(g.key)}
                                                    title="View data"
                                                    aria-label="View data"
                                                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#3498db', padding: 0, verticalAlign: 'middle' }}
                                                >
                                                    <EyeIcon />
                                                </button>
                                                <span style={{ marginLeft: '8px', fontSize: '12px', color: '#888' }}>
                                                    {groupBytes(g)} bytes{g.chunks.length > 1 ? ` - ${g.chunks.length} chunks` : ''}
                                                </span>
                                            </td>
                                            <td style={tdStyle}>
                                                {statusBadge(groupStatus(g))}
                                                {mixed && <div style={{ fontSize: '11px', color: '#888', marginTop: '4px' }}>{sent} of {g.chunks.length} sent</div>}
                                            </td>
                                            <td style={{ ...tdStyle, textAlign: 'center' }}>
                                                <button
                                                    onClick={() => handleRemove(g)}
                                                    title="Remove from list"
                                                    aria-label="Remove from list"
                                                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#c62828', fontSize: '16px' }}
                                                >✕</button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>

            {popupGroup && (
                <Modal title="Downlink data" onClose={() => setPopupKey(null)}>
                    <p style={{ margin: '0 0 16px', padding: '10px 14px', fontSize: '14px', color: '#334155', backgroundColor: '#f1f5f9', borderRadius: '10px' }}>
                        {popupGroup.first.deviceName || popupGroup.first.devEui} &middot; FPort {popupGroup.first.fPort} &middot; {groupBytes(popupGroup)} bytes
                        {popupGroup.chunks.length > 1 && <> &middot; {popupGroup.chunks.length} chunks</>}
                    </p>
                    {popupGroup.chunks.map((c, i) => (
                        <div key={c._id} style={{ marginBottom: i === popupGroup.chunks.length - 1 ? 0 : '16px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                                <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#333' }}>
                                    {popupGroup.chunks.length > 1 ? `Chunk ${c.chunkIndex || i + 1} - ` : ''}{byteLen(c)} bytes
                                </span>
                                {statusBadge(c.status)}
                            </div>
                            <div style={{ fontFamily: 'monospace', fontSize: '14px', wordBreak: 'break-all', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '10px', padding: '12px' }}>
                                {dataText(c)}
                            </div>
                            <div style={{ margin: '6px 0 0', fontSize: '12px', color: '#888', lineHeight: '1.6' }}>
                                <div>Queued: {fmtTime(c.createdAt)}</div>
                                <div>Transmitted: {chunkTimeText(c, 'transmittedAt')}</div>
                                <div>Acknowledged: {chunkTimeText(c, 'acknowledgedAt')}</div>
                            </div>
                            {c.status === 'failed' && c.error && (
                                <p style={{ margin: '6px 0 0', fontSize: '12px', color: '#c62828' }}>{c.error}</p>
                            )}
                        </div>
                    ))}
                </Modal>
            )}
        </div>
    );
}
