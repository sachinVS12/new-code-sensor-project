// Every request to /api sends the login cookie by itself. When the server answers 401 (session ended or not
// logged in) on a data request, the app is told with an "auth-expired" event and shows the login page again.
export function installAuthFetch() {
    const nativeFetch = window.fetch.bind(window);
    window.fetch = async (...args) => {
        const res = await nativeFetch(...args);
        const first = args[0];
        const url = typeof first === 'string' ? first : (first && first.url) || '';
        if (res.status === 401 && url.startsWith('/api/') && !url.startsWith('/api/auth/')) {
            window.dispatchEvent(new Event('auth-expired'));
        }
        return res;
    };
}
