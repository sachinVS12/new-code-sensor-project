// Extra lines for the success alert, from the "chirpstack" part of the backend response
export function chirpstackNote(cs) {
    if (!cs || !cs.enabled) return '';
    let note = '';
    if (cs.created) note += '\nAlso created in ChirpStack.';
    if (cs.updated) note += '\nAlso updated in ChirpStack.';
    if (cs.replaced) note += '\nChirpStack cannot change an EUI or Application in place, so it was created again there and the old one removed.';
    if (cs.regionSaved) note += '\nRegion saved in ChirpStack (gateway tag "region_id").';
    if (cs.alreadyExisted) note += '\nIt already existed in ChirpStack, so it was only linked here.';
    if (cs.deleted) note += '\nAlso removed from ChirpStack.';
    if (cs.notFound) note += '\nIt was not found in ChirpStack, so nothing was removed there.';
    if (cs.warning) note += '\nNote: ' + cs.warning;
    return note;
}
