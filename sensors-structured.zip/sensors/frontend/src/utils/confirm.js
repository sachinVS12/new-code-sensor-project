// Confirm pop-up (replaces the browser's confirm() box). Returns a promise that resolves to true / false:
//   if (!(await confirmDialog({ title: 'Delete gateway?', message: '...', confirmText: 'Delete' }))) return;
// Options: title, message, confirmText, cancelText, variant ('danger' = red button, 'primary' = blue).
// The <ConfirmDialogHost /> in App.jsx shows it.
export function confirmDialog(options) {
    const opts = typeof options === 'string' ? { message: options } : options;
    return new Promise((resolve) => {
        window.dispatchEvent(new CustomEvent('app-confirm', { detail: { ...opts, resolve } }));
    });
}
