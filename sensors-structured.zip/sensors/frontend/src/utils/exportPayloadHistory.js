import * as XLSX from 'xlsx';
import { payloadHistorySheets, payloadEntrySheets, payloadHistoryFileName } from './payload';

// dates and times are shown with the time of day (without dateNF Excel shows only the date)
const DATE_FORMAT = 'yyyy-mm-dd hh:mm:ss';

function makeSheet(aoa, widths) {
    const ws = XLSX.utils.aoa_to_sheet(aoa, { cellDates: true, dateNF: DATE_FORMAT });
    ws['!cols'] = widths.map((wch) => ({ wch }));
    return ws;
}

function writeWorkbook(sheetList, fileName) {
    const wb = XLSX.utils.book_new();
    for (const [name, aoa, widths] of sheetList) XLSX.utils.book_append_sheet(wb, makeSheet(aoa, widths), name);
    XLSX.writeFile(wb, fileName, { cellDates: true });
}

// Downloads the whole Payload History of one device as an .xlsx file (sheets: Summary, Chunks, Samples, Info).
// Returns the file name, or null when there is nothing to export.
export function exportPayloadHistoryXlsx(history, device) {
    if (!history || history.length === 0) return null;
    const fileName = payloadHistoryFileName(device);
    const sheets = payloadHistorySheets(history, device);
    writeWorkbook([
        ['Summary', sheets.summary, [8, 22, 11, 9, 14, 9, 8, 8, 10, 9]],
        ['Chunks', sheets.chunks, [9, 22, 9, 15, 22, 16, 8, 8, 14, 14]],
        ['Samples', sheets.samples, [9, 22, 11, 9, 10, 9]],
        ['Info', sheets.info, [16, 28]]
    ], fileName);
    return fileName;
}

// Downloads one entry (a row of payloadHistoryRows) as an .xlsx file. Returns the file name.
//  sheet 1 "Chunk values": every chunk as a column with ALL its values printed underneath (+ totals)
//  sheet 2 "Samples":      every value in one list, with the chunk it came from
export function exportPayloadEntryXlsx(row, device) {
    if (!row) return null;
    const fileName = payloadHistoryFileName(device, new Date(), row.no);
    const sheets = payloadEntrySheets(row, device);
    const chunkColumns = sheets.grid[11].length - 1; // the "Chunk #" row: label + one cell per chunk
    writeWorkbook([
        ['Chunk values', sheets.grid, [18, ...Array(chunkColumns).fill(21)]], // 21 wide: the date and time (yyyy-mm-dd hh:mm:ss) must fit, or Excel shows ###
        ['Samples', sheets.samples, [9, 22, 11, 9, 10, 9]]
    ], fileName);
    return fileName;
}
