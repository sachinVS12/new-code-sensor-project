import * as XLSX from 'xlsx';
import { payloadHistorySheets, payloadEntrySheets, payloadHistoryFileName } from './payload';

function writeWorkbook(sheets, fileName) {
    const make = (aoa, widths) => {
        const ws = XLSX.utils.aoa_to_sheet(aoa, { cellDates: true });
        ws['!cols'] = widths.map((wch) => ({ wch }));
        return ws;
    };
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, make(sheets.summary, [6, 22, 11, 12, 9, 8, 8, 10, 9]), 'Summary');
    XLSX.utils.book_append_sheet(wb, make(sheets.samples, [9, 22, 11, 10, 9]), 'Samples');
    XLSX.utils.book_append_sheet(wb, make(sheets.info, [14, 28]), 'Info');
    XLSX.writeFile(wb, fileName, { cellDates: true });
}

// Downloads the whole Payload History of one device as an .xlsx file (sheets: Summary, Samples, Info).
// Returns the file name, or null when there is nothing to export.
export function exportPayloadHistoryXlsx(history, device) {
    if (!history || history.length === 0) return null;
    const fileName = payloadHistoryFileName(device);
    writeWorkbook(payloadHistorySheets(history, device), fileName);
    return fileName;
}

// Downloads one entry (a row of payloadHistoryRows) as an .xlsx file, same sheets as above. Returns the file name.
export function exportPayloadEntryXlsx(row, device) {
    if (!row) return null;
    const fileName = payloadHistoryFileName(device, new Date(), row.no);
    writeWorkbook(payloadEntrySheets(row, device), fileName);
    return fileName;
}
