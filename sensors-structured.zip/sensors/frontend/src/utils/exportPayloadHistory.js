import * as XLSX from 'xlsx';
import { payloadHistorySheets, payloadHistoryFileName } from './payload';

// Downloads the Payload History of one device as an .xlsx file (sheets: Summary, Samples, Info).
// Returns the file name, or null when there is nothing to export.
export function exportPayloadHistoryXlsx(history, device) {
    if (!history || history.length === 0) return null;
    const sheets = payloadHistorySheets(history, device);
    const make = (aoa, widths) => {
        const ws = XLSX.utils.aoa_to_sheet(aoa, { cellDates: true });
        ws['!cols'] = widths.map((wch) => ({ wch }));
        return ws;
    };
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, make(sheets.summary, [6, 22, 11, 12, 9, 8, 8, 10, 9]), 'Summary');
    XLSX.utils.book_append_sheet(wb, make(sheets.samples, [9, 22, 11, 10, 9]), 'Samples');
    XLSX.utils.book_append_sheet(wb, make(sheets.info, [14, 28]), 'Info');
    const fileName = payloadHistoryFileName(device);
    XLSX.writeFile(wb, fileName, { cellDates: true });
    return fileName;
}
