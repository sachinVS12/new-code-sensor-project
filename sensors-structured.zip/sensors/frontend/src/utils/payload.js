// Packet type shown in the Tabular View. Chunk devices send it in the 3-byte header
// (0 = single dataset, 1 = batch dataset, 2 = probe, 3 = packed 12-bit dataset); other devices send a number in decodedPayload.type.
const CHUNK_TYPE_LABELS = { 0: 'Single', 1: 'Batch', 2: 'Probe', 3: 'Packed 12-bit' };
export function packetTypeOf(dp) {
    if (!dp) return undefined;
    if (dp.kind === 'probe') return 'Probe';
    if (dp.header) return CHUNK_TYPE_LABELS[dp.header.type] ?? `Type ${dp.header.type}`;
    return dp.type;
}

// Adds one decoded uplink to a payload history list (same rules the Graph page uses)
export function applyPayloadEntry(prev, dp, time, at = null) {
    if (!dp) return prev;
    if (dp.kind === 'chunk' && dp.chunkSamples) {
        return [...prev, {
            time,
            at,
            samples: dp.chunkSamples,
            avg: null,
            min: Math.min(...dp.chunkSamples),
            max: Math.max(...dp.chunkSamples),
            battery: dp.battery || 'N/A',
            isChunk: true,
            progress: `${dp.receivedChunks}/${dp.totalChunks} chunks`,
            chunkIndex: dp.header?.chunk ?? null, // which chunk this entry is (0-based, as the node sent it)
            totalChunks: dp.totalChunks ?? null
        }].slice(-100);
    }
    if (dp.kind === 'dataset' && dp.samples) {
        const filtered = prev.filter(p => !p.isChunk);
        // the finished dataset keeps the list of chunks it was built from (index, sample count, arrival time)
        filtered.push({ time, at, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.battery || 'N/A', isChunk: false, chunks: dp.chunks || null, totalChunks: dp.totalChunks ?? null });
        return filtered.slice(-100);
    }
    if (dp.samples) {
        return [...prev, { time, at, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.batteryV, isChunk: false }].slice(-100);
    }
    return prev;
}

// ── Payload History: table rows and Excel sheets (pure functions, no browser or xlsx needed) ──

// The chunks an entry is made of: [{ index, sampleCount, receivedAt, samples }] in chunk order.
//  - a finished dataset: the chunks the decoder reported, cut out of its samples (chunk 0 first)
//  - a chunk that is still arriving: that one chunk
//  - anything else (e.g. a RAK5146 payload): no chunks
function chunkListOf(p, samples) {
    if (p.isChunk) {
        if (p.chunkIndex === null || p.chunkIndex === undefined) return [];
        return [{ index: p.chunkIndex, sampleCount: samples.length, receivedAt: p.at ?? null, samples }];
    }
    if (!Array.isArray(p.chunks) || p.chunks.length === 0) return [];
    let pos = 0;
    const list = p.chunks.map((c) => {
        const part = samples.slice(pos, pos + c.sampleCount);
        pos += c.sampleCount;
        return { index: c.index, sampleCount: c.sampleCount, receivedAt: c.receivedAt ?? null, samples: part };
    });
    return pos === samples.length ? list : []; // chunk sizes that do not add up to the data: do not guess
}

// one summary row per history entry, oldest first (# = position in the history)
export function payloadHistoryRows(history = []) {
    return history.map((p, i) => {
        const when = p.at ? new Date(p.at) : null;
        const samples = p.samples || [];
        const chunkList = chunkListOf(p, samples);
        // chunkCount = how many chunks this row stands for: a finished dataset = all its chunks, a chunk row = 1, no chunks = 0
        const chunkCount = p.isChunk ? chunkList.length : chunkList.length || (Number.isInteger(p.totalChunks) ? p.totalChunks : 0);
        const chunkText = p.isChunk ? (p.progress || '') : chunkCount > 0 ? `${chunkCount}/${p.totalChunks ?? chunkCount} chunks` : '';
        return {
            no: i + 1,
            time: p.time || '',
            when: when && !Number.isNaN(when.getTime()) ? when : null,
            type: p.isChunk ? 'Chunk' : 'Complete',
            chunks: chunkText,
            chunkCount,
            chunkList,
            sampleCount: samples.length,
            min: p.min ?? null,
            max: p.max ?? null,
            avg: p.avg ?? null,
            battery: p.battery === 'N/A' ? null : (p.battery ?? null), // no battery reported -> empty cell, not the text N/A
            samples
        };
    });
}

// totals shown under the table and in the Excel file. Every chunk is counted once: a finished dataset counts all its
// chunks, a chunk that is still arriving counts 1 (its dataset has no Complete row yet, so nothing is counted twice).
export function payloadHistoryTotals(rows = []) {
    return {
        entries: rows.length,
        chunks: rows.reduce((n, r) => n + r.chunkCount, 0),
        samples: rows.reduce((n, r) => n + r.sampleCount, 0)
    };
}

const SUMMARY_HEADER = ['#', 'Date & time', 'Type', 'Chunks', 'Progress', 'Samples', 'Min', 'Max', 'Average', 'Battery'];
const CHUNKS_HEADER = ['Entry #', 'Entry date & time', 'Chunk #', 'Index (as sent)', 'Received at', 'Samples in chunk', 'Min', 'Max', 'First sample #', 'Last sample #'];
const SAMPLES_HEADER = ['Entry #', 'Date & time', 'Type', 'Chunk #', 'Sample #', 'Value'];

// a total is an Excel formula (so it can be checked in the file) with its value stored next to it
const formulaCell = (formula, value) => ({ t: 'n', f: formula, v: value });

// the sheets of an Excel file, as arrays of rows (numbers stay numbers, empty cells stay empty)
function sheetsFromRows(rows, infoLines, exportedAt) {
    const stamp = (r) => r.when || r.time;
    const totals = payloadHistoryTotals(rows);
    const n = rows.length;

    // Summary: one row per entry + a Total row (SUM of the Chunks and Samples columns)
    const summary = [
        SUMMARY_HEADER,
        ...rows.map((r) => [r.no, stamp(r), r.type, r.chunkCount || null, r.chunks || null, r.sampleCount, r.min, r.max, r.avg, r.battery]),
        ['Total', null, null, formulaCell(`SUM(D2:D${n + 1})`, totals.chunks), null, formulaCell(`SUM(F2:F${n + 1})`, totals.samples), null, null, null, null]
    ];

    // Chunks: one row per chunk of every entry + a Total row (COUNT of the chunk rows, SUM of their samples)
    const chunkRows = [];
    for (const r of rows) {
        let first = 1;
        for (const c of r.chunkList) {
            chunkRows.push([
                r.no, stamp(r), c.index + 1, c.index, c.receivedAt ? new Date(c.receivedAt) : null, c.sampleCount,
                c.samples.length ? Math.min(...c.samples) : null, c.samples.length ? Math.max(...c.samples) : null,
                c.sampleCount ? first : null, c.sampleCount ? first + c.sampleCount - 1 : null
            ]);
            first += c.sampleCount;
        }
    }
    const m = chunkRows.length;
    const chunkSamples = chunkRows.reduce((sum, row) => sum + row[5], 0);
    const chunks = [
        CHUNKS_HEADER,
        ...chunkRows,
        m > 0
            ? ['Total', null, formulaCell(`COUNT(C2:C${m + 1})`, m), null, null, formulaCell(`SUM(F2:F${m + 1})`, chunkSamples), null, null, null, null]
            : ['Total', null, 0, null, null, 0, null, null, null, null]
    ];

    // Samples: one row per sample, with the chunk it came from
    const samples = [
        SAMPLES_HEADER,
        ...rows.flatMap((r) => {
            if (r.chunkList.length === 0) return r.samples.map((v, i) => [r.no, stamp(r), r.type, null, i + 1, v]);
            let pos = 0;
            return r.chunkList.flatMap((c) => c.samples.map((v) => [r.no, stamp(r), r.type, c.index + 1, ++pos, v]));
        })
    ];

    return {
        info: [...infoLines, ['Total chunks', totals.chunks], ['Total samples', totals.samples], ['Exported at', exportedAt]],
        summary,
        chunks,
        samples
    };
}

// whole Payload History of a device
export function payloadHistorySheets(history = [], device = {}, exportedAt = new Date()) {
    const rows = payloadHistoryRows(history);
    return sheetsFromRows(rows, [['Device', device.deviceName || ''], ['DevEUI', device.devEui || ''], ['Entries', rows.length]], exportedAt);
}

// Excel column letter of the n-th column (1 = A, 26 = Z, 27 = AA ...)
export function excelColumn(n) {
    let name = '';
    for (let k = n; k > 0; k = Math.floor((k - 1) / 26)) name = String.fromCharCode(65 + ((k - 1) % 26)) + name;
    return name;
}

// The "Chunk values" sheet of the eye-icon download: every chunk of the entry is one COLUMN and its values are printed
// underneath it in the order they were received, so a complete dataset shows all its chunks side by side.
//
//   Device / DevEUI / Entry # / Date & time / Type / Total chunks / Total samples / Min / Max / Average
//   Chunk #           1         2         3   ...   29
//   Received at       ...
//   Samples in chunk  142       142       142 ...   120
//   Min / Max         ...
//   Value 1           2115      ...
//   Value 2           2131      ...
//
// "Total chunks" and "Total samples" are formulas over the Chunk # and Samples in chunk rows (value stored next to them).
export function payloadEntryGrid(row, device = {}) {
    const blocks = row.chunkList.length
        ? row.chunkList
        : [{ index: null, receivedAt: null, sampleCount: row.sampleCount, samples: row.samples }]; // no chunks (e.g. RAK5146): one column
    const last = excelColumn(blocks.length + 1); // chunk columns are B ... last
    const HEAD = 12; // row of "Chunk #"; "Samples in chunk" is HEAD + 2
    const maxLen = Math.max(0, ...blocks.map((b) => b.samples.length));
    const minOf = (v) => (v.length ? Math.min(...v) : null);
    const maxOf = (v) => (v.length ? Math.max(...v) : null);
    return [
        ['Device', device.deviceName || ''],
        ['DevEUI', device.devEui || ''],
        ['Entry #', row.no],
        ['Date & time', row.when || row.time],
        ['Type', row.type],
        ['Total chunks', formulaCell(`COUNT(B${HEAD}:${last}${HEAD})`, row.chunkList.length)],
        ['Total samples', formulaCell(`SUM(B${HEAD + 2}:${last}${HEAD + 2})`, row.sampleCount)],
        ['Min', row.min],
        ['Max', row.max],
        ['Average', row.avg],
        ['Each column below is one chunk; its values are listed underneath in the order received.'],
        ['Chunk #', ...blocks.map((b) => (b.index === null ? 'Values' : b.index + 1))],
        ['Received at', ...blocks.map((b) => (b.receivedAt ? new Date(b.receivedAt) : null))],
        ['Samples in chunk', ...blocks.map((b) => b.samples.length)],
        ['Min', ...blocks.map((b) => minOf(b.samples))],
        ['Max', ...blocks.map((b) => maxOf(b.samples))],
        ...Array.from({ length: maxLen }, (_, k) => [`Value ${k + 1}`, ...blocks.map((b) => b.samples[k] ?? null)])
    ];
}

// one entry of the history (a row of payloadHistoryRows), used by the eye-icon popup: the chunk values sheet + every sample
export function payloadEntrySheets(row, device = {}, exportedAt = new Date()) {
    const all = sheetsFromRows([row], [], exportedAt);
    return { grid: payloadEntryGrid(row, device), samples: all.samples };
}

// file name: payload_history_<device>_<date-time>.xlsx, or ..._<device>_entry-<n>_<date-time>.xlsx for one entry
// (characters Windows does not allow are removed)
export function payloadHistoryFileName(device = {}, now = new Date(), entryNo = null) {
    const name = String(device.deviceName || device.devEui || 'device').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'device';
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
    return `payload_history_${name}${entryNo ? `_entry-${entryNo}` : ''}_${stamp}.xlsx`;
}
