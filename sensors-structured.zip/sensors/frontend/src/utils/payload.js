// Packet type shown in the Tabular View. Chunk devices send it in the 3-byte header
// (0 = single dataset, 1 = batch dataset, 2 = probe); other devices send a number in decodedPayload.type.
const CHUNK_TYPE_LABELS = { 0: 'Single', 1: 'Batch', 2: 'Probe' };
export function packetTypeOf(dp) {
    if (!dp) return undefined;
    if (dp.kind === 'probe') return 'Probe';
    if (dp.header) return CHUNK_TYPE_LABELS[dp.header.type] ?? `Type ${dp.header.type}`;
    return dp.type;
}

// Adds one decoded uplink to a payload history list (same rules the Graph page uses)
export function applyPayloadEntry(prev, dp, time) {
    if (!dp) return prev;
    if (dp.kind === 'chunk' && dp.chunkSamples) {
        return [...prev, {
            time,
            samples: dp.chunkSamples,
            avg: null,
            min: Math.min(...dp.chunkSamples),
            max: Math.max(...dp.chunkSamples),
            battery: dp.battery || 'N/A',
            isChunk: true,
            progress: `${dp.receivedChunks}/${dp.totalChunks} chunks`
        }].slice(-100);
    }
    if (dp.kind === 'dataset' && dp.samples) {
        const filtered = prev.filter(p => !p.isChunk);
        filtered.push({ time, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.battery || 'N/A', isChunk: false });
        return filtered.slice(-100);
    }
    if (dp.samples) {
        return [...prev, { time, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.batteryV, isChunk: false }].slice(-100);
    }
    return prev;
}
