// Packet type shown in the Tabular View. Chunk devices send it in the 3-byte header
// (0 = single dataset, 1 = batch dataset, 2 = probe, 3 = packed 12-bit dataset); other devices send a number in decodedPayload.type.
const CHUNK_TYPE_LABELS = { 0: 'Single', 1: 'Batch', 2: 'Probe', 3: 'Packed 12-bit' };
export function packetTypeOf(dp) {
    if (!dp) return undefined;
    if (dp.kind === 'probe') return 'Probe';
    if (dp.header) return CHUNK_TYPE_LABELS[dp.header.type] ?? `Type ${dp.header.type}`;
    return dp.type;
}

// Adds one decoded uplink to a payload history list (same rules the Graph page uses)
export function applyPayloadEntry(prev, dp, time, at = null) {
    if (!dp) return prev;
    if (dp.kind === 'chunk' && dp.chunkSamples) {
        return [...prev, {
            time,
            at,
            samples: dp.chunkSamples,
            avg: null,
            min: Math.min(...dp.chunkSamples),
            max: Math.max(...dp.chunkSamples),
            battery: dp.battery || 'N/A',
            isChunk: true,
            progress: `${dp.receivedChunks}/${dp.totalChunks} chunks`
        }].slice(-100);
    }
    if (dp.kind === 'dataset' && dp.samples) {
        const filtered = prev.filter(p => !p.isChunk);
        filtered.push({ time, at, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.battery || 'N/A', isChunk: false });
        return filtered.slice(-100);
    }
    if (dp.samples) {
        return [...prev, { time, at, samples: dp.samples, avg: dp.avg, min: dp.min, max: dp.max, battery: dp.batteryV, isChunk: false }].slice(-100);
    }
    return prev;
}

// ── Payload History: table rows and Excel sheets (pure functions, no browser or xlsx needed) ──

// one summary row per history entry, oldest first (# = position in the history)
export function payloadHistoryRows(history = []) {
    return history.map((p, i) => {
        const when = p.at ? new Date(p.at) : null;
        const samples = p.samples || [];
        return {
            no: i + 1,
            time: p.time || '',
            when: when && !Number.isNaN(when.getTime()) ? when : null,
            type: p.isChunk ? 'Chunk' : 'Complete',
            chunks: p.isChunk ? (p.progress || '') : '',
            sampleCount: samples.length,
            min: p.min ?? null,
            max: p.max ?? null,
            avg: p.avg ?? null,
            battery: p.battery === 'N/A' ? null : (p.battery ?? null), // no battery reported -> empty cell, not the text N/A
            samples
        };
    });
}

// the sheets of an Excel file, as arrays of rows (numbers stay numbers, empty cells stay empty)
function sheetsFromRows(rows, info) {
    const stamp = (r) => r.when || r.time;
    return {
        info,
        summary: [
            ['#', 'Date & time', 'Type', 'Chunks', 'Samples', 'Min', 'Max', 'Average', 'Battery'],
            ...rows.map((r) => [r.no, stamp(r), r.type, r.chunks, r.sampleCount, r.min, r.max, r.avg, r.battery])
        ],
        samples: [
            ['Entry #', 'Date & time', 'Type', 'Sample #', 'Value'],
            ...rows.flatMap((r) => r.samples.map((v, i) => [r.no, stamp(r), r.type, i + 1, v]))
        ]
    };
}

// whole Payload History of a device
export function payloadHistorySheets(history = [], device = {}, exportedAt = new Date()) {
    const rows = payloadHistoryRows(history);
    return sheetsFromRows(rows, [
        ['Device', device.deviceName || ''],
        ['DevEUI', device.devEui || ''],
        ['Entries', rows.length],
        ['Exported at', exportedAt]
    ]);
}

// one entry of the history (a row of payloadHistoryRows), used by the eye-icon popup
export function payloadEntrySheets(row, device = {}, exportedAt = new Date()) {
    return sheetsFromRows([row], [
        ['Device', device.deviceName || ''],
        ['DevEUI', device.devEui || ''],
        ['Entry #', row.no],
        ['Exported at', exportedAt]
    ]);
}

// file name: payload_history_<device>_<date-time>.xlsx, or ..._<device>_entry-<n>_<date-time>.xlsx for one entry
// (characters Windows does not allow are removed)
export function payloadHistoryFileName(device = {}, now = new Date(), entryNo = null) {
    const name = String(device.deviceName || device.devEui || 'device').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'device';
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
    return `payload_history_${name}${entryNo ? `_entry-${entryNo}` : ''}_${stamp}.xlsx`;
}
