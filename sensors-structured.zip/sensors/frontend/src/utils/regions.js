// Regions that can be chosen when creating a gateway (keep in sync with backend/src/utils/regions.js)
export const REGIONS = ['EU868', 'EU433', 'US915', 'AU915', 'AS923', 'IN865', 'KR920', 'CN470', 'RU864'];
