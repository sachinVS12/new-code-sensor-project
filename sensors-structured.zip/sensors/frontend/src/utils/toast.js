// Toast notifications (replaces alert()). Call from anywhere:
//   toast.success('Saved'), toast.error('Failed'), toast.warning('...'), toast.info('...')
// Optional 2nd argument: { duration: ms, action: { label, onClick } }
// The <ToastContainer /> in App.jsx shows them.
let nextId = 1;

const emit = (type, message, options = {}) => {
    window.dispatchEvent(new CustomEvent('app-toast', { detail: { id: nextId++, type, message, ...options } }));
};

export const toast = {
    success: (message, options) => emit('success', message, options),
    error: (message, options) => emit('error', message, options),
    warning: (message, options) => emit('warning', message, options),
    info: (message, options) => emit('info', message, options)
};
