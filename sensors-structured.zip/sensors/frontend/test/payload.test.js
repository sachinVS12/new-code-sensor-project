// Tests for the Payload History table / Excel data. Run: node test/payload.test.js
import assert from 'node:assert';
import { applyPayloadEntry, payloadHistoryRows, payloadHistoryTotals, payloadHistorySheets, payloadEntrySheets, payloadEntryGrid, excelColumn, payloadHistoryFileName } from '../src/utils/payload.js';

const AT1 = '2026-11-28T10:00:00.000Z';
const AT2 = '2026-11-28T10:05:00.000Z';
const T = (n) => `2026-11-28T10:00:${String(n).padStart(2, '0')}.000Z`;

// helpers that build the decoder messages the dashboard receives
const chunkMsg = (index, total, vals, received) => ({ kind: 'chunk', chunkSamples: vals, receivedChunks: received, totalChunks: total, header: { type: 1, total, chunk: index } });
const datasetMsg = (parts) => {
    const samples = parts.flat();
    return { kind: 'dataset', samples, min: Math.min(...samples), max: Math.max(...samples), avg: samples.reduce((a, b) => a + b, 0) / samples.length, totalChunks: parts.length, chunkCount: parts.length,
        chunks: parts.map((p, i) => ({ index: i, sampleCount: p.length, receivedAt: T(i) })), battery: 3.3 };
};

// ---- entries keep their timestamp, and their chunks ----
let h = applyPayloadEntry([], chunkMsg(0, 3, [5, 9], 1), '10:00:00 AM', AT1);
assert.strictEqual(h[0].at, AT1);
assert.strictEqual(h[0].chunkIndex, 0);
assert.strictEqual(h[0].totalChunks, 3);
h = applyPayloadEntry(h, datasetMsg([[1, 2], [3, 4]]), '10:05:00 AM', AT2);
assert.strictEqual(h.length, 1, 'a complete dataset replaces its chunk rows');
assert.strictEqual(h[0].at, AT2);
assert.strictEqual(h[0].chunks.length, 2, 'but the complete entry keeps the list of its chunks');
assert.strictEqual(applyPayloadEntry([], { samples: [1] }, 't')[0].at, null, 'old callers without a timestamp still work');
console.log('ok  history entries keep their timestamp and chunks');

// ---- rows: chunk counts ----
const parts = [[10, 20, 30], [40, 50], [60]];
h = applyPayloadEntry([], datasetMsg(parts), '10:00:00 AM', AT1);                 // # 1 complete, 3 chunks, 6 samples
h = applyPayloadEntry(h, chunkMsg(1, 29, [7, 8], 2), '10:05:00 AM', AT2);          // # 2 chunk 2 of 29 still arriving
const rows = payloadHistoryRows(h);
assert.deepStrictEqual(rows.map((r) => [r.no, r.type, r.chunks, r.chunkCount, r.sampleCount]), [
    [1, 'Complete', '3/3 chunks', 3, 6],
    [2, 'Chunk', '2/29 chunks', 1, 2],
]);
assert.deepStrictEqual(rows[0].chunkList.map((c) => [c.index, c.sampleCount, c.samples]), [[0, 3, [10, 20, 30]], [1, 2, [40, 50]], [2, 1, [60]]], 'samples are cut back into their chunks');
assert.strictEqual(rows[1].chunkList[0].index, 1);
assert.ok(rows[0].when instanceof Date && rows[0].when.toISOString() === AT1);
assert.strictEqual(payloadHistoryRows([{ time: '9:00 AM', at: 'not a date', samples: [1] }])[0].when, null, 'bad timestamp -> null, falls back to the time text');
assert.deepStrictEqual(payloadHistoryRows([]), []);
assert.strictEqual(payloadHistoryRows([{ samples: [1], battery: 'N/A' }])[0].battery, null);
assert.strictEqual(payloadHistoryRows([{ samples: [1], battery: 3.2 }])[0].battery, 3.2);
// a device that does not send chunks (RAK5146): no chunk numbers at all
const rak = payloadHistoryRows(applyPayloadEntry([], { samples: [7, 8], avg: 7.5, min: 7, max: 8, batteryV: 3.1 }, 't', AT1))[0];
assert.deepStrictEqual([rak.chunkCount, rak.chunks, rak.chunkList.length], [0, '', 0]);
// chunk sizes that do not match the data are not guessed, but the header total is still the chunk count
const odd = payloadHistoryRows([{ samples: [1, 2, 3], isChunk: false, totalChunks: 2, chunks: [{ index: 0, sampleCount: 1 }, { index: 1, sampleCount: 1 }] }])[0];
assert.deepStrictEqual([odd.chunkList.length, odd.chunkCount, odd.chunks], [0, 2, '2/2 chunks']);
// an old backend (no chunk list) still gives the right total from the header
assert.strictEqual(payloadHistoryRows([{ samples: [1, 2, 3, 4], totalChunks: 29 }])[0].chunkCount, 29);
console.log('ok  table rows + chunk counts');

// ---- totals: every chunk counted once ----
assert.deepStrictEqual(payloadHistoryTotals(rows), { entries: 2, chunks: 4, samples: 8 }, '3 chunks in the complete dataset + 1 chunk still arriving');
assert.deepStrictEqual(payloadHistoryTotals([]), { entries: 0, chunks: 0, samples: 0 });
// a dataset that finishes replaces its chunk rows, so nothing is counted twice
let live = [];
for (let c = 0; c < 29; c++) live = applyPayloadEntry(live, chunkMsg(c, 29, [c, c + 1], c + 1), 't', AT1);
assert.strictEqual(payloadHistoryTotals(payloadHistoryRows(live)).chunks, 29, '29 chunk rows = 29 chunks');
live = applyPayloadEntry(live, datasetMsg(Array.from({ length: 29 }, (_, c) => [c, c + 1])), 't', AT2);
assert.deepStrictEqual(payloadHistoryTotals(payloadHistoryRows(live)), { entries: 1, chunks: 29, samples: 58 }, 'after completion: still 29, not 58');
console.log('ok  totals (29 chunks stay 29 after the dataset completes)');

// ---- excel sheets ----
const at = new Date('2026-11-28T12:00:00Z');
const s = payloadHistorySheets(h, { deviceName: 'mohan', devEui: '50c6c10d19c40cce' }, at);
assert.deepStrictEqual(s.summary[0], ['#', 'Date & time', 'Type', 'Chunks', 'Progress', 'Samples', 'Min', 'Max', 'Average', 'Battery']);
assert.strictEqual(s.summary.length, 1 + 2 + 1, 'header + 2 entries + Total row');
assert.deepStrictEqual([s.summary[1][0], s.summary[1][2], s.summary[1][3], s.summary[1][4], s.summary[1][5], s.summary[1][6], s.summary[1][7], s.summary[1][8]], [1, 'Complete', 3, '3/3 chunks', 6, 10, 60, 35]);
assert.ok(s.summary[1][1] instanceof Date, 'time column holds real dates, so Excel can sort / filter them');
assert.deepStrictEqual([s.summary[2][2], s.summary[2][3], s.summary[2][4], s.summary[2][8]], ['Chunk', 1, '2/29 chunks', null]);
const sumTotal = s.summary[3];
assert.strictEqual(sumTotal[0], 'Total');
assert.deepStrictEqual(sumTotal[3], { t: 'n', f: 'SUM(D2:D3)', v: 4 }, 'Chunks total is a SUM over the Chunks column');
assert.deepStrictEqual(sumTotal[5], { t: 'n', f: 'SUM(F2:F3)', v: 8 });

// Chunks sheet: one row per chunk
assert.deepStrictEqual(s.chunks[0], ['Entry #', 'Entry date & time', 'Chunk #', 'Index (as sent)', 'Received at', 'Samples in chunk', 'Min', 'Max', 'First sample #', 'Last sample #']);
assert.strictEqual(s.chunks.length, 1 + 4 + 1, 'header + 3 chunks of entry 1 + 1 chunk of entry 2 + Total row');
assert.deepStrictEqual([s.chunks[1][0], s.chunks[1][2], s.chunks[1][3], s.chunks[1][5], s.chunks[1][6], s.chunks[1][7], s.chunks[1][8], s.chunks[1][9]], [1, 1, 0, 3, 10, 30, 1, 3]);
assert.deepStrictEqual([s.chunks[2][2], s.chunks[2][5], s.chunks[2][8], s.chunks[2][9]], [2, 2, 4, 5], 'chunk 2 covers samples 4-5');
assert.deepStrictEqual([s.chunks[3][2], s.chunks[3][5], s.chunks[3][8], s.chunks[3][9]], [3, 1, 6, 6]);
assert.ok(s.chunks[1][4] instanceof Date && s.chunks[1][4].toISOString() === T(0), 'each chunk has its arrival time');
assert.deepStrictEqual([s.chunks[4][0], s.chunks[4][2], s.chunks[4][3]], [2, 2, 1], 'entry 2 is chunk # 2 (index 1) of its dataset');
assert.deepStrictEqual(s.chunks[5][2], { t: 'n', f: 'COUNT(C2:C5)', v: 4 }, 'Chunks sheet Total = COUNT of the chunk rows');
assert.deepStrictEqual(s.chunks[5][5], { t: 'n', f: 'SUM(F2:F5)', v: 8 });
// the two independent totals agree
assert.strictEqual(sumTotal[3].v, s.chunks[5][2].v, 'Summary total chunks = Chunks sheet count');
assert.strictEqual(sumTotal[5].v, s.chunks[5][5].v, 'Summary total samples = samples listed in the Chunks sheet');

// Samples sheet: every value with its chunk
assert.deepStrictEqual(s.samples[0], ['Entry #', 'Date & time', 'Type', 'Chunk #', 'Sample #', 'Value']);
assert.strictEqual(s.samples.length, 1 + 6 + 2, 'one row per sample');
assert.deepStrictEqual(s.samples.slice(1, 7).map((r) => [r[3], r[4], r[5]]), [[1, 1, 10], [1, 2, 20], [1, 3, 30], [2, 4, 40], [2, 5, 50], [3, 6, 60]], 'chunk # and running sample # per value');
assert.deepStrictEqual([s.samples[7][0], s.samples[7][2], s.samples[7][3], s.samples[7][4], s.samples[7][5]], [2, 'Chunk', 2, 1, 7]);
assert.deepStrictEqual(s.info, [['Device', 'mohan'], ['DevEUI', '50c6c10d19c40cce'], ['Entries', 2], ['Total chunks', 4], ['Total samples', 8], ['Exported at', at]]);

// a full 29-chunk packed dataset: 29 chunk rows, 4096 sample rows, totals 29 / 4096 in both sheets
const sizes = Array.from({ length: 29 }, (_, i) => (i < 28 ? 144 : 4096 - 28 * 144));
let pos = 0; const big = sizes.map((n) => { const p = Array.from({ length: n }, (_, k) => 1470 + ((pos + k) % 1291)); pos += n; return p; });
const bigSheets = payloadHistorySheets(applyPayloadEntry([], datasetMsg(big), 't', AT1));
assert.strictEqual(bigSheets.chunks.length, 1 + 29 + 1);
assert.strictEqual(bigSheets.samples.length, 1 + 4096);
assert.deepStrictEqual([bigSheets.summary[1][3], bigSheets.summary[1][4], bigSheets.summary[2][3].v, bigSheets.summary[2][5].v], [29, '29/29 chunks', 29, 4096]);
assert.deepStrictEqual([bigSheets.chunks[30][2].v, bigSheets.chunks[30][5].v], [29, 4096]);
assert.strictEqual(bigSheets.chunks[29][9], 4096, 'last chunk ends at sample 4096');
assert.strictEqual(bigSheets.samples[4096][3], 29, 'last sample belongs to chunk 29');
// no chunks at all (RAK5146): chunk columns stay empty, totals are 0
const rakSheets = payloadHistorySheets(applyPayloadEntry([], { samples: [7, 8], avg: 7.5, min: 7, max: 8 }, 't', AT1));
assert.deepStrictEqual([rakSheets.summary[1][3], rakSheets.summary[1][4]], [null, null]);
assert.deepStrictEqual(rakSheets.chunks[1], ['Total', null, 0, null, null, 0, null, null, null, null]);
assert.strictEqual(rakSheets.samples[1][3], null);
assert.strictEqual(payloadHistorySheets([]).summary.length, 2, 'empty history: header + Total');
console.log('ok  excel sheets (Summary, Chunks, Samples, Info)');

// ---- one entry (eye icon -> Download): chunks as columns, every value printed under its chunk ----
assert.deepStrictEqual([1, 2, 26, 27, 30, 52, 53, 702, 703].map(excelColumn), ['A', 'B', 'Z', 'AA', 'AD', 'AZ', 'BA', 'ZZ', 'AAA']);
const dev = { deviceName: 'mohan', devEui: '50c6c10d19c40cce' };
const g = payloadEntryGrid(rows[0], dev);   // 3 chunks: [10 20 30] [40 50] [60]
assert.deepStrictEqual(g.slice(0, 5), [['Device', 'mohan'], ['DevEUI', '50c6c10d19c40cce'], ['Entry #', 1], ['Date & time', rows[0].when], ['Type', 'Complete']]);
assert.deepStrictEqual(g[5], ['Total chunks', { t: 'n', f: 'COUNT(B12:D12)', v: 3 }], 'total chunks = COUNT of the Chunk # cells');
assert.deepStrictEqual(g[6], ['Total samples', { t: 'n', f: 'SUM(B14:D14)', v: 6 }], 'total samples = SUM of the Samples in chunk cells');
assert.deepStrictEqual([g[7], g[8], g[9]], [['Min', 10], ['Max', 60], ['Average', 35]]);
assert.deepStrictEqual(g[11], ['Chunk #', 1, 2, 3], 'one column per chunk');
assert.deepStrictEqual(g[12].slice(1).map((d) => d.toISOString()), [T(0), T(1), T(2)], 'arrival time of every chunk');
assert.deepStrictEqual(g[13], ['Samples in chunk', 3, 2, 1]);
assert.deepStrictEqual([g[14], g[15]], [['Min', 10, 40, 60], ['Max', 30, 50, 60]]);
assert.deepStrictEqual(g.slice(16), [['Value 1', 10, 40, 60], ['Value 2', 20, 50, null], ['Value 3', 30, null, null]], 'all values printed under their chunk (shorter chunks leave blanks)');
// the grid and the Samples sheet agree, value for value
const e1 = payloadEntrySheets(rows[0], dev, at);
assert.deepStrictEqual(Object.keys(e1), ['grid', 'samples']);
assert.deepStrictEqual(e1.samples.slice(1).map((r) => [r[3], r[4], r[5]]), [[1, 1, 10], [1, 2, 20], [1, 3, 30], [2, 4, 40], [2, 5, 50], [3, 6, 60]]);
const fromGrid = []; for (let c = 1; c <= 3; c++) for (const r of g.slice(16)) if (r[c] !== null) fromGrid.push(r[c]);
assert.deepStrictEqual(fromGrid, e1.samples.slice(1).map((r) => r[5]), 'reading the grid chunk by chunk gives the samples in order');
// a chunk that is still arriving: one column, its own chunk number
const g2 = payloadEntryGrid(rows[1], dev);
assert.deepStrictEqual([g2[4], g2[11], g2[13]], [['Type', 'Chunk'], ['Chunk #', 2], ['Samples in chunk', 2]]);
assert.deepStrictEqual(g2[5], ['Total chunks', { t: 'n', f: 'COUNT(B12:B12)', v: 1 }]);
assert.deepStrictEqual(g2.slice(16), [['Value 1', 7], ['Value 2', 8]]);
// a device without chunks (RAK5146): one "Values" column, 0 chunks
const g3 = payloadEntryGrid(payloadHistoryRows(applyPayloadEntry([], { samples: [7, 8], avg: 7.5, min: 7, max: 8 }, 't', AT1))[0], dev);
assert.deepStrictEqual([g3[11], g3[5][1].v, g3.length], [['Chunk #', 'Values'], 0, 18]);
// the full 29-chunk dataset: 29 columns (B..AD), 144 value rows, the last chunk is shorter, nothing lost or repeated
const bigRows = payloadHistoryRows(applyPayloadEntry([], datasetMsg(big), 't', AT1));
const gb = payloadEntryGrid(bigRows[0], dev);
assert.strictEqual(gb[11].length, 1 + 29);
assert.deepStrictEqual([gb[5][1].f, gb[5][1].v, gb[6][1].f, gb[6][1].v], ['COUNT(B12:AD12)', 29, 'SUM(B14:AD14)', 4096]);
assert.strictEqual(gb.length, 16 + 144);
assert.strictEqual(gb[13][29], 4096 - 28 * 144, 'chunk 29 holds the remaining samples');
assert.strictEqual(gb[16 + 100][29], null, 'rows below the short last chunk stay empty');
const allBig = []; for (let c = 1; c <= 29; c++) for (const r of gb.slice(16)) if (r[c] !== null) allBig.push(r[c]);
assert.strictEqual(allBig.length, 4096);
assert.deepStrictEqual(allBig, big.flat(), 'the 4096 values, in order, chunk by chunk');
assert.strictEqual(Math.min(...allBig), 1470); assert.strictEqual(Math.max(...allBig), 1470 + 1290);
console.log('ok  single entry: chunk values sheet (chunks as columns, all values printed)');

// ---- file name ----
const d = new Date(2026, 10, 28, 9, 5, 7);
assert.strictEqual(payloadHistoryFileName({ deviceName: 'mohan' }, d), 'payload_history_mohan_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ deviceName: 'mohan' }, d, 2), 'payload_history_mohan_entry-2_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ deviceName: 'my / sensor: 1*' }, d), 'payload_history_my_sensor_1_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ devEui: 'abc' }, d), 'payload_history_abc_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({}, d), 'payload_history_device_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ deviceName: '///' }, d), 'payload_history_device_2026-11-28_09-05-07.xlsx');
console.log('ok  file name');
console.log('payload history: all checks passed');
