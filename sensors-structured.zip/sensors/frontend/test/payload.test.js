// Tests for the Payload History table / Excel data. Run: node test/payload.test.js
import assert from 'node:assert';
import { applyPayloadEntry, payloadHistoryRows, payloadHistorySheets, payloadEntrySheets, payloadHistoryFileName } from '../src/utils/payload.js';

const AT1 = '2026-11-28T10:00:00.000Z';
const AT2 = '2026-11-28T10:05:00.000Z';

// entries remember their full timestamp (needed for the date in the table / Excel)
let h = applyPayloadEntry([], { kind: 'chunk', chunkSamples: [5, 9], receivedChunks: 1, totalChunks: 3 }, '10:00:00 AM', AT1);
assert.strictEqual(h[0].at, AT1);
h = applyPayloadEntry(h, { kind: 'dataset', samples: [1, 2, 3, 4], avg: 2.5, min: 1, max: 4, battery: 3.3 }, '10:05:00 AM', AT2);
assert.strictEqual(h.length, 1, 'a complete dataset replaces its chunks');
assert.strictEqual(h[0].at, AT2);
const rak = applyPayloadEntry([], { samples: [7], avg: 7, min: 7, max: 7, batteryV: 3.1 }, 't', AT1);
assert.strictEqual(rak[0].at, AT1);
assert.strictEqual(applyPayloadEntry([], { samples: [1] }, 't')[0].at, null, 'old callers without a timestamp still work');
console.log('ok  history entries keep their timestamp');

// rows
h = applyPayloadEntry([], { kind: 'dataset', samples: [10, 20, 30], avg: 20, min: 10, max: 30, battery: 3.3 }, '10:00:00 AM', AT1);
h = applyPayloadEntry(h, { kind: 'chunk', chunkSamples: [40, 50], receivedChunks: 2, totalChunks: 5 }, '10:05:00 AM', AT2);
const rows = payloadHistoryRows(h);
assert.strictEqual(rows.length, 2);
assert.deepStrictEqual(rows.map((r) => [r.no, r.type, r.chunks, r.sampleCount, r.min, r.max, r.avg]), [
    [1, 'Complete', '', 3, 10, 30, 20],
    [2, 'Chunk', '2/5 chunks', 2, 40, 50, null],
]);
assert.ok(rows[0].when instanceof Date && rows[0].when.toISOString() === AT1);
assert.strictEqual(payloadHistoryRows([{ time: '9:00 AM', at: 'not a date', samples: [1] }])[0].when, null, 'bad timestamp -> null, falls back to the time text');
assert.deepStrictEqual(payloadHistoryRows([]), []);
assert.strictEqual(payloadHistoryRows([{ samples: [1], battery: 'N/A' }])[0].battery, null);
assert.strictEqual(payloadHistoryRows([{ samples: [1], battery: 3.2 }])[0].battery, 3.2);
console.log('ok  table rows');

// excel sheets
const at = new Date('2026-11-28T12:00:00Z');
const s = payloadHistorySheets(h, { deviceName: 'mohan', devEui: '50c6c10d19c40cce' }, at);
assert.deepStrictEqual(s.summary[0], ['#', 'Date & time', 'Type', 'Chunks', 'Samples', 'Min', 'Max', 'Average', 'Battery']);
assert.strictEqual(s.summary.length, 3);
assert.deepStrictEqual(s.summary[1].slice(2), ['Complete', '', 3, 10, 30, 20, 3.3]);
assert.ok(s.summary[1][1] instanceof Date, 'time column holds real dates, so Excel can sort / filter them');
assert.deepStrictEqual(s.samples[0], ['Entry #', 'Date & time', 'Type', 'Sample #', 'Value']);
assert.strictEqual(s.samples.length, 1 + 3 + 2, 'one row per sample');
assert.deepStrictEqual([s.samples[1][0], s.samples[1][3], s.samples[1][4]], [1, 1, 10]);
assert.deepStrictEqual([s.samples[5][0], s.samples[5][2], s.samples[5][3], s.samples[5][4]], [2, 'Chunk', 2, 50]);
assert.deepStrictEqual(s.info[0], ['Device', 'mohan']);
assert.deepStrictEqual(s.info[1], ['DevEUI', '50c6c10d19c40cce']);
assert.strictEqual(s.info[2][1], 2);
assert.strictEqual(s.info[3][1], at);
// a full 4096-sample dataset stays one row per sample
const big = applyPayloadEntry([], { kind: 'dataset', samples: Array.from({ length: 4096 }, (_, i) => i), avg: 1, min: 0, max: 4095 }, 't', AT1);
assert.strictEqual(payloadHistorySheets(big).samples.length, 4097);
assert.strictEqual(payloadHistorySheets([]).summary.length, 1);
console.log('ok  excel sheets');

// file name
const d = new Date(2026, 10, 28, 9, 5, 7);
assert.strictEqual(payloadHistoryFileName({ deviceName: 'mohan' }, d), 'payload_history_mohan_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ deviceName: 'my / sensor: 1*' }, d), 'payload_history_my_sensor_1_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ devEui: 'abc' }, d), 'payload_history_abc_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({}, d), 'payload_history_device_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ deviceName: '///' }, d), 'payload_history_device_2026-11-28_09-05-07.xlsx');
console.log('ok  file name');
// one entry (eye-icon popup): its own Summary row, only its samples, and its # from the table
const entryRow = payloadHistoryRows(h)[1]; // the chunk entry, # 2
const e = payloadEntrySheets(entryRow, { deviceName: 'mohan', devEui: '50c6c10d19c40cce' }, at);
assert.strictEqual(e.summary.length, 2);
assert.deepStrictEqual([e.summary[1][0], e.summary[1][2], e.summary[1][3], e.summary[1][4], e.summary[1][5], e.summary[1][6], e.summary[1][7]], [2, 'Chunk', '2/5 chunks', 2, 40, 50, null]);
assert.deepStrictEqual(e.samples, [
    ['Entry #', 'Date & time', 'Type', 'Sample #', 'Value'],
    [2, entryRow.when, 'Chunk', 1, 40],
    [2, entryRow.when, 'Chunk', 2, 50],
]);
assert.deepStrictEqual(e.info.slice(0, 3), [['Device', 'mohan'], ['DevEUI', '50c6c10d19c40cce'], ['Entry #', 2]]);
assert.strictEqual(payloadHistoryFileName({ deviceName: 'mohan' }, d, 2), 'payload_history_mohan_entry-2_2026-11-28_09-05-07.xlsx');
assert.strictEqual(payloadHistoryFileName({ deviceName: 'mohan' }, d), 'payload_history_mohan_2026-11-28_09-05-07.xlsx', 'whole-history name unchanged');
console.log('ok  single entry sheets + file name');
console.log('payload history: all checks passed');
