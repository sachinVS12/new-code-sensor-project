import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Where the backend runs (only used by the dev server and `vite preview`)
const backend = process.env.BACKEND_URL || 'http://localhost:3000';

export default defineConfig(({ command }) => ({
    plugins: [react()],

    // Development: the browser connects to the backend WebSocket directly (no proxy in between).
    // Production: the backend serves the UI itself, so the page's own host is used ('' = same host).
    define: {
        __WS_BASE__: JSON.stringify(command === 'serve' ? backend.replace(/^http/, 'ws') : ''),
    },

    server: {
        port: 5173,
        // In development the UI talks to the backend through these proxies,
        // so the frontend code keeps using relative URLs (/api/..., /socket).
        proxy: {
            '/api': { target: backend },
            '/socket': { target: backend, ws: true },
        },
    },

    build: {
        outDir: 'dist',          // the backend serves frontend/dist
        emptyOutDir: true,
        chunkSizeWarningLimit: 1500,
    },
}));
