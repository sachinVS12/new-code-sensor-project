const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

// Where the backend runs (only used by the dev server proxy)
const backend = process.env.BACKEND_URL || 'http://localhost:3000';

module.exports = (env, argv) => {
    const isProd = argv.mode === 'production';

    return {
        entry: './src/main.jsx',
        output: {
            path: path.resolve(__dirname, 'dist'),
            filename: isProd ? 'assets/[name].[contenthash:8].js' : 'assets/[name].js',
            publicPath: '/',
            clean: true,
        },
        resolve: { extensions: ['.js', '.jsx'] },
        module: {
            rules: [
                {
                    test: /\.jsx?$/,
                    exclude: /node_modules/,
                    use: {
                        loader: 'babel-loader',
                        options: { presets: [['@babel/preset-react', { runtime: 'automatic' }]] },
                    },
                },
                { test: /\.css$/, use: ['style-loader', 'css-loader'] },
            ],
        },
        plugins: [new HtmlWebpackPlugin({ template: './public/index.html' })],
        devtool: isProd ? false : 'eval-source-map',
        performance: { hints: false },
        devServer: {
            port: 5173,
            hot: true,
            historyApiFallback: true,
            // In development the UI talks to the backend through these proxies,
            // so the frontend code keeps using relative URLs (/api/..., /socket).
            proxy: [
                { context: ['/api'], target: backend },
                { context: ['/socket'], target: backend, ws: true },
            ],
        },
    };
};
